---
name: openclaw-docs-index
description: Top-level overview of OpenClaw, features, and purpose
metadata: {"openclaw":{"docPath":"index","group":"Start Here"}}
---

# OpenClaw

## Purpose
- Top-level overview of OpenClaw, features, and purpose

## Read When
- Introducing OpenClaw to newcomers

## Topics Covered
- Start here
- Dashboard (browser Control UI)
- How it works
- Network model
- Features (high level)
- Quick start
- Configuration (optional)
- Docs

## Key Commands
```bash
# Recommended: global install (npm/pnpm)
npm install -g openclaw@latest
# or: pnpm add -g openclaw@latest

# Onboard + install the service (launchd/systemd user service)
openclaw onboard --install-daemon

# Pair WhatsApp Web (shows QR)
openclaw channels login

# Gateway runs via the service after onboarding; manual run is still possible:
openclaw gateway --port 18789
```

```bash
git clone https://github.com/openclaw/openclaw.git
cd openclaw
pnpm install
pnpm ui:build # auto-installs UI deps on first run
pnpm build
openclaw onboard --install-daemon
```

```bash
OPENCLAW_CONFIG_PATH=~/.openclaw/a.json \
OPENCLAW_STATE_DIR=~/.openclaw-a \
openclaw gateway --port 19001
```

```bash
openclaw message send --target +15555550123 --message "Hello from OpenClaw"
```

## Key Config Snippets
```json
{
  channels: {
    whatsapp: {
      allowFrom: ["+15555550123"],
      groups: { "*": { requireMention: true } },
    },
  },
  messages: { groupChat: { mentionPatterns: ["@openclaw"] } },
}
```

## Key Environment Variables
- OPENCLAW_CONFIG_PATH
- OPENCLAW_STATE_DIR
- CLAW

## Files And Paths
- ~/.openclaw/a.json
- ~/.openclaw-a
- ~/.openclaw/openclaw.json

## Related Source Code
- openclaw/src
- openclaw/docs/index.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/index