---
name: openclaw-docs-token-use
description: How OpenClaw builds prompt context and reports token usage + costs
metadata: {"openclaw":{"docPath":"token-use","group":"Core Concepts"}}
---

# Token Use and Costs

## Purpose
- How OpenClaw builds prompt context and reports token usage + costs

## Read When
- Explaining token usage, costs, or context windows
- Debugging context growth or compaction behavior

## Topics Covered
- How the system prompt is built
- What counts in the context window
- How to see current token usage
- Cost estimation (when shown)
- Cache TTL and pruning impact
- Tips for reducing token pressure

## Key Config Snippets
```json
agents:
  defaults:
    model:
      primary: "anthropic/claude-opus-4-5"
    models:
      "anthropic/claude-opus-4-5":
        params:
          cacheRetention: "long"
    heartbeat:
      every: "55m"
```

## Related Source Code
- openclaw/src
- openclaw/docs/token-use.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/token-use