---
name: openclaw-docs-tools-exec
description: Exec tool usage, stdin modes, and TTY support
metadata: {"openclaw":{"docPath":"tools/exec","group":"Tools & Skills"}}
---

# Exec Tool

## Purpose
- Exec tool usage, stdin modes, and TTY support

## Read When
- Using or modifying the exec tool
- Debugging stdin or TTY behavior

## Topics Covered
- Parameters
- Config
- Session overrides (`/exec`)
- Authorization model
- Exec approvals (companion app / node host)
- Allowlist + safe bins
- Examples
- apply_patch (experimental)

## Key Commands
```bash
openclaw config get agents.list
openclaw config set agents.list[0].tools.exec.node "node-id-or-name"
```

## Key Config Snippets
```json
{
  tools: {
    exec: {
      pathPrepend: ["~/bin", "/opt/oss/bin"],
    },
  },
}
```

```json
{ "tool": "exec", "command": "ls -la" }
```

## Key Config Keys
- exec.node
- tools.exec.node
- tools.exec.host
- tools.exec.security
- tools.exec.ask

## Files And Paths
- ~/.openclaw/exec-approvals.json
- ~/bin
- /etc/profile`

## Related Source Code
- openclaw/src
- openclaw/docs/tools/exec.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/exec