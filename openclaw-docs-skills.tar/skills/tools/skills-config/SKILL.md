---
name: openclaw-docs-tools-skills-config
description: Skills config schema and examples
metadata: {"openclaw":{"docPath":"tools/skills-config","group":"Tools & Skills"}}
---

# Skills Config

## Purpose
- Skills config schema and examples

## Read When
- Adding or modifying skills config
- Adjusting bundled allowlist or install behavior

## Topics Covered
- Fields
- Notes

## Key Config Snippets
```json
{
  skills: {
    allowBundled: ["gemini", "peekaboo"],
    load: {
      extraDirs: ["~/Projects/agent-scripts/skills", "~/Projects/oss/some-skill-pack/skills"],
      watch: true,
      watchDebounceMs: 250,
    },
    install: {
      preferBrew: true,
      nodeManager: "npm", // npm | pnpm | yarn | bun (Gateway runtime still Node; bun not recommended)
    },
    entries: {
      "nano-banana-pro": {
        enabled: true,
        apiKey: "GEMINI_KEY_HERE",
        env: {
          GEMINI_API_KEY: "GEMINI_KEY_HERE",
        },
      },
```

## Files And Paths
- ~/.openclaw/openclaw.json
- ~/Projects/agent-scripts/skills
- ~/Projects/oss/some-skill-pack/skills
- .openclaw.skillKey`,

## Related Source Code
- openclaw/src
- openclaw/docs/tools/skills-config.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/skills-config