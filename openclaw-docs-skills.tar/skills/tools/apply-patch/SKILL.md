---
name: openclaw-docs-tools-apply-patch
description: Apply multi-file patches with the apply_patch tool
metadata: {"openclaw":{"docPath":"tools/apply-patch","group":"Tools & Skills"}}
---

# apply_patch Tool

## Purpose
- Apply multi-file patches with the apply_patch tool

## Read When
- You need structured file edits across multiple files
- You want to document or debug patch-based edits

## Topics Covered
- Parameters
- Notes
- Example

## Key Config Snippets
```json
{
  "tool": "apply_patch",
  "input": "*** Begin Patch\n*** Update File: src/index.ts\n@@\n-const foo = 1\n+const foo = 2\n*** End Patch"
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/tools/apply-patch.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/apply-patch