---
name: openclaw-docs-tools-slash-commands
description: Slash commands: text vs native, config, and supported commands
metadata: {"openclaw":{"docPath":"tools/slash-commands","group":"Tools & Skills"}}
---

# Slash Commands

## Purpose
- Slash commands: text vs native, config, and supported commands

## Read When
- Using or configuring chat commands
- Debugging command routing or permissions

## Topics Covered
- Config
- Command list
- Usage surfaces (what shows where)
- Model selection (`/model`)
- Debug overrides
- Config updates
- Surface notes

## Key Config Snippets
```json
{
  commands: {
    native: "auto",
    nativeSkills: "auto",
    text: true,
    bash: false,
    bashForegroundMs: 2000,
    config: false,
    debug: false,
    restart: false,
    useAccessGroups: true,
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/tools/slash-commands.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/slash-commands