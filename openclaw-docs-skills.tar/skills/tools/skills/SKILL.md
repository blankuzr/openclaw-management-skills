---
name: openclaw-docs-tools-skills
description: Skills: managed vs workspace, gating rules, and config/env wiring
metadata: {"openclaw":{"docPath":"tools/skills","group":"Tools & Skills"}}
---

# Skills

## Purpose
- Skills: managed vs workspace, gating rules, and config/env wiring

## Read When
- Adding or modifying skills
- Changing skill gating or load rules

## Topics Covered
- Locations and precedence
- Per-agent vs shared skills
- Plugins + skills
- ClawHub (install + sync)
- Security notes
- Format (AgentSkills + Pi-compatible)
- Gating (load-time filters)
- Config overrides (`~/.openclaw/openclaw.json`)

## Key Config Snippets
```json
{
  skills: {
    entries: {
      "nano-banana-pro": {
        enabled: true,
        apiKey: "GEMINI_KEY_HERE",
        env: {
          GEMINI_API_KEY: "GEMINI_KEY_HERE",
        },
        config: {
          endpoint: "https://example.invalid",
          model: "nano-pro",
        },
      },
      peekaboo: { enabled: true },
      sag: { enabled: false },
    },
  },
}
```

```json
{
  skills: {
    load: {
      watch: true,
      watchDebounceMs: 250,
    },
  },
}
```

## Key Config Keys
- openclaw.plugin.json
- metadata.openclaw.requires.config

## Files And Paths
- ~/.openclaw/skills
- ~/.openclaw/openclaw.json
- .openclaw.requires.config`
- .openclaw.homepage`).
- .openclaw`:
- ~/.openclaw/tools/
- .openclaw`
- .openclaw.skillKey`,

## Related Source Code
- openclaw/src
- openclaw/docs/tools/skills.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/skills