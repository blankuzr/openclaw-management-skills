---
name: openclaw-docs-tools-llm-task
description: JSON-only LLM tasks for workflows (optional plugin tool)
metadata: {"openclaw":{"docPath":"tools/llm-task","group":"Tools & Skills"}}
---

# LLM Task

## Purpose
- JSON-only LLM tasks for workflows (optional plugin tool)

## Read When
- You want a JSON-only LLM step inside workflows
- You need schema-validated LLM output for automation

## Topics Covered
- Enable the plugin
- Config (optional)
- Tool parameters
- Output
- Example: Lobster workflow step
- Safety notes

## Key Commands
```bash
openclaw.invoke --tool llm-task --action json --args-json '{
  "prompt": "Given the input email, return intent and draft.",
  "input": {
    "subject": "Hello",
    "body": "Can you help?"
  },
  "schema": {
    "type": "object",
    "properties": {
      "intent": { "type": "string" },
      "draft": { "type": "string" }
    },
```

## Key Config Snippets
```json
{
  "plugins": {
    "entries": {
      "llm-task": { "enabled": true }
    }
  }
}
```

```json
{
  "agents": {
    "list": [
      {
        "id": "main",
        "tools": { "allow": ["llm-task"] }
      }
    ]
  }
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/tools/llm-task.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/llm-task