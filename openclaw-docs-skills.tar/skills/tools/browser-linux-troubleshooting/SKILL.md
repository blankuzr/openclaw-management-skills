---
name: openclaw-docs-tools-browser-linux-troubleshooting
description: Fix Chrome/Brave/Edge/Chromium CDP startup issues for OpenClaw browser control on Linux
metadata: {"openclaw":{"docPath":"tools/browser-linux-troubleshooting","group":"Tools & Skills"}}
---

# Browser Troubleshooting

## Purpose
- Fix Chrome/Brave/Edge/Chromium CDP startup issues for OpenClaw browser control on Linux

## Topics Covered
- Problem: "Failed to start Chrome CDP on port 18800"

## Key Commands
```bash
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
sudo dpkg -i google-chrome-stable_current_amd64.deb
sudo apt --fix-broken install -y  # if there are dependency errors
```

```bash
chromium-browser --headless --no-sandbox --disable-gpu \
  --remote-debugging-port=18800 \
  --user-data-dir=$HOME/.openclaw/browser/openclaw/user-data \
  about:blank &
```

```bash
curl -s http://127.0.0.1:18791/ | jq '{running, pid, chosenBrowser}'
```

```bash
curl -s -X POST http://127.0.0.1:18791/start
curl -s http://127.0.0.1:18791/tabs
```

## Key Config Snippets
```json
{"error":"Error: Failed to start Chrome CDP on port 18800 for profile \"openclaw\"."}
```

```json
{
  "browser": {
    "enabled": true,
    "executablePath": "/usr/bin/google-chrome-stable",
    "headless": true,
    "noSandbox": true
  }
}
```

## Files And Paths
- ~/.openclaw/openclaw.json
- /.openclaw/browser/openclaw/user-data
- ~/.config/systemd/user/openclaw-browser.service

## Related Source Code
- openclaw/src
- openclaw/docs/tools/browser-linux-troubleshooting.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/browser-linux-troubleshooting