---
name: openclaw-docs-tools-web
description: Web search + fetch tools (Brave Search API, Perplexity direct/OpenRouter)
metadata: {"openclaw":{"docPath":"tools/web","group":"Tools & Skills"}}
---

# Web Tools

## Purpose
- Web search + fetch tools (Brave Search API, Perplexity direct/OpenRouter)

## Read When
- You want to enable web_search or web_fetch
- You need Brave Search API key setup
- You want to use Perplexity Sonar for web search

## Topics Covered
- How it works
- Choosing a search provider
- Getting a Brave API key
- Using Perplexity (direct or via OpenRouter)
- web_search
- web_fetch

## Key Config Snippets
```json
{
  tools: {
    web: {
      search: {
        provider: "brave", // or "perplexity"
      },
    },
  },
}
```

```json
{
  tools: {
    web: {
      search: {
        provider: "perplexity",
        perplexity: {
          apiKey: "pplx-...",
          baseUrl: "https://api.perplexity.ai",
          model: "perplexity/sonar-pro",
        },
      },
    },
  },
}
```

## Files And Paths
- ~/.openclaw/openclaw.json
- ~/.openclaw/.env

## Related Source Code
- openclaw/src
- openclaw/docs/tools/web.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/web