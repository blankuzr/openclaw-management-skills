---
name: openclaw-docs-tools-clawhub
description: ClawHub guide: public skills registry + CLI workflows
metadata: {"openclaw":{"docPath":"tools/clawhub","group":"Tools & Skills"}}
---

# ClawHub

## Purpose
- ClawHub guide: public skills registry + CLI workflows

## Read When
- Introducing ClawHub to new users
- Installing, searching, or publishing skills
- Explaining ClawHub CLI flags and sync behavior

## Topics Covered
- What ClawHub is
- How it works
- What you can do
- Who this is for (beginner-friendly)
- Quick start (non-technical)
- Install the CLI
- How it fits into OpenClaw
- Skill system overview

## Key Commands
```bash
npm i -g clawhub
```

```bash
pnpm add -g clawhub
```

```bash
clawhub search "postgres backups"
```

```bash
clawhub install my-skill-pack
```

```bash
clawhub update --all
```

```bash
clawhub publish ./my-skill --slug my-skill --name "My Skill" --version 1.0.0 --tags latest
```

## Key Environment Variables
- CLAWHUB_WORKDIR
- CLAWHUB_CONFIG_PATH
- CLAWHUB_DISABLE_TELEMETRY
- CLAWHUB_SITE
- CLAWHUB_REGISTRY

## Files And Paths
- ~/.openclaw/skills
- ~/openclaw/skills

## Related Source Code
- openclaw/src
- openclaw/docs/tools/clawhub.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/clawhub