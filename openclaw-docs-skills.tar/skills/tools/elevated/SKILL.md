---
name: openclaw-docs-tools-elevated
description: Elevated exec mode and /elevated directives
metadata: {"openclaw":{"docPath":"tools/elevated","group":"Tools & Skills"}}
---

# Elevated Mode

## Purpose
- Elevated exec mode and /elevated directives

## Read When
- Adjusting elevated mode defaults, allowlists, or slash command behavior

## Topics Covered
- What it does
- What it controls (and what it doesn't)
- Resolution order
- Setting a session default
- Availability + allowlists
- Logging + status

## Key Config Keys
- tools.elevated
- tools.elevated.enabled

## Related Source Code
- openclaw/src
- openclaw/docs/tools/elevated.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/elevated