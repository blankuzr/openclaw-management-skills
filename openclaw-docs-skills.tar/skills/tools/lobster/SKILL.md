---
name: openclaw-docs-tools-lobster
description: Typed workflow runtime for OpenClaw with resumable approval gates.
metadata: {"openclaw":{"docPath":"tools/lobster","group":"Tools & Skills"}}
---

# Lobster

## Purpose
- Typed workflow runtime for OpenClaw with resumable approval gates.

## Read When
- You want deterministic multi-step workflows with explicit approvals
- You need to resume a workflow without re-running earlier steps

## Topics Covered
- Hook
- Why
- Why a DSL instead of plain programs?
- How it works
- Pattern: small CLI + JSON pipes + approvals
- JSON-only LLM steps (llm-task)
- Workflow files (.lobster)
- Install Lobster

## Key Commands
```bash
inbox list --json
inbox categorize --json
inbox apply --json
```

```bash
gog.gmail.search --query 'newer_than:1d' \
  | openclaw.invoke --tool message --action send --each --item-key message --args-json '{"provider":"telegram","to":"..."}'
```

```bash
openclaw.invoke --tool llm-task --action json --args-json '{
  "prompt": "Given the input email, return intent and draft.",
  "input": { "subject": "Hello", "body": "Can you help?" },
  "schema": {
    "type": "object",
    "properties": {
      "intent": { "type": "string" },
      "draft": { "type": "string" }
    },
    "required": ["intent", "draft"],
    "additionalProperties": false
  }
```

## Key Config Snippets
```json
{
  "action": "run",
  "pipeline": "exec --json --shell 'inbox list --json' | exec --stdin json --shell 'inbox categorize --json' | exec --stdin json --shell 'inbox apply --json' | approve --preview-from-stdin --limit 5 --prompt 'Apply changes?'",
  "timeoutMs": 30000
}
```

```json
{
  "action": "resume",
  "token": "<resumeToken>",
  "approve": true
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/tools/lobster.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/lobster