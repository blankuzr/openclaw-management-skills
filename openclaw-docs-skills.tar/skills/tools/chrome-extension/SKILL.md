---
name: openclaw-docs-tools-chrome-extension
description: Chrome extension: let OpenClaw drive your existing Chrome tab
metadata: {"openclaw":{"docPath":"tools/chrome-extension","group":"Tools & Skills"}}
---

# Chrome Extension

## Purpose
- Chrome extension: let OpenClaw drive your existing Chrome tab

## Read When
- You want the agent to drive an existing Chrome tab (toolbar button)
- You need remote Gateway + local browser automation via Tailscale
- You want to understand the security implications of browser takeover

## Topics Covered
- What it is (concept)
- Install / load (unpacked)
- Updates (no build step)
- Use it (no extra config)
- Attach / detach (toolbar button)
- Which tab does it control?
- Badge + common errors
- Remote Gateway (use a node host)

## Key Commands
```bash
openclaw browser extension install
```

```bash
openclaw browser extension path
```

```bash
openclaw browser create-profile \
  --name my-chrome \
  --driver extension \
  --cdp-url http://127.0.0.1:18792 \
  --color "#00AA00"
```

## Key Config Snippets
```json
{
  agents: {
    defaults: {
      sandbox: {
        browser: {
          allowHostControl: true,
        },
      },
    },
  },
}
```

## Key Config Keys
- chrome.debugger

## Related Source Code
- openclaw/src
- openclaw/docs/tools/chrome-extension.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/chrome-extension