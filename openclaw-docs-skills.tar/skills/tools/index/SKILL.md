---
name: openclaw-docs-tools-index
description: Agent tool surface for OpenClaw (browser, canvas, nodes, message, cron) replacing legacy `openclaw-*` skills
metadata: {"openclaw":{"docPath":"tools/index","group":"Tools & Skills"}}
---

# Tools

## Purpose
- Agent tool surface for OpenClaw (browser, canvas, nodes, message, cron) replacing legacy `openclaw-*` skills

## Read When
- Adding or modifying agent tools
- Retiring or changing `openclaw-*` skills

## Topics Covered
- Disabling tools
- Tool profiles (base allowlist)
- Provider-specific tool policy
- Tool groups (shorthands)
- Plugins + tools
- Tool inventory
- Parameters (common)
- Recommended agent flows

## Key Config Snippets
```json
{
  tools: { deny: ["browser"] },
}
```

```json
{
  tools: {
    profile: "messaging",
    allow: ["slack", "discord"],
  },
}
```

## Key Config Keys
- tools.allow
- tools.deny
- openclaw.json

## Related Source Code
- openclaw/src
- openclaw/docs/tools/index.md
- openclaw/src/commands
- openclaw/src/terminal
- openclaw/src/browser

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tools/index