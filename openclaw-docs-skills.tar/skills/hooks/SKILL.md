---
name: openclaw-docs-hooks
description: Hooks: event-driven automation for commands and lifecycle events
metadata: {"openclaw":{"docPath":"hooks","group":"Automation & Hooks"}}
---

# Hooks

## Purpose
- Hooks: event-driven automation for commands and lifecycle events

## Read When
- You want event-driven automation for /new, /reset, /stop, and agent lifecycle events
- You want to build, install, or debug hooks

## Topics Covered
- Getting Oriented
- Overview
- Getting Started
- Hook Discovery
- Hook Packs (npm/archives)
- Hook Structure
- What It Does
- Requirements

## Key Commands
```bash
openclaw hooks list
```

```bash
openclaw hooks enable session-memory
```

```bash
openclaw hooks check
```

```bash
openclaw hooks info session-memory
```

```bash
openclaw hooks install <path-or-spec>
```

```bash
mkdir -p ~/.openclaw/hooks/my-hook
cd ~/.openclaw/hooks/my-hook
```

## Key Config Snippets
```json
{
  "name": "@acme/my-hooks",
  "version": "0.1.0",
  "openclaw": {
    "hooks": ["./hooks/my-hook", "./hooks/other-hook"]
  }
}
```

```json
{
  type: 'command' | 'session' | 'agent' | 'gateway',
  action: string,              // e.g., 'new', 'reset', 'stop'
  sessionKey: string,          // Session identifier
  timestamp: Date,             // When the event occurred
  messages: string[],          // Push messages here to send to user
  context: {
    sessionEntry?: SessionEntry,
    sessionId?: string,
    sessionFile?: string,
    commandSource?: string,    // e.g., 'whatsapp', 'telegram'
    senderId?: string,
    workspaceDir?: string,
    bootstrapFiles?: WorkspaceBootstrapFile[],
    cfg?: OpenClawConfig
  }
}
```

## Files And Paths
- ~/.openclaw/workspace/memory/
- ~/.openclaw/logs/commands.log
- ~/.openclaw/hooks/
- //docs.openclaw.ai/hooks#my-hook
- .openclaw`
- ~/.openclaw/hooks/my-hook
- ~/.openclaw/workspace
- ~/.openclaw/gateway.log

## Related Source Code
- openclaw/src
- openclaw/docs/hooks
- openclaw/docs/hooks.md
- openclaw/src/hooks
- openclaw/src/cron

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/hooks