---
name: openclaw-docs-hooks-soul-evil
description: SOUL Evil hook (swap SOUL.md with SOUL_EVIL.md)
metadata: {"openclaw":{"docPath":"hooks/soul-evil","group":"Automation & Hooks"}}
---

# SOUL Evil Hook

## Purpose
- SOUL Evil hook (swap SOUL.md with SOUL_EVIL.md)

## Read When
- You want to enable or tune the SOUL Evil hook
- You want a purge window or random-chance persona swap

## Topics Covered
- How It Works
- Enable
- Options
- Notes
- See Also

## Key Commands
```bash
openclaw hooks enable soul-evil
```

## Key Config Snippets
```json
{
  "hooks": {
    "internal": {
      "enabled": true,
      "entries": {
        "soul-evil": {
          "enabled": true,
          "file": "SOUL_EVIL.md",
          "chance": 0.1,
          "purge": { "at": "21:00", "duration": "15m" }
        }
      }
    }
  }
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/hooks/soul-evil.md
- openclaw/src/hooks
- openclaw/src/cron

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/hooks/soul-evil