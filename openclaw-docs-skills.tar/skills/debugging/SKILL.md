---
name: openclaw-docs-debugging
description: Debugging tools: watch mode, raw model streams, and tracing reasoning leakage
metadata: {"openclaw":{"docPath":"debugging","group":"Gateway & Ops"}}
---

# Debugging

## Purpose
- Debugging tools: watch mode, raw model streams, and tracing reasoning leakage

## Read When
- You need to inspect raw model output for reasoning leakage
- You want to run the Gateway in watch mode while iterating
- You need a repeatable debugging workflow

## Topics Covered
- Runtime debug overrides
- Gateway watch mode
- Dev profile + dev gateway (--dev)
- Raw stream logging (OpenClaw)
- Raw chunk logging (pi-mono)
- Safety notes

## Key Commands
```bash
pnpm gateway:watch --force
```

```bash
tsx watch src/entry.ts gateway --force
```

```bash
pnpm gateway:dev
OPENCLAW_PROFILE=dev openclaw tui
```

```bash
pnpm gateway:dev:reset
```

```bash
OPENCLAW_PROFILE=dev openclaw gateway --dev --reset
```

```bash
openclaw gateway stop
```

## Key Config Keys
- openclaw.json

## Key Environment Variables
- OPENCLAW_PROFILE
- OPENCLAW_STATE_DIR
- OPENCLAW_CONFIG_PATH
- OPENCLAW_GATEWAY_PORT
- OPENCLAW_SKIP_CHANNELS
- OPENCLAW_RAW_STREAM
- OPENCLAW_RAW_STREAM_PATH
- PI_RAW_STREAM
- PI_RAW_STREAM_PATH

## Files And Paths
- ~/.openclaw-dev
- ~/.openclaw-dev/openclaw.json
- ~/.openclaw/logs/raw-stream.jsonl
- ~/.pi-mono/logs/raw-openai-completions.jsonl

## Related Source Code
- openclaw/src
- openclaw/docs/debugging.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/debugging