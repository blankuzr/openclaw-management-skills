---
name: openclaw-docs-automation-gmail-pubsub
description: Gmail Pub/Sub push wired into OpenClaw webhooks via gogcli
metadata: {"openclaw":{"docPath":"automation/gmail-pubsub","group":"Automation & Hooks"}}
---

# Gmail PubSub

## Purpose
- Gmail Pub/Sub push wired into OpenClaw webhooks via gogcli

## Read When
- Wiring Gmail inbox triggers to OpenClaw
- Setting up Pub/Sub push for agent wake

## Topics Covered
- Prereqs
- Wizard (recommended)
- One-time setup
- Start the watch
- Run the push handler
- Expose the handler (advanced, unsupported)
- Test
- Troubleshooting

## Key Commands
```bash
openclaw webhooks gmail setup \
  --account openclaw@gmail.com
```

```bash
openclaw webhooks gmail run
```

```bash
gcloud auth login
gcloud config set project <project-id>
```

```bash
gcloud services enable gmail.googleapis.com pubsub.googleapis.com
```

```bash
gcloud pubsub topics create gog-gmail-watch
```

```bash
gcloud pubsub topics add-iam-policy-binding gog-gmail-watch \
  --member=serviceAccount:gmail-api-push@system.gserviceaccount.com \
  --role=roles/pubsub.publisher
```

## Key Config Snippets
```json
{
  hooks: {
    enabled: true,
    token: "OPENCLAW_HOOK_TOKEN",
    path: "/hooks",
    presets: ["gmail"],
  },
}
```

```json
{
  hooks: {
    enabled: true,
    token: "OPENCLAW_HOOK_TOKEN",
    presets: ["gmail"],
    mappings: [
      {
        match: { path: "gmail" },
        action: "agent",
        wakeMode: "now",
        name: "Gmail",
        sessionKey: "hook:gmail:{{messages[0].id}}",
        messageTemplate: "New email from {{messages[0].from}}\nSubject: {{messages[0].subject}}\n{{messages[0].snippet}}\n{{messages[0].body}}",
        model: "openai/gpt-5.2-mini",
        deliver: true,
        channel: "last",
        // to: "+15551234567"
      },
    ],
  },
```

## Key Environment Variables
- OPENCLAW_HOOK_TOKEN
- OPENCLAW_SKIP_GMAIL_WATCHER

## Related Source Code
- openclaw/src
- openclaw/docs/automation/gmail-pubsub.md
- openclaw/src/hooks
- openclaw/src/cron

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/automation/gmail-pubsub