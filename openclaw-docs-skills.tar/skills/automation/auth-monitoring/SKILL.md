---
name: openclaw-docs-automation-auth-monitoring
description: Monitor OAuth expiry for model providers
metadata: {"openclaw":{"docPath":"automation/auth-monitoring","group":"Automation & Hooks"}}
---

# Auth Monitoring

## Purpose
- Monitor OAuth expiry for model providers

## Read When
- Setting up auth expiry monitoring or alerts
- Automating Claude Code / Codex OAuth refresh checks

## Topics Covered
- Preferred: CLI check (portable)
- Optional scripts (ops / phone workflows)

## Key Commands
```bash
openclaw models status --check
```

## Related Source Code
- openclaw/src
- openclaw/docs/automation/auth-monitoring.md
- openclaw/src/hooks
- openclaw/src/cron

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/automation/auth-monitoring