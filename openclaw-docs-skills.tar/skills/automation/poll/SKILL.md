---
name: openclaw-docs-automation-poll
description: Poll sending via gateway + CLI
metadata: {"openclaw":{"docPath":"automation/poll","group":"Automation & Hooks"}}
---

# Polls

## Purpose
- Poll sending via gateway + CLI

## Read When
- Adding or modifying poll support
- Debugging poll sends from the CLI or gateway

## Topics Covered
- Supported channels
- CLI
- Gateway RPC
- Channel differences
- Agent tool (Message)

## Key Commands
```bash
# WhatsApp
openclaw message poll --target +15555550123 \
  --poll-question "Lunch today?" --poll-option "Yes" --poll-option "No" --poll-option "Maybe"
openclaw message poll --target 123456789@g.us \
  --poll-question "Meeting time?" --poll-option "10am" --poll-option "2pm" --poll-option "4pm" --poll-multi

# Discord
openclaw message poll --channel discord --target channel:123456789 \
  --poll-question "Snack?" --poll-option "Pizza" --poll-option "Sushi"
openclaw message poll --channel discord --target channel:123456789 \
  --poll-question "Plan?" --poll-option "A" --poll-option "B" --poll-duration-hours 48

```

## Files And Paths
- ~/.openclaw/msteams-polls.json

## Related Source Code
- openclaw/src
- openclaw/docs/automation/poll.md
- openclaw/src/hooks
- openclaw/src/cron

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/automation/poll