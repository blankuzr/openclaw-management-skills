---
name: openclaw-docs-broadcast-groups
description: Broadcast a WhatsApp message to multiple agents
metadata: {"openclaw":{"docPath":"broadcast-groups","group":"Channels"}}
---

# Broadcast Groups

## Purpose
- Broadcast a WhatsApp message to multiple agents

## Read When
- Configuring broadcast groups
- Debugging multi-agent replies in WhatsApp

## Topics Covered
- Overview
- Use Cases
- Configuration
- How It Works
- Best Practices
- Compatibility
- Troubleshooting
- Examples

## Key Commands
```bash
tail -f ~/.openclaw/logs/gateway.log | grep broadcast
```

## Key Config Snippets
```json
{
  "broadcast": {
    "120363403215116621@g.us": ["alfred", "baerbel", "assistant3"]
  }
}
```

```json
{
  "broadcast": {
    "strategy": "parallel",
    "120363403215116621@g.us": ["alfred", "baerbel"]
  }
}
```

## Files And Paths
- ~/.openclaw/logs/gateway.log
- ~/agents/formatter
- ~/agents/security
- ~/agents/testing
- ~/agents/docs
- ~/agents/lang-detect
- ~/agents/translate-en
- ~/agents/translate-de

## Related Source Code
- openclaw/src
- openclaw/docs/broadcast-groups.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/broadcast-groups