---
name: openclaw-docs-start-pairing
description: Pairing overview: approve who can DM you + which nodes can join
metadata: {"openclaw":{"docPath":"start/pairing","group":"Start Here"}}
---

# Pairing

## Purpose
- Pairing overview: approve who can DM you + which nodes can join

## Read When
- Setting up DM access control
- Pairing a new iOS/Android node
- Reviewing OpenClaw security posture

## Topics Covered
- 1) DM pairing (inbound chat access)
- 2) Node device pairing (iOS/Android/macOS/headless nodes)
- Related docs

## Key Commands
```bash
openclaw pairing list telegram
openclaw pairing approve telegram <CODE>
```

```bash
openclaw devices list
openclaw devices approve <requestId>
openclaw devices reject <requestId>
```

## Files And Paths
- ~/.openclaw/credentials/
- ~/.openclaw/devices/

## Related Source Code
- openclaw/src
- openclaw/docs/start/pairing.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/start/pairing