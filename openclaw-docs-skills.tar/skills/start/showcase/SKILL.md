---
name: openclaw-docs-start-showcase
description: Community-built projects and integrations powered by OpenClaw
metadata: {"openclaw":{"docPath":"start/showcase","group":"Start Here"}}
---

# Showcase

## Purpose
- Community-built projects and integrations powered by OpenClaw

## Topics Covered
-  OpenClaw in Action
-  Fresh from Discord
-  Automation & Workflows
-  Knowledge & Memory
-  Voice & Phone
-  Infrastructure & Deployment
-  Home & Hardware
-  Community Projects

## Related Source Code
- openclaw/src
- openclaw/docs/start/showcase.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/start/showcase