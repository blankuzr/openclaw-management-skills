---
name: openclaw-docs-start-openclaw
description: End-to-end guide for running OpenClaw as a personal assistant with safety cautions
metadata: {"openclaw":{"docPath":"start/openclaw","group":"Start Here"}}
---

# Personal Assistant Setup

## Purpose
- End-to-end guide for running OpenClaw as a personal assistant with safety cautions

## Read When
- Onboarding a new assistant instance
- Reviewing safety/permission implications

## Topics Covered
-  Safety first
- Prerequisites
- The two-phone setup (recommended)
- 5-minute quick start
- Give the agent a workspace (AGENTS)
- The config that turns it into "an assistant"
- Sessions and memory
- Heartbeats (proactive mode)

## Key Commands
```bash
npm install -g openclaw@latest
# or: pnpm add -g openclaw@latest
```

```bash
git clone https://github.com/openclaw/openclaw.git
cd openclaw
pnpm install
pnpm ui:build # auto-installs UI deps on first run
pnpm build
pnpm link --global
```

```bash
openclaw channels login
```

```bash
openclaw gateway --port 18789
```

```bash
openclaw setup
```

```bash
openclaw status          # local status (creds, sessions, queued events)
openclaw status --all    # full diagnosis (read-only, pasteable)
openclaw status --deep   # adds gateway health probes (Telegram + Discord)
openclaw health --json   # gateway health snapshot (WS)
```

## Key Config Snippets
```json
{
  channels: { whatsapp: { allowFrom: ["+15555550123"] } },
}
```

```json
{
  agent: {
    workspace: "~/.openclaw/workspace",
  },
}
```

## Files And Paths
- ~/.openclaw/openclaw.json
- ~/.openclaw/workspace
- ~/.openclaw/agents/
- ~/.openclaw/sessions/sessions.json
- /tmp/openclaw/`

## Related Source Code
- openclaw/src
- openclaw/docs/start/openclaw.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/start/openclaw