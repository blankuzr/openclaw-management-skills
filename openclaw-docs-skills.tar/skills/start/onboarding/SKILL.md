---
name: openclaw-docs-start-onboarding
description: First-run onboarding flow for OpenClaw (macOS app)
metadata: {"openclaw":{"docPath":"start/onboarding","group":"Start Here"}}
---

# Onboarding

## Purpose
- First-run onboarding flow for OpenClaw (macOS app)

## Read When
- Designing the macOS onboarding assistant
- Implementing auth or identity setup

## Topics Covered
- Page order (current)
- 1) Welcome + security notice
- 2) Local vs Remote
- 3) Local-only auth (Anthropic OAuth)
- 4) Setup Wizard (Gatewaydriven)
- 5) Permissions
- 6) CLI (optional)
- 7) Onboarding chat (dedicated session)

## Key Commands
```bash
openclaw webhooks gmail setup --account you@gmail.com
```

## Files And Paths
- ~/.openclaw/credentials/oauth.json
- ~/.openclaw/workspace
- ~/.openclaw/agents/

## Related Source Code
- openclaw/src
- openclaw/docs/start/onboarding.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/start/onboarding