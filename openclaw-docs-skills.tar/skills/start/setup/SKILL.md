---
name: openclaw-docs-start-setup
description: Setup guide: keep your OpenClaw setup tailored while staying up-to-date
metadata: {"openclaw":{"docPath":"start/setup","group":"Start Here"}}
---

# Setup

## Purpose
- Setup guide: keep your OpenClaw setup tailored while staying up-to-date

## Read When
- Setting up a new machine
- You want "latest + greatest" without breaking your personal setup

## Topics Covered
- TL;DR
- Prereqs (from source)
- Tailoring strategy (so updates don't hurt)
- Stable workflow (macOS app first)
- Bleeding edge workflow (Gateway in a terminal)
- Credential storage map
- Updating (without wrecking your setup)
- Linux (systemd user service)

## Key Commands
```bash
openclaw setup
```

```bash
openclaw setup
```

```bash
openclaw channels login
```

```bash
openclaw health
```

```bash
./scripts/restart-mac.sh
```

```bash
pnpm install
pnpm gateway:watch
```

## Files And Paths
- ~/.openclaw/workspace
- ~/.openclaw/openclaw.json
- ~/.openclaw/credentials/
- ~/.openclaw/agents/
- /tmp/openclaw/`
- ~/.openclaw/credentials/whatsapp/
- ~/.openclaw/credentials/oauth.json
- ~/.openclaw/

## Related Source Code
- openclaw/src
- openclaw/docs/start/setup.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/start/setup