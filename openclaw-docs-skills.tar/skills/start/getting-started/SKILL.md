---
name: openclaw-docs-start-getting-started
description: Beginner guide: from zero to first message (wizard, auth, channels, pairing)
metadata: {"openclaw":{"docPath":"start/getting-started","group":"Start Here"}}
---

# Getting Started

## Purpose
- Beginner guide: from zero to first message (wizard, auth, channels, pairing)

## Read When
- First time setup from zero
- You want the fastest path from install -> onboarding -> first message

## Topics Covered
- 0) Prereqs
- 1) Install the CLI (recommended)
- 2) Run the onboarding wizard (and install the service)
- 3) Start the Gateway
- 3.5) Quick verify (2 min)
- 4) Pair + connect your first chat surface
- 5) DM safety (pairing approvals)
- From source (development)

## Key Commands
```bash
curl -fsSL https://openclaw.ai/install.sh | bash
```

```bash
iwr -useb https://openclaw.ai/install.ps1 | iex
```

```bash
npm install -g openclaw@latest
```

```bash
pnpm add -g openclaw@latest
```

```bash
openclaw onboard --install-daemon
```

```bash
openclaw gateway status
```

## Key Config Snippets
```json
{
  "routing": {
    "agents": {
      "main": {
        "workspace": "~/.openclaw/workspace",
        "sandbox": { "mode": "off" }
      }
    }
  }
}
```

## Files And Paths
- ~/.openclaw/workspace
- ~/.openclaw/credentials/oauth.json
- ~/.openclaw/agents/

## Related Source Code
- openclaw/src
- openclaw/docs/start/getting-started.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/start/getting-started