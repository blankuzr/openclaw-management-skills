---
name: openclaw-docs-providers-anthropic
description: Use Anthropic Claude via API keys or setup-token in OpenClaw
metadata: {"openclaw":{"docPath":"providers/anthropic","group":"Providers"}}
---

# Anthropic

## Purpose
- Use Anthropic Claude via API keys or setup-token in OpenClaw

## Read When
- You want to use Anthropic models in OpenClaw
- You want setup-token instead of API keys

## Topics Covered
- Option A: Anthropic API key
- Prompt caching (Anthropic API)
- Option B: Claude setup-token
- Notes
- Troubleshooting

## Key Commands
```bash
openclaw onboard
# choose: Anthropic API key

# or non-interactive
openclaw onboard --anthropic-api-key "$ANTHROPIC_API_KEY"
```

```bash
claude setup-token
```

```bash
openclaw models auth setup-token --provider anthropic
```

```bash
openclaw models auth paste-token --provider anthropic
```

```bash
# Paste a setup-token during onboarding
openclaw onboard --auth-choice setup-token
```

## Key Config Snippets
```json
{
  env: { ANTHROPIC_API_KEY: "sk-ant-..." },
  agents: { defaults: { model: { primary: "anthropic/claude-opus-4-5" } } },
}
```

```json
{
  agents: {
    defaults: {
      models: {
        "anthropic/claude-opus-4-5": {
          params: { cacheRetention: "long" },
        },
      },
    },
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/providers/anthropic.md
- openclaw/src/providers

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/providers/anthropic