---
name: openclaw-docs-providers-moonshot
description: Configure Moonshot K2 vs Kimi Coding (separate providers + keys)
metadata: {"openclaw":{"docPath":"providers/moonshot","group":"Providers"}}
---

# Moonshot AI

## Purpose
- Configure Moonshot K2 vs Kimi Coding (separate providers + keys)

## Read When
- You want Moonshot K2 (Moonshot Open Platform) vs Kimi Coding setup
- You need to understand separate endpoints, keys, and model refs
- You want copy/paste config for either provider

## Topics Covered
- Config snippet (Moonshot API)
- Kimi Coding
- Notes

## Key Commands
```bash
openclaw onboard --auth-choice moonshot-api-key
```

```bash
openclaw onboard --auth-choice kimi-code-api-key
```

## Key Config Snippets
```json
{
  env: { MOONSHOT_API_KEY: "sk-..." },
  agents: {
    defaults: {
      model: { primary: "moonshot/kimi-k2.5" },
      models: {
        // moonshot-kimi-k2-aliases:start
        "moonshot/kimi-k2.5": { alias: "Kimi K2.5" },
        "moonshot/kimi-k2-0905-preview": { alias: "Kimi K2" },
        "moonshot/kimi-k2-turbo-preview": { alias: "Kimi K2 Turbo" },
        "moonshot/kimi-k2-thinking": { alias: "Kimi K2 Thinking" },
        "moonshot/kimi-k2-thinking-turbo": { alias: "Kimi K2 Thinking Turbo" },
        // moonshot-kimi-k2-aliases:end
      },
    },
  },
  models: {
    mode: "merge",
    providers: {
      moonshot: {
```

```json
{
  env: { KIMI_API_KEY: "sk-..." },
  agents: {
    defaults: {
      model: { primary: "kimi-coding/k2p5" },
      models: {
        "kimi-coding/k2p5": { alias: "Kimi K2.5" },
      },
    },
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/providers/moonshot.md
- openclaw/src/providers

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/providers/moonshot