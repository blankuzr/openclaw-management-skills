---
name: openclaw-docs-providers-minimax
description: Use MiniMax M2.1 in OpenClaw
metadata: {"openclaw":{"docPath":"providers/minimax","group":"Providers"}}
---

# MiniMax

## Purpose
- Use MiniMax M2.1 in OpenClaw

## Read When
- You want MiniMax models in OpenClaw
- You need MiniMax setup guidance

## Topics Covered
- Model overview (M2.1)
- MiniMax M2.1 vs MiniMax M2.1 Lightning
- Choose a setup
- Configure via `openclaw configure`
- Configuration options
- Notes
- Troubleshooting

## Key Commands
```bash
openclaw plugins enable minimax-portal-auth  # skip if already loaded.
openclaw gateway restart  # restart if gateway is already running
openclaw onboard --auth-choice minimax-portal
```

```bash
openclaw models list
```

## Key Config Snippets
```json
{
  env: { MINIMAX_API_KEY: "sk-..." },
  agents: { defaults: { model: { primary: "minimax/MiniMax-M2.1" } } },
  models: {
    mode: "merge",
    providers: {
      minimax: {
        baseUrl: "https://api.minimax.io/anthropic",
        apiKey: "${MINIMAX_API_KEY}",
        api: "anthropic-messages",
        models: [
          {
            id: "MiniMax-M2.1",
            name: "MiniMax M2.1",
            reasoning: false,
            input: ["text"],
            cost: { input: 15, output: 60, cacheRead: 2, cacheWrite: 10 },
            contextWindow: 200000,
            maxTokens: 8192,
          },
```

```json
{
  env: { MINIMAX_API_KEY: "sk-..." },
  agents: {
    defaults: {
      models: {
        "anthropic/claude-opus-4-5": { alias: "opus" },
        "minimax/MiniMax-M2.1": { alias: "minimax" },
      },
      model: {
        primary: "anthropic/claude-opus-4-5",
        fallbacks: ["minimax/MiniMax-M2.1"],
      },
    },
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/providers/minimax.md
- openclaw/src/providers

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/providers/minimax