---
name: openclaw-docs-providers-opencode
description: Use OpenCode Zen (curated models) with OpenClaw
metadata: {"openclaw":{"docPath":"providers/opencode","group":"Providers"}}
---

# OpenCode Zen

## Purpose
- Use OpenCode Zen (curated models) with OpenClaw

## Read When
- You want OpenCode Zen for model access
- You want a curated list of coding-friendly models

## Topics Covered
- CLI setup
- Config snippet
- Notes

## Key Commands
```bash
openclaw onboard --auth-choice opencode-zen
# or non-interactive
openclaw onboard --opencode-zen-api-key "$OPENCODE_API_KEY"
```

## Key Config Snippets
```json
{
  env: { OPENCODE_API_KEY: "sk-..." },
  agents: { defaults: { model: { primary: "opencode/claude-opus-4-5" } } },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/providers/opencode.md
- openclaw/src/providers

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/providers/opencode