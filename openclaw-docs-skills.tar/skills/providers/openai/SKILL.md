---
name: openclaw-docs-providers-openai
description: Use OpenAI via API keys or Codex subscription in OpenClaw
metadata: {"openclaw":{"docPath":"providers/openai","group":"Providers"}}
---

# OpenAI

## Purpose
- Use OpenAI via API keys or Codex subscription in OpenClaw

## Read When
- You want to use OpenAI models in OpenClaw
- You want Codex subscription auth instead of API keys

## Topics Covered
- Option A: OpenAI API key (OpenAI Platform)
- Option B: OpenAI Code (Codex) subscription
- Notes

## Key Commands
```bash
openclaw onboard --auth-choice openai-api-key
# or non-interactive
openclaw onboard --openai-api-key "$OPENAI_API_KEY"
```

```bash
# Run Codex OAuth in the wizard
openclaw onboard --auth-choice openai-codex

# Or run OAuth directly
openclaw models auth login --provider openai-codex
```

## Key Config Snippets
```json
{
  env: { OPENAI_API_KEY: "sk-..." },
  agents: { defaults: { model: { primary: "openai/gpt-5.2" } } },
}
```

```json
{
  agents: { defaults: { model: { primary: "openai-codex/gpt-5.2" } } },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/providers/openai.md
- openclaw/src/providers

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/providers/openai