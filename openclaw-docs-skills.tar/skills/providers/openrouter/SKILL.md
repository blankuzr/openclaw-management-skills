---
name: openclaw-docs-providers-openrouter
description: Use OpenRouter's unified API to access many models in OpenClaw
metadata: {"openclaw":{"docPath":"providers/openrouter","group":"Providers"}}
---

# OpenRouter

## Purpose
- Use OpenRouter's unified API to access many models in OpenClaw

## Read When
- You want a single API key for many LLMs
- You want to run models via OpenRouter in OpenClaw

## Topics Covered
- CLI setup
- Config snippet
- Notes

## Key Commands
```bash
openclaw onboard --auth-choice apiKey --token-provider openrouter --token "$OPENROUTER_API_KEY"
```

## Key Config Snippets
```json
{
  env: { OPENROUTER_API_KEY: "sk-or-..." },
  agents: {
    defaults: {
      model: { primary: "openrouter/anthropic/claude-sonnet-4-5" },
    },
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/providers/openrouter.md
- openclaw/src/providers

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/providers/openrouter