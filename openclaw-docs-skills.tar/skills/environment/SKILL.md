---
name: openclaw-docs-environment
description: Where OpenClaw loads environment variables and the precedence order
metadata: {"openclaw":{"docPath":"environment","group":"Gateway & Ops"}}
---

# Environment Variables

## Purpose
- Where OpenClaw loads environment variables and the precedence order

## Read When
- You need to know which env vars are loaded, and in what order
- You are debugging missing API keys in the Gateway
- You are documenting provider auth or deployment environments

## Topics Covered
- Precedence (highest -> lowest)
- Config `env` block
- Shell env import
- Env var substitution in config
- Related

## Key Config Snippets
```json
{
  env: {
    OPENROUTER_API_KEY: "sk-or-...",
    vars: {
      GROQ_API_KEY: "gsk-...",
    },
  },
}
```

```json
{
  env: {
    shellEnv: {
      enabled: true,
      timeoutMs: 15000,
    },
  },
}
```

## Key Environment Variables
- OPENCLAW_STATE_DIR
- OPENCLAW_LOAD_SHELL_ENV
- OPENCLAW_SHELL_ENV_TIMEOUT_MS

## Files And Paths
- ~/.openclaw/.env
- ~/.openclaw/openclaw.json

## Related Source Code
- openclaw/src
- openclaw/docs/environment.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/environment