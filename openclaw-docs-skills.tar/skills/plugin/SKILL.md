---
name: openclaw-docs-plugin
description: OpenClaw plugins/extensions: discovery, config, and safety
metadata: {"openclaw":{"docPath":"plugin","group":"Tools & Skills"}}
---

# Plugins

## Purpose
- OpenClaw plugins/extensions: discovery, config, and safety

## Read When
- Adding or modifying plugins/extensions
- Documenting plugin install or load rules

## Topics Covered
- Quick start (new to plugins?)
- Available plugins (official)
- Runtime helpers
- Discovery & precedence
- Plugin IDs
- Config
- Plugin slots (exclusive categories)
- Control UI (schema + labels)

## Key Commands
```bash
openclaw plugins list
```

```bash
openclaw plugins install @openclaw/voice-call
```

```bash
openclaw plugins list
openclaw plugins info <id>
openclaw plugins install <path>                 # copy a local file/dir into ~/.openclaw/extensions/<id>
openclaw plugins install ./extensions/voice-call # relative path ok
openclaw plugins install ./plugin.tgz           # install from a local tarball
openclaw plugins install ./plugin.zip           # install from a local zip
openclaw plugins install -l ./extensions/voice-call # link (no copy) for dev
openclaw plugins install @openclaw/voice-call # install from npm
openclaw plugins update <id>
openclaw plugins update --all
openclaw plugins enable <id>
openclaw plugins disable <id>
```

## Key Config Snippets
```json
{
  "name": "my-pack",
  "openclaw": {
    "extensions": ["./src/safety.ts", "./src/tools.ts"]
  }
}
```

```json
{
  "name": "@openclaw/nextcloud-talk",
  "openclaw": {
    "extensions": ["./index.ts"],
    "channel": {
      "id": "nextcloud-talk",
      "label": "Nextcloud Talk",
      "selectionLabel": "Nextcloud Talk (self-hosted)",
      "docsPath": "/channels/nextcloud-talk",
      "docsLabel": "nextcloud-talk",
      "blurb": "Self-hosted chat via Nextcloud Talk webhook bots.",
      "order": 65,
      "aliases": ["nc-talk", "nc"]
    },
    "install": {
      "npmSpec": "@openclaw/nextcloud-talk",
      "localPath": "extensions/nextcloud-talk",
      "defaultChoice": "npm"
    }
  }
```

## Key Environment Variables
- OPENCLAW_PLUGIN_CATALOG_PATHS
- OPENCLAW_MPM_CATALOG_PATHS

## Files And Paths
- /.openclaw/extensions/*.ts`
- /.openclaw/extensions/*/index.ts`
- ~/.openclaw/extensions/
- ~/.openclaw/mpm/plugins.json
- ~/.openclaw/mpm/catalog.json
- ~/.openclaw/plugins/catalog.json
- ~/.../voice-call.ts
- ~/Projects/oss/voice-call-extension

## Related Source Code
- openclaw/src
- openclaw/docs/plugin.md
- openclaw/extensions
- openclaw/src/plugins
- openclaw/src/plugin-sdk

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/plugin