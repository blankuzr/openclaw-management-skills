---
name: openclaw-docs-help-troubleshooting
description: Troubleshooting hub: symptoms -> checks -> fixes
metadata: {"openclaw":{"docPath":"help/troubleshooting","group":"Help"}}
---

# Troubleshooting

## Purpose
- Troubleshooting hub: symptoms -> checks -> fixes

## Read When
- You see an error and want the fix path
- The installer says "success" but the CLI doesn't work

## Topics Covered
- First 60 seconds
- Common "it broke" cases

## Key Commands
```bash
openclaw status
openclaw status --all
openclaw gateway probe
openclaw logs --follow
openclaw doctor
```

```bash
openclaw status --deep
```

```bash
curl -fsSL https://openclaw.ai/install.sh | bash -s -- --verbose
```

```bash
curl -fsSL https://openclaw.ai/install.sh | bash -s -- --beta --verbose
```

```bash
openclaw status --all
```

## Key Environment Variables
- OPENCLAW_VERBOSE

## Files And Paths
- .openclaw.ai`

## Related Source Code
- openclaw/src
- openclaw/docs/help/troubleshooting.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/help/troubleshooting