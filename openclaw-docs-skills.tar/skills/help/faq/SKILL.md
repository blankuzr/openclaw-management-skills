---
name: openclaw-docs-help-faq
description: Frequently asked questions about OpenClaw setup, configuration, and usage
metadata: {"openclaw":{"docPath":"help/faq","group":"Help"}}
---

# FAQ

## Purpose
- Frequently asked questions about OpenClaw setup, configuration, and usage

## Topics Covered
- Table of contents
- First 60 seconds if something's broken
- Quick start and first-run setup
- What is OpenClaw?
- Skills and automation
- Sandboxing and memory
- Where things live on disk
- Config basics

## Key Commands
```bash
openclaw status
```

```bash
openclaw status --all
```

```bash
openclaw gateway status
```

```bash
openclaw status --deep
```

```bash
openclaw logs --follow
```

```bash
tail -f "$(ls -t /tmp/openclaw/openclaw-*.log | head -1)"
```

## Key Config Snippets
```json
{
  agents: { defaults: { workspace: "~/.openclaw/workspace" } },
}
```

```json
{
  agents: {
    defaults: {
      workspace: "~/Projects/my-repo",
    },
  },
}
```

## Key Environment Variables
- OPENCLAW_GATEWAY_TOKEN
- OPENCLAW_STATE_DIR
- OPENCLAW_SKIP_CRON
- OPENCLAW_HOME_VOLUME
- OPENCLAW_DOCKER_APT_PACKAGES
- OPENCLAW_CONFIG_PATH
- OPENCLAW_LOAD_SHELL_ENV
- OPENCLAW_SHELL_ENV_TIMEOUT_MS
- OPENCLAW_PROFILE
- OPENCLAW_GATEWAY_PORT

## Files And Paths
- .openclaw.ai
- /tmp/openclaw/openclaw-*.log
- ~/.openclaw
- ~/.openclaw/workspace
- ~/.openclaw/
- ~/.openclaw/agents/
- .openclaw.ai`
- .openclaw.ai`,

## Related Source Code
- openclaw/src
- openclaw/docs/help/faq.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/help/faq