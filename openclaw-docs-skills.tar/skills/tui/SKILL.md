---
name: openclaw-docs-tui
description: Terminal UI (TUI): connect to the Gateway from any machine
metadata: {"openclaw":{"docPath":"tui","group":"Web & Interfaces"}}
---

# TUI

## Purpose
- Terminal UI (TUI): connect to the Gateway from any machine

## Read When
- You want a beginner-friendly walkthrough of the TUI
- You need the complete list of TUI features, commands, and shortcuts

## Topics Covered
- Quick start
- What you see
- Mental model: agents + sessions
- Sending + delivery
- Pickers + overlays
- Keyboard shortcuts
- Slash commands
- Local shell commands

## Key Commands
```bash
openclaw gateway
```

```bash
openclaw tui
```

```bash
openclaw tui --url ws://<host>:<port> --token <gateway-token>
```

## Related Source Code
- openclaw/src
- openclaw/docs/tui.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/tui