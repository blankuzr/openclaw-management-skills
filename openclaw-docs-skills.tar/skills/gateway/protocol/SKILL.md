---
name: openclaw-docs-gateway-protocol
description: Gateway WebSocket protocol: handshake, frames, versioning
metadata: {"openclaw":{"docPath":"gateway/protocol","group":"Gateway & Ops"}}
---

# Gateway Protocol

## Purpose
- Gateway WebSocket protocol: handshake, frames, versioning

## Read When
- Implementing or updating gateway WS clients
- Debugging protocol mismatches or connect failures
- Regenerating protocol schema/models

## Topics Covered
- Transport
- Handshake (connect)
- Framing
- Roles + scopes
- Presence
- Exec approvals
- Versioning
- Auth

## Key Config Snippets
```json
{
  "type": "event",
  "event": "connect.challenge",
  "payload": { "nonce": "", "ts": 1737264000000 }
}
```

```json
{
  "type": "req",
  "id": "",
  "method": "connect",
  "params": {
    "minProtocol": 3,
    "maxProtocol": 3,
    "client": {
      "id": "cli",
      "version": "1.2.3",
      "platform": "macos",
      "mode": "operator"
    },
    "role": "operator",
    "scopes": ["operator.read", "operator.write"],
    "caps": [],
    "commands": [],
    "permissions": {},
    "auth": { "token": "" },
    "locale": "en-US",
```

## Key Environment Variables
- OPENCLAW_GATEWAY_TOKEN

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/protocol.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/protocol