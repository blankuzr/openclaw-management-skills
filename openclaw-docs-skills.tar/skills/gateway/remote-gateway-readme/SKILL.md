---
name: openclaw-docs-gateway-remote-gateway-readme
description: SSH tunnel setup for OpenClaw.app connecting to a remote gateway
metadata: {"openclaw":{"docPath":"gateway/remote-gateway-readme","group":"Gateway & Ops"}}
---

# Remote Gateway Setup

## Purpose
- SSH tunnel setup for OpenClaw.app connecting to a remote gateway

## Topics Covered
- Overview
- Quick Setup
- Auto-Start Tunnel on Login
- Troubleshooting
- How It Works

## Key Commands
```bash
ssh-copy-id -i ~/.ssh/id_rsa <REMOTE_USER>@<REMOTE_IP>
```

```bash
launchctl setenv OPENCLAW_GATEWAY_TOKEN "<your-token>"
```

```bash
ssh -N remote-gateway &
```

```bash
# Quit OpenClaw.app (Q), then reopen:
open /path/to/OpenClaw.app
```

```bash
launchctl bootstrap gui/$UID ~/Library/LaunchAgents/bot.molt.ssh-tunnel.plist
```

```bash
ps aux | grep "ssh -N remote-gateway" | grep -v grep
lsof -i :18789
```

## Key Environment Variables
- OPENCLAW_GATEWAY_TOKEN

## Files And Paths
- ~/.ssh/config
- ~/.ssh/id_rsa
- ~/Library/LaunchAgents/bot.molt.ssh-tunnel.plist
- .openclaw.ssh-tunnel`

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/remote-gateway-readme.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/remote-gateway-readme