---
name: openclaw-docs-gateway-security-index
description: Security considerations and threat model for running an AI gateway with shell access
metadata: {"openclaw":{"docPath":"gateway/security/index","group":"Gateway & Ops"}}
---

# Security

## Purpose
- Security considerations and threat model for running an AI gateway with shell access

## Read When
- Adding features that widen access or automation

## Topics Covered
- Quick check: `openclaw security audit`
- Credential storage map
- Security Audit Checklist
- Control UI over HTTP
- Reverse Proxy Configuration
- Local session logs live on disk
- Node execution (system.run)
- Dynamic skills (watcher / remote nodes)

## Key Commands
```bash
openclaw security audit
openclaw security audit --deep
openclaw security audit --fix
```

```bash
openclaw pairing list <channel>
openclaw pairing approve <channel> <code>
```

```bash
detect-secrets scan --baseline .secrets.baseline
```

```bash
detect-secrets audit .secrets.baseline
```

## Key Config Snippets
```json
gateway:
  trustedProxies:
    - "127.0.0.1" # if your proxy runs on localhost
  auth:
    mode: password
    password: ${OPENCLAW_GATEWAY_PASSWORD}
```

```json
{
  session: { dmScope: "per-channel-peer" },
}
```

## Key Environment Variables
- OPENCLAW_GATEWAY_PASSWORD
- OPENCLAW_STATE_DIR
- OPENCLAW_GATEWAY_PORT
- OPENCLAW_DISABLE_BONJOUR

## Files And Paths
- ~/.openclaw
- ~/.openclaw/credentials/whatsapp/
- ~/.openclaw/credentials/
- ~/.openclaw/agents/
- ~/.openclaw/credentials/oauth.json
- ~/.openclaw/extensions/
- ~/.openclaw/openclaw.json
- ~/.openclaw/

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/security/index.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/security/index