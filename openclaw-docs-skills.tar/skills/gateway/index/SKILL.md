---
name: openclaw-docs-gateway-index
description: Runbook for the Gateway service, lifecycle, and operations
metadata: {"openclaw":{"docPath":"gateway/index","group":"Gateway & Ops"}}
---

# Gateway Runbook

## Purpose
- Runbook for the Gateway service, lifecycle, and operations

## Read When
- Running or debugging the gateway process

## Topics Covered
- What it is
- How to run (local)
- Remote access
- Multiple gateways (same host)
- Protocol (operator view)
- Methods (initial set)
- Events
- WebChat integration

## Key Commands
```bash
openclaw gateway --port 18789
# for full debug/trace logs in stdio:
openclaw gateway --port 18789 --verbose
# if the port is busy, terminate listeners then start:
openclaw gateway --force
# dev loop (auto-reload on TS changes):
pnpm gateway:watch
```

```bash
ssh -N -L 18789:127.0.0.1:18789 user@host
```

```bash
openclaw --dev setup
openclaw --dev gateway --allow-unconfigured
# then target the dev instance:
openclaw --dev status
openclaw --dev health
```

```bash
openclaw --profile main gateway install
openclaw --profile rescue gateway install
```

```bash
OPENCLAW_CONFIG_PATH=~/.openclaw/a.json OPENCLAW_STATE_DIR=~/.openclaw-a openclaw gateway --port 19001
OPENCLAW_CONFIG_PATH=~/.openclaw/b.json OPENCLAW_STATE_DIR=~/.openclaw-b openclaw gateway --port 19002
```

```bash
openclaw gateway status
openclaw gateway install
openclaw gateway stop
openclaw gateway restart
openclaw logs --follow
```

## Key Config Snippets
```json
[Unit]
Description=OpenClaw Gateway (profile: <profile>, v<version>)
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/usr/local/bin/openclaw gateway --port 18789
Restart=always
RestartSec=5
Environment=OPENCLAW_GATEWAY_TOKEN=
WorkingDirectory=/home/youruser

[Install]
WantedBy=default.target
```

## Key Environment Variables
- OPENCLAW_CONFIG_PATH
- OPENCLAW_SKIP_CANVAS_HOST
- OPENCLAW_GATEWAY_TOKEN
- OPENCLAW_GATEWAY_PORT
- OPENCLAW_SERVICE_MARKER
- OPENCLAW_SERVICE_KIND
- OPENCLAW_SERVICE_VERSION
- OPENCLAW_STATE_DIR
- OPENCLAW_CANVAS_HOST_PORT

## Files And Paths
- ~/.openclaw/openclaw.json
- ~/.openclaw/workspace/canvas
- .openclaw.*`
- ~/.openclaw-dev
- ~/.openclaw-dev/openclaw.json
- ~/.openclaw/workspace-dev
- ~/.openclaw/a.json
- ~/.openclaw-a

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/index.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/index