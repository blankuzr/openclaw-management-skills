---
name: openclaw-docs-gateway-background-process
description: Background exec execution and process management
metadata: {"openclaw":{"docPath":"gateway/background-process","group":"Gateway & Ops"}}
---

# Background Exec and Process Tool

## Purpose
- Background exec execution and process management

## Read When
- Adding or modifying background exec behavior
- Debugging long-running exec tasks

## Topics Covered
- exec tool
- Child process bridging
- process tool
- Examples

## Key Config Snippets
```json
{ "tool": "exec", "command": "sleep 5 && echo done", "yieldMs": 1000 }
```

```json
{ "tool": "process", "action": "poll", "sessionId": "<id>" }
```

## Key Environment Variables
- PI_BASH_YIELD_MS
- PI_BASH_MAX_OUTPUT_CHARS
- OPENCLAW_BASH_PENDING_MAX_OUTPUT_CHARS
- PI_BASH_JOB_TTL_MS

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/background-process.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/background-process