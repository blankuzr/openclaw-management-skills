---
name: openclaw-docs-gateway-multiple-gateways
description: Run multiple OpenClaw Gateways on one host (isolation, ports, and profiles)
metadata: {"openclaw":{"docPath":"gateway/multiple-gateways","group":"Gateway & Ops"}}
---

# Multiple Gateways

## Purpose
- Run multiple OpenClaw Gateways on one host (isolation, ports, and profiles)

## Read When
- Running more than one Gateway on the same machine
- You need isolated config/state/ports per Gateway

## Topics Covered
- Isolation checklist (required)
- Recommended: profiles (`--profile`)
- Rescue-bot guide
- Port mapping (derived)
- Browser/CDP notes (common footgun)
- Manual env example
- Quick checks

## Key Commands
```bash
# main
openclaw --profile main setup
openclaw --profile main gateway --port 18789

# rescue
openclaw --profile rescue setup
openclaw --profile rescue gateway --port 19001
```

```bash
openclaw --profile main gateway install
openclaw --profile rescue gateway install
```

```bash
# Main bot (existing or fresh, without --profile param)
# Runs on port 18789 + Chrome CDC/Canvas/... Ports
openclaw onboard
openclaw gateway install

# Rescue bot (isolated profile + ports)
openclaw --profile rescue onboard
# Notes:
# - workspace name will be postfixed with -rescue per default
# - Port should be at least 18789 + 20 Ports,
#   better choose completely different base port, like 19789,
# - rest of the onboarding is the same as normal
```

```bash
OPENCLAW_CONFIG_PATH=~/.openclaw/main.json \
OPENCLAW_STATE_DIR=~/.openclaw-main \
openclaw gateway --port 18789

OPENCLAW_CONFIG_PATH=~/.openclaw/rescue.json \
OPENCLAW_STATE_DIR=~/.openclaw-rescue \
openclaw gateway --port 19001
```

```bash
openclaw --profile main status
openclaw --profile rescue status
openclaw --profile rescue browser status
```

## Key Config Keys
- agents.defaults.workspace
- gateway.port

## Key Environment Variables
- OPENCLAW_CONFIG_PATH
- OPENCLAW_STATE_DIR
- OPENCLAW_GATEWAY_PORT

## Files And Paths
- ~/.openclaw/main.json
- ~/.openclaw-main
- ~/.openclaw/rescue.json
- ~/.openclaw-rescue

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/multiple-gateways.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/multiple-gateways