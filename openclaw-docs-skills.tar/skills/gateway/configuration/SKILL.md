---
name: openclaw-docs-gateway-configuration
description: All configuration options for ~/.openclaw/openclaw.json with examples
metadata: {"openclaw":{"docPath":"gateway/configuration","group":"Gateway & Ops"}}
---

# Configuration

## Purpose
- All configuration options for ~/.openclaw/openclaw.json with examples

## Read When
- Adding or modifying config fields

## Topics Covered
- Strict config validation
- Schema + UI hints
- Apply + restart (RPC)
- Partial updates (RPC)
- Minimal config (recommended starting point)
- Self-chat mode (recommended for group control)
- Config Includes (`$include`)
- Common options

## Key Commands
```bash
openclaw gateway call config.get --params '{}' # capture payload.hash
openclaw gateway call config.apply --params '{
  "raw": "{\\n  agents: { defaults: { workspace: \\"~/.openclaw/workspace\\" } }\\n}\\n",
  "baseHash": "<hash-from-config.get>",
  "sessionKey": "agent:main:whatsapp:dm:+15555550123",
  "restartDelayMs": 1000
}'
```

```bash
openclaw gateway call config.get --params '{}' # capture payload.hash
openclaw gateway call config.patch --params '{
  "raw": "{\\n  channels: { telegram: { groups: { \\"*\\": { requireMention: false } } } }\\n}\\n",
  "baseHash": "<hash-from-config.get>",
  "sessionKey": "agent:main:whatsapp:dm:+15555550123",
  "restartDelayMs": 1000
}'
```

```bash
scripts/sandbox-setup.sh
```

```bash
#!/usr/bin/env bash
exec ssh -T gateway-host imsg "$@"
```

```bash
scripts/sandbox-setup.sh
```

```bash
scripts/sandbox-browser-setup.sh
```

## Key Config Snippets
```json
{
  agents: { defaults: { workspace: "~/.openclaw/workspace" } },
  channels: { whatsapp: { allowFrom: ["+15555550123"] } },
}
```

```json
{
  agents: {
    defaults: { workspace: "~/.openclaw/workspace" },
    list: [
      {
        id: "main",
        groupChat: { mentionPatterns: ["@openclaw", "reisponde"] },
      },
    ],
  },
  channels: {
    whatsapp: {
      // Allowlist is DMs only; including your own number enables self-chat mode.
      allowFrom: ["+15555550123"],
      groups: { "*": { requireMention: true } },
    },
  },
}
```

## Key Config Keys
- channels.whatsapp.groups
- channels.telegram.groups
- channels.discord.guilds
- agents.defaults.workspace
- agents.defaults
- config.schema
- config.apply
- config.patch
- config.get

## Key Environment Variables
- OPENCLAW_STATE_DIR
- OPENCLAW_LOAD_SHELL_ENV
- OPENCLAW_SHELL_ENV_TIMEOUT_MS
- OPENCLAW_GATEWAY_TOKEN
- OPENCLAW_OAUTH_DIR
- OPENCLAW_AGENT_DIR
- PI_CODING_AGENT_DIR
- OPENCLAW_GATEWAY_PORT
- OPENCLAW_GATEWAY_PASSWORD
- OPENCLAW_CONFIG_PATH

## Files And Paths
- ~/.openclaw/openclaw.json
- ~/.openclaw/workspace
- /agents.json5
- /clients/mueller.json5
- /clients/schmidt.json5
- ~/.openclaw/agents.json5
- /base.json5
- /mueller.json5

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/configuration.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/configuration