---
name: openclaw-docs-gateway-sandbox-vs-tool-policy-vs-elevated
description: Why a tool is blocked: sandbox runtime, tool allow/deny policy, and elevated exec gates
metadata: {"openclaw":{"docPath":"gateway/sandbox-vs-tool-policy-vs-elevated","group":"Gateway & Ops"}}
---

# Sandbox vs Tool Policy vs Elevated

## Purpose
- Why a tool is blocked: sandbox runtime, tool allow/deny policy, and elevated exec gates

## Topics Covered
- Quick debug
- Sandbox: where tools run
- Tool policy: which tools exist/are callable
- Elevated: exec-only "run on host"
- Common "sandbox jail" fixes

## Key Commands
```bash
openclaw sandbox explain
openclaw sandbox explain --session agent:main:main
openclaw sandbox explain --agent work
openclaw sandbox explain --json
```

## Key Config Snippets
```json
{
  tools: {
    sandbox: {
      tools: {
        allow: ["group:runtime", "group:fs", "group:sessions", "group:memory"],
      },
    },
  },
}
```

## Files And Paths
- /var/run/docker.sock`

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/sandbox-vs-tool-policy-vs-elevated.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/sandbox-vs-tool-policy-vs-elevated