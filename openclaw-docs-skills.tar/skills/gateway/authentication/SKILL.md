---
name: openclaw-docs-gateway-authentication
description: Model authentication: OAuth, API keys, and setup-token
metadata: {"openclaw":{"docPath":"gateway/authentication","group":"Gateway & Ops"}}
---

# Authentication

## Purpose
- Model authentication: OAuth, API keys, and setup-token

## Read When
- Debugging model auth or OAuth expiry
- Documenting authentication or credential storage

## Topics Covered
- Recommended Anthropic setup (API key)
- Anthropic: setup-token (subscription auth)
- Checking model auth status
- Controlling which credential is used
- Troubleshooting
- Requirements

## Key Commands
```bash
export ANTHROPIC_API_KEY="..."
openclaw models status
```

```bash
cat >> ~/.openclaw/.env <<'EOF'
ANTHROPIC_API_KEY=...
EOF
```

```bash
openclaw models status
openclaw doctor
```

```bash
claude setup-token
```

```bash
openclaw models auth setup-token --provider anthropic
```

```bash
openclaw models auth paste-token --provider anthropic
```

## Files And Paths
- ~/.openclaw/.env

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/authentication.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/authentication