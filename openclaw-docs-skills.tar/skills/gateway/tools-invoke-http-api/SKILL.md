---
name: openclaw-docs-gateway-tools-invoke-http-api
description: Invoke a single tool directly via the Gateway HTTP endpoint
metadata: {"openclaw":{"docPath":"gateway/tools-invoke-http-api","group":"Gateway & Ops"}}
---

# Tools Invoke API

## Purpose
- Invoke a single tool directly via the Gateway HTTP endpoint

## Read When
- Calling tools without running a full agent turn
- Building automations that need tool policy enforcement

## Topics Covered
- Authentication
- Request body
- Policy + routing behavior
- Responses
- Example

## Key Commands
```bash
curl -sS http://127.0.0.1:18789/tools/invoke \
  -H 'Authorization: Bearer YOUR_TOKEN' \
  -H 'Content-Type: application/json' \
  -d '{
    "tool": "sessions_list",
    "action": "json",
    "args": {}
  }'
```

## Key Config Snippets
```json
{
  "tool": "sessions_list",
  "action": "json",
  "args": {},
  "sessionKey": "main",
  "dryRun": false
}
```

## Key Config Keys
- gateway.auth.token
- gateway.auth.password

## Key Environment Variables
- OPENCLAW_GATEWAY_TOKEN
- OPENCLAW_GATEWAY_PASSWORD

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/tools-invoke-http-api.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/tools-invoke-http-api