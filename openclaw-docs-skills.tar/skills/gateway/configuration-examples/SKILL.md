---
name: openclaw-docs-gateway-configuration-examples
description: Schema-accurate configuration examples for common OpenClaw setups
metadata: {"openclaw":{"docPath":"gateway/configuration-examples","group":"Gateway & Ops"}}
---

# Configuration Examples

## Purpose
- Schema-accurate configuration examples for common OpenClaw setups

## Read When
- Learning how to configure OpenClaw
- Looking for configuration examples
- Setting up OpenClaw for the first time

## Topics Covered
- Quick start
- Expanded example (major options)
- Common patterns
- Tips

## Key Config Snippets
```json
{
  agent: { workspace: "~/.openclaw/workspace" },
  channels: { whatsapp: { allowFrom: ["+15555550123"] } },
}
```

```json
{
  identity: {
    name: "Clawd",
    theme: "helpful assistant",
    emoji: "",
  },
  agent: {
    workspace: "~/.openclaw/workspace",
    model: { primary: "anthropic/claude-sonnet-4-5" },
  },
  channels: {
    whatsapp: {
      allowFrom: ["+15555550123"],
      groups: { "*": { requireMention: true } },
    },
  },
}
```

## Files And Paths
- ~/.openclaw/workspace
- ~/.openclaw/openclaw.json
- /tmp/openclaw/openclaw.log
- ~/.openclaw/agents/default/sessions/sessions.json
- ~/.openclaw/sandboxes
- /var/tmp
- ~/.openclaw/cron/cron.json
- ~/.openclaw/hooks

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/configuration-examples.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/configuration-examples