---
name: openclaw-docs-gateway-remote
description: Remote access using SSH tunnels (Gateway WS) and tailnets
metadata: {"openclaw":{"docPath":"gateway/remote","group":"Gateway & Ops"}}
---

# Remote Access

## Purpose
- Remote access using SSH tunnels (Gateway WS) and tailnets

## Read When
- Running or troubleshooting remote gateway setups

## Topics Covered
- The core idea
- Common VPN/tailnet setups (where the agent lives)
- Command flow (what runs where)
- SSH tunnel (CLI + tools)
- CLI remote defaults
- Chat UI over SSH
- macOS app "Remote over SSH"
- Security rules (remote/VPN)

## Key Commands
```bash
ssh -N -L 18789:127.0.0.1:18789 user@host
```

## Key Config Snippets
```json
{
  gateway: {
    mode: "remote",
    remote: {
      url: "ws://127.0.0.1:18789",
      token: "your-token",
    },
  },
}
```

## Key Environment Variables
- OPENCLAW_GATEWAY_PORT

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/remote.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/remote