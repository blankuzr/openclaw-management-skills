---
name: openclaw-docs-gateway-logging
description: Logging surfaces, file logs, WS log styles, and console formatting
metadata: {"openclaw":{"docPath":"gateway/logging","group":"Gateway & Ops"}}
---

# Logging

## Purpose
- Logging surfaces, file logs, WS log styles, and console formatting

## Read When
- Changing logging output or formats
- Debugging CLI or gateway output

## Topics Covered
- File-based logger
- Console capture
- Tool summary redaction
- Gateway WebSocket logs
- Console formatting (subsystem logging)

## Key Commands
```bash
openclaw logs --follow
```

```bash
# optimized (only errors/slow)
openclaw gateway

# show all WS traffic (paired)
openclaw gateway --verbose --ws-log compact

# show all WS traffic (full meta)
openclaw gateway --verbose --ws-log full
```

## Key Config Keys
- logging.file
- logging.level
- logs.tail

## Files And Paths
- /tmp/openclaw/`
- ~/.openclaw/openclaw.json

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/logging.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/logging