---
name: openclaw-docs-gateway-troubleshooting
description: Quick troubleshooting guide for common OpenClaw failures
metadata: {"openclaw":{"docPath":"gateway/troubleshooting","group":"Gateway & Ops"}}
---

# Troubleshooting

## Purpose
- Quick troubleshooting guide for common OpenClaw failures

## Read When
- Investigating runtime issues or failures

## Topics Covered
- Status & Diagnostics
- Common Issues
- Common troubleshooting
- macOS Specific Issues
- Debug Mode
- Log Locations
- Health Check
- Reset Everything

## Key Commands
```bash
openclaw models auth setup-token --provider anthropic
```

```bash
openclaw models status
```

```bash
# Run on the gateway host (paste the setup-token)
openclaw models auth setup-token --provider anthropic
openclaw models status
```

```bash
openclaw models auth paste-token --provider anthropic
openclaw models status
```

```bash
openclaw gateway status
openclaw doctor
```

```bash
openclaw configure
```

## Key Config Snippets
```json
{ "logging": { "level": "debug" } }
```

```json
{ "logging": { "consoleLevel": "debug", "consoleStyle": "pretty" } }
```

## Key Environment Variables
- OPENCLAW_SHOW_SECRETS
- OPENCLAW_STATE_DIR
- OPENCLAW_GATEWAY_TOKEN
- OPENCLAW_CONFIG_PATH

## Files And Paths
- /tmp/openclaw/openclaw-YYYY-MM-DD.log`
- ~/.openclaw/.env
- ~/openclaw
- ~/.openclaw/sandboxes/...
- /.openclaw/openclaw.json}
- /tmp/openclaw/openclaw-*.log
- ~/.openclaw/agents/
- /.openclaw}/credentials

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/troubleshooting.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/troubleshooting