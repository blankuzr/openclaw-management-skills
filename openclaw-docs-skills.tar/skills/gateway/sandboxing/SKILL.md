---
name: openclaw-docs-gateway-sandboxing
description: How OpenClaw sandboxing works: modes, scopes, workspace access, and images
metadata: {"openclaw":{"docPath":"gateway/sandboxing","group":"Gateway & Ops"}}
---

# Sandboxing

## Purpose
- How OpenClaw sandboxing works: modes, scopes, workspace access, and images

## Topics Covered
- What gets sandboxed
- Modes
- Scope
- Workspace access
- Custom bind mounts
- Images + setup
- setupCommand (one-time container setup)
- Tool policy + escape hatches

## Key Commands
```bash
scripts/sandbox-setup.sh
```

```bash
scripts/sandbox-browser-setup.sh
```

## Key Config Snippets
```json
{
  agents: {
    defaults: {
      sandbox: {
        docker: {
          binds: ["/home/user/source:/source:ro", "/var/run/docker.sock:/var/run/docker.sock"],
        },
      },
    },
    list: [
      {
        id: "build",
        sandbox: {
          docker: {
            binds: ["/mnt/cache:/cache:rw"],
          },
        },
      },
    ],
  },
```

```json
{
  agents: {
    defaults: {
      sandbox: {
        mode: "non-main",
        scope: "session",
        workspaceAccess: "none",
      },
    },
  },
}
```

## Key Config Keys
- agents.defaults.sandbox
- agents.defaults.sandbox.browser
- tools.elevated
- agents.defaults.sandbox.mode
- agents.defaults.sandbox.scope
- agents.defaults.sandbox.docker.binds

## Files And Paths
- ~/.openclaw/sandboxes
- /var/run/docker.sock:/var/run/docker.sock

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/sandboxing.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/sandboxing