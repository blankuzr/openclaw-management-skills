---
name: openclaw-docs-gateway-bridge-protocol
description: Bridge protocol (legacy nodes): TCP JSONL, pairing, scoped RPC
metadata: {"openclaw":{"docPath":"gateway/bridge-protocol","group":"Gateway & Ops"}}
---

# Bridge Protocol

## Purpose
- Bridge protocol (legacy nodes): TCP JSONL, pairing, scoped RPC

## Read When
- Building or debugging node clients (iOS/Android/macOS node mode)
- Investigating pairing or bridge auth failures
- Auditing the node surface exposed by the gateway

## Topics Covered
- Why we have both
- Transport
- Handshake + pairing
- Frames
- Exec lifecycle events
- Tailnet usage
- Versioning

## Key Config Keys
- bridge.tls.enabled
- screen.record
- location.get
- sms.send
- exec.finished
- exec.denied
- exec.started

## Files And Paths
- ~/.openclaw/openclaw.json

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/bridge-protocol.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/bridge-protocol