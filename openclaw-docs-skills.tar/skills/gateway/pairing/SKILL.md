---
name: openclaw-docs-gateway-pairing
description: Gateway-owned node pairing (Option B) for iOS and other remote nodes
metadata: {"openclaw":{"docPath":"gateway/pairing","group":"Gateway & Ops"}}
---

# Gateway-Owned Pairing

## Purpose
- Gateway-owned node pairing (Option B) for iOS and other remote nodes

## Read When
- Implementing node pairing approvals without macOS UI
- Adding CLI flows for approving remote nodes
- Extending gateway protocol with node management

## Topics Covered
- Concepts
- How pairing works
- CLI workflow (headless friendly)
- API surface (gateway protocol)
- Auto-approval (macOS app)
- Storage (local, private)
- Transport behavior

## Key Commands
```bash
openclaw nodes pending
openclaw nodes approve <requestId>
openclaw nodes reject <requestId>
openclaw nodes status
openclaw nodes rename --node <id|name|ip> --name "Living Room iPad"
```

## Key Config Keys
- node.pair.requested

## Key Environment Variables
- OPENCLAW_STATE_DIR

## Files And Paths
- ~/.openclaw
- ~/.openclaw/nodes/paired.json
- ~/.openclaw/nodes/pending.json

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/pairing.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/pairing