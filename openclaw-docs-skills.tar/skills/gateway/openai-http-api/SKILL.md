---
name: openclaw-docs-gateway-openai-http-api
description: Expose an OpenAI-compatible /v1/chat/completions HTTP endpoint from the Gateway
metadata: {"openclaw":{"docPath":"gateway/openai-http-api","group":"Gateway & Ops"}}
---

# OpenAI Chat Completions

## Purpose
- Expose an OpenAI-compatible /v1/chat/completions HTTP endpoint from the Gateway

## Read When
- Integrating tools that expect OpenAI Chat Completions

## Topics Covered
- Authentication
- Choosing an agent
- Enabling the endpoint
- Disabling the endpoint
- Session behavior
- Streaming (SSE)
- Examples

## Key Commands
```bash
curl -sS http://127.0.0.1:18789/v1/chat/completions \
  -H 'Authorization: Bearer YOUR_TOKEN' \
  -H 'Content-Type: application/json' \
  -H 'x-openclaw-agent-id: main' \
  -d '{
    "model": "openclaw",
    "messages": [{"role":"user","content":"hi"}]
  }'
```

```bash
curl -N http://127.0.0.1:18789/v1/chat/completions \
  -H 'Authorization: Bearer YOUR_TOKEN' \
  -H 'Content-Type: application/json' \
  -H 'x-openclaw-agent-id: main' \
  -d '{
    "model": "openclaw",
    "stream": true,
    "messages": [{"role":"user","content":"hi"}]
  }'
```

## Key Config Snippets
```json
{
  gateway: {
    http: {
      endpoints: {
        chatCompletions: { enabled: true },
      },
    },
  },
}
```

```json
{
  gateway: {
    http: {
      endpoints: {
        chatCompletions: { enabled: false },
      },
    },
  },
}
```

## Key Config Keys
- gateway.auth.token
- gateway.auth.password

## Key Environment Variables
- OPENCLAW_GATEWAY_TOKEN
- OPENCLAW_GATEWAY_PASSWORD

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/openai-http-api.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/openai-http-api