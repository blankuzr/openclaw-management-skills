---
name: openclaw-docs-gateway-cli-backends
description: CLI backends: text-only fallback via local AI CLIs
metadata: {"openclaw":{"docPath":"gateway/cli-backends","group":"Gateway & Ops"}}
---

# CLI Backends

## Purpose
- CLI backends: text-only fallback via local AI CLIs

## Read When
- You want a reliable fallback when API providers fail
- You are running Claude Code CLI or other local AI CLIs and want to reuse them
- You need a text-only, tool-free path that still supports sessions and images

## Topics Covered
- Beginner-friendly quick start
- Using it as a fallback
- Configuration overview
- How it works
- Sessions
- Images (pass-through)
- Inputs / outputs
- Defaults (built-in)

## Key Commands
```bash
openclaw agent --message "hi" --model claude-cli/opus-4.5
```

```bash
openclaw agent --message "hi" --model codex-cli/gpt-5.2-codex
```

## Key Config Snippets
```json
{
  agents: {
    defaults: {
      cliBackends: {
        "claude-cli": {
          command: "/opt/homebrew/bin/claude",
        },
      },
    },
  },
}
```

```json
{
  agents: {
    defaults: {
      model: {
        primary: "anthropic/claude-opus-4-5",
        fallbacks: ["claude-cli/opus-4.5"],
      },
      models: {
        "anthropic/claude-opus-4-5": { alias: "Opus" },
        "claude-cli/opus-4.5": {},
      },
    },
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/cli-backends.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/cli-backends