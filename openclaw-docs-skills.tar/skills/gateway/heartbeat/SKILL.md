---
name: openclaw-docs-gateway-heartbeat
description: Heartbeat polling messages and notification rules
metadata: {"openclaw":{"docPath":"gateway/heartbeat","group":"Gateway & Ops"}}
---

# Heartbeat

## Purpose
- Heartbeat polling messages and notification rules

## Read When
- Adjusting heartbeat cadence or messaging
- Deciding between heartbeat and cron for scheduled tasks

## Topics Covered
- Quick start (beginner)
- Defaults
- What the heartbeat prompt is for
- Response contract
- Config
- Delivery behavior
- Visibility controls
- HEARTBEAT.md (optional)

## Key Commands
```bash
openclaw system event --text "Check for urgent follow-ups" --mode now
```

## Key Config Snippets
```json
{
  agents: {
    defaults: {
      heartbeat: {
        every: "30m",
        target: "last",
        // activeHours: { start: "08:00", end: "24:00" },
        // includeReasoning: true, // optional: send separate `Reasoning:` message too
      },
    },
  },
}
```

```json
{
  agents: {
    defaults: {
      heartbeat: {
        every: "30m", // default: 30m (0m disables)
        model: "anthropic/claude-opus-4-5",
        includeReasoning: false, // default: false (deliver separate Reasoning: message when available)
        target: "last", // last | none | <channel id> (core or plugin, e.g. "bluebubbles")
        to: "+15551234567", // optional channel-specific override
        prompt: "Read HEARTBEAT.md if it exists (workspace context). Follow it strictly. Do not infer or repeat old tasks from prior chats. If nothing needs attention, reply HEARTBEAT_OK.",
        ackMaxChars: 300, // max chars allowed after HEARTBEAT_OK
      },
    },
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/gateway/heartbeat.md
- openclaw/src/gateway
- openclaw/src/config
- openclaw/src/routing
- openclaw/src/pairing
- openclaw/src/daemon

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/gateway/heartbeat