---
name: openclaw-docs-railway
description: Guidance for the OpenClaw docs section: railway.
metadata: {"openclaw":{"docPath":"railway","group":"Install & Updates"}}
---

# Deploy on Railway

## Purpose
- Guidance for the OpenClaw docs section: railway.

## Topics Covered
- Quick checklist (new users)
- One-click deploy
- What you get
- Required Railway settings
- Setup flow
- Getting chat tokens
- Backups & migration

## Key Config Keys
- applications.commands

## Key Environment Variables
- OPENCLAW_STATE_DIR
- OPENCLAW_WORKSPACE_DIR
- OPENCLAW_GATEWAY_TOKEN

## Files And Paths
- /data/.openclaw`

## Related Source Code
- openclaw/src
- openclaw/docs/railway.mdx

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/railway