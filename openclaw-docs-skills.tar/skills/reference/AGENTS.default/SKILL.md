---
name: openclaw-docs-reference-AGENTS.default
description: Default OpenClaw agent instructions and skills roster for the personal assistant setup
metadata: {"openclaw":{"docPath":"reference/AGENTS.default","group":"Reference & Templates"}}
---

# reference/AGENTS.default

## Purpose
- Default OpenClaw agent instructions and skills roster for the personal assistant setup

## Read When
- Starting a new OpenClaw agent session
- Enabling or auditing default skills

## Topics Covered
- First run (recommended)
- Safety defaults
- Session start (required)
- Soul (required)
- Shared spaces (recommended)
- Memory system (recommended)
- Tools & skills
- Backup tip (recommended)

## Key Commands
```bash
mkdir -p ~/.openclaw/workspace
```

```bash
cp docs/reference/templates/AGENTS.md ~/.openclaw/workspace/AGENTS.md
cp docs/reference/templates/SOUL.md ~/.openclaw/workspace/SOUL.md
cp docs/reference/templates/TOOLS.md ~/.openclaw/workspace/TOOLS.md
```

```bash
cp docs/reference/AGENTS.default.md ~/.openclaw/workspace/AGENTS.md
```

```bash
cd ~/.openclaw/workspace
git init
git add AGENTS.md
git commit -m "Add Clawd workspace"
# Optional: add a private remote + push
```

## Key Config Snippets
```json
{
  agents: { defaults: { workspace: "~/.openclaw/workspace" } },
}
```

## Key Config Keys
- agents.defaults.workspace

## Files And Paths
- ~/.openclaw/workspace
- ~/.openclaw/workspace/AGENTS.md
- ~/.openclaw/workspace/SOUL.md
- ~/.openclaw/workspace/TOOLS.md

## Related Source Code
- openclaw/src
- openclaw/docs/reference/AGENTS.default.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/reference/AGENTS.default