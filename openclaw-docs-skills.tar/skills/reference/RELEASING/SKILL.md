---
name: openclaw-docs-reference-RELEASING
description: Step-by-step release checklist for npm + macOS app
metadata: {"openclaw":{"docPath":"reference/RELEASING","group":"Reference & Templates"}}
---

# reference/RELEASING

## Purpose
- Step-by-step release checklist for npm + macOS app

## Read When
- Cutting a new npm release
- Cutting a new macOS app release
- Verifying metadata before publishing

## Topics Covered
- Operator trigger
- Plugin publish scope (npm)

## Key Config Keys
- package.json
- openclaw.mjs
- appcast.xml

## Key Environment Variables
- OPENCLAW_INSTALL_SMOKE_SKIP_NONROOT
- OPENCLAW_INSTALL_SMOKE_PREVIOUS
- OPENCLAW_INSTALL_SMOKE_SKIP_PREVIOUS

## Files And Paths
- ~/.profile
- ~/Library/CloudStorage/Dropbox/Backup/Sparkle
- /tmp/npm-cache-$(date

## Related Source Code
- openclaw/src
- openclaw/docs/reference/RELEASING.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/reference/RELEASING