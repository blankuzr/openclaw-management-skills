---
name: openclaw-docs-reference-device-models
description: How OpenClaw vendors Apple device model identifiers for friendly names in the macOS app.
metadata: {"openclaw":{"docPath":"reference/device-models","group":"Reference & Templates"}}
---

# Device Model Database

## Purpose
- How OpenClaw vendors Apple device model identifiers for friendly names in the macOS app.

## Read When
- Updating device model identifier mappings or NOTICE/license files
- Changing how Instances UI displays device names

## Topics Covered
- Data source
- Updating the database

## Key Commands
```bash
IOS_COMMIT="<commit sha for ios-device-identifiers.json>"
MAC_COMMIT="<commit sha for mac-device-identifiers.json>"

curl -fsSL "https://raw.githubusercontent.com/kyle-seongwoo-jun/apple-device-identifiers/${IOS_COMMIT}/ios-device-identifiers.json" \
  -o apps/macos/Sources/OpenClaw/Resources/DeviceModels/ios-device-identifiers.json

curl -fsSL "https://raw.githubusercontent.com/kyle-seongwoo-jun/apple-device-identifiers/${MAC_COMMIT}/mac-device-identifiers.json" \
  -o apps/macos/Sources/OpenClaw/Resources/DeviceModels/mac-device-identifiers.json
```

```bash
swift build --package-path apps/macos
```

## Files And Paths
- //raw.githubusercontent.com/kyle-seongwoo-jun/apple-device-identifiers/${IOS_COMMIT}/ios-device-identifiers.json
- /macos/Sources/OpenClaw/Resources/DeviceModels/ios-device-identifiers.json
- //raw.githubusercontent.com/kyle-seongwoo-jun/apple-device-identifiers/${MAC_COMMIT}/mac-device-identifiers.json
- /macos/Sources/OpenClaw/Resources/DeviceModels/mac-device-identifiers.json

## Related Source Code
- openclaw/src
- openclaw/docs/reference/device-models.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/reference/device-models