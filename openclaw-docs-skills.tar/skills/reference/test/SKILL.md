---
name: openclaw-docs-reference-test
description: How to run tests locally (vitest) and when to use force/coverage modes
metadata: {"openclaw":{"docPath":"reference/test","group":"Reference & Templates"}}
---

# Tests

## Purpose
- How to run tests locally (vitest) and when to use force/coverage modes

## Read When
- Running or fixing tests

## Topics Covered
- Model latency bench (local keys)
- Onboarding E2E (Docker)
- QR import smoke (Docker)

## Key Commands
```bash
scripts/e2e/onboard-docker.sh
```

```bash
pnpm test:docker:qr
```

## Files And Paths
- ~/.profile

## Related Source Code
- openclaw/src
- openclaw/docs/reference/test.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/reference/test