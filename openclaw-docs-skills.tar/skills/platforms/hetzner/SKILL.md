---
name: openclaw-docs-platforms-hetzner
description: Run OpenClaw Gateway 24/7 on a cheap Hetzner VPS (Docker) with durable state and baked-in binaries
metadata: {"openclaw":{"docPath":"platforms/hetzner","group":"Platforms"}}
---

# Hetzner

## Purpose
- Run OpenClaw Gateway 24/7 on a cheap Hetzner VPS (Docker) with durable state and baked-in binaries

## Read When
- You want OpenClaw running 24/7 on a cloud VPS (not your laptop)
- You want a production-grade, always-on Gateway on your own VPS
- You want full control over persistence, binaries, and restart behavior
- You are running OpenClaw in Docker on Hetzner or a similar provider

## Topics Covered
- Goal
- What are we doing (simple terms)?
- Quick path (experienced operators)
- What you need
- 1) Provision the VPS
- 2) Install Docker (on the VPS)
- 3) Clone the OpenClaw repository
- 4) Create persistent host directories

## Key Commands
```bash
ssh root@YOUR_VPS_IP
```

```bash
apt-get update
apt-get install -y git curl ca-certificates
curl -fsSL https://get.docker.com | sh
```

```bash
docker --version
docker compose version
```

```bash
git clone https://github.com/openclaw/openclaw.git
cd openclaw
```

```bash
mkdir -p /root/.openclaw
mkdir -p /root/.openclaw/workspace

# Set ownership to the container user (uid 1000):
chown -R 1000:1000 /root/.openclaw
chown -R 1000:1000 /root/.openclaw/workspace
```

```bash
OPENCLAW_IMAGE=openclaw:latest
OPENCLAW_GATEWAY_TOKEN=change-me-now
OPENCLAW_GATEWAY_BIND=lan
OPENCLAW_GATEWAY_PORT=18789

OPENCLAW_CONFIG_DIR=/root/.openclaw
OPENCLAW_WORKSPACE_DIR=/root/.openclaw/workspace

GOG_KEYRING_PASSWORD=change-me-now
XDG_CONFIG_HOME=/home/node/.openclaw
```

## Key Config Snippets
```json
services:
  openclaw-gateway:
    image: ${OPENCLAW_IMAGE}
    build: .
    restart: unless-stopped
    env_file:
      - .env
    environment:
      - HOME=/home/node
      - NODE_ENV=production
      - TERM=xterm-256color
      - OPENCLAW_GATEWAY_BIND=${OPENCLAW_GATEWAY_BIND}
      - OPENCLAW_GATEWAY_PORT=${OPENCLAW_GATEWAY_PORT}
      - OPENCLAW_GATEWAY_TOKEN=${OPENCLAW_GATEWAY_TOKEN}
      - GOG_KEYRING_PASSWORD=${GOG_KEYRING_PASSWORD}
      - XDG_CONFIG_HOME=${XDG_CONFIG_HOME}
      - PATH=/home/linuxbrew/.linuxbrew/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
    volumes:
      - ${OPENCLAW_CONFIG_DIR}:/home/node/.openclaw
      - ${OPENCLAW_WORKSPACE_DIR}:/home/node/.openclaw/workspace
```

```json
[gateway] listening on ws://0.0.0.0:18789
```

## Key Environment Variables
- OPENCLAW_IMAGE
- OPENCLAW_GATEWAY_TOKEN
- OPENCLAW_GATEWAY_BIND
- OPENCLAW_GATEWAY_PORT
- OPENCLAW_CONFIG_DIR
- OPENCLAW_WORKSPACE_DIR

## Files And Paths
- ~/.openclaw
- ~/.openclaw/workspace
- /root/.openclaw
- /root/.openclaw/workspace
- /home/node/.openclaw
- /home/node/.openclaw/workspace
- /var/lib/apt/lists/*
- /package.json

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/hetzner.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/hetzner