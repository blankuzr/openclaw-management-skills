---
name: openclaw-docs-platforms-android
description: Android app (node): connection runbook + Canvas/Chat/Camera
metadata: {"openclaw":{"docPath":"platforms/android","group":"Platforms"}}
---

# Android App

## Purpose
- Android app (node): connection runbook + Canvas/Chat/Camera

## Read When
- Pairing or reconnecting the Android node
- Debugging Android gateway discovery or auth
- Verifying chat history parity across clients

## Topics Covered
- Support snapshot
- System control
- Connection Runbook

## Key Commands
```bash
openclaw gateway --port 18789 --verbose
```

```bash
dns-sd -B _openclaw-gw._tcp local.
```

```bash
openclaw nodes pending
openclaw nodes approve <requestId>
```

```bash
openclaw nodes status
```

```bash
openclaw gateway call node.list --params "{}"
```

```bash
openclaw nodes invoke --node "<Android Node>" --command canvas.navigate --params '{"url":"http://<gateway-hostname>.local:18793/__openclaw__/canvas/"}'
```

## Files And Paths
- ~/.openclaw/openclaw.json
- ~/.openclaw/workspace/canvas/index.html

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/android.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/android