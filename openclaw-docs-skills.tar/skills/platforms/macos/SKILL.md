---
name: openclaw-docs-platforms-macos
description: OpenClaw macOS companion app (menu bar + gateway broker)
metadata: {"openclaw":{"docPath":"platforms/macos","group":"Platforms"}}
---

# macOS App

## Purpose
- OpenClaw macOS companion app (menu bar + gateway broker)

## Read When
- Implementing macOS app features
- Changing gateway lifecycle or node bridging on macOS

## Topics Covered
- What it does
- Local vs remote mode
- Launchd control
- Node capabilities (mac)
- Exec approvals (system.run)
- Deep links
- Onboarding flow (typical)
- Build & dev workflow (native)

## Key Commands
```bash
launchctl kickstart -k gui/$UID/bot.molt.gateway
launchctl bootout gui/$UID/bot.molt.gateway
```

```bash
open 'openclaw://agent?message=Hello%20from%20deep%20link'
```

```bash
cd apps/macos
swift run openclaw-mac connect --json
swift run openclaw-mac discover --timeout 3000 --json
```

## Key Config Snippets
```json
{
  "version": 1,
  "defaults": {
    "security": "deny",
    "ask": "on-miss"
  },
  "agents": {
    "main": {
      "security": "allowlist",
      "ask": "on-miss",
      "allowlist": [{ "pattern": "/opt/homebrew/bin/rg" }]
    }
  }
}
```

## Key Config Keys
- system.run
- bot.molt.gateway

## Key Environment Variables
- OPENCLAW_PROFILE

## Files And Paths
- .openclaw.*`
- ~/.openclaw/exec-approvals.json

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/macos.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/macos