---
name: openclaw-docs-platforms-ios
description: iOS node app: connect to the Gateway, pairing, canvas, and troubleshooting
metadata: {"openclaw":{"docPath":"platforms/ios","group":"Platforms"}}
---

# iOS App

## Purpose
- iOS node app: connect to the Gateway, pairing, canvas, and troubleshooting

## Read When
- Pairing or reconnecting the iOS node
- Running the iOS app from source
- Debugging gateway discovery or canvas commands

## Topics Covered
- What it does
- Requirements
- Quick start (pair + connect)
- Discovery paths
- Canvas + A2UI
- Voice wake + talk mode
- Common errors
- Related docs

## Key Commands
```bash
openclaw gateway --port 18789
```

```bash
openclaw nodes pending
openclaw nodes approve <requestId>
```

```bash
openclaw nodes status
openclaw gateway call node.list --params "{}"
```

```bash
openclaw nodes invoke --node "iOS Node" --command canvas.navigate --params '{"url":"http://<gateway-host>:18793/__openclaw__/canvas/"}'
```

```bash
openclaw nodes invoke --node "iOS Node" --command canvas.eval --params '{"javaScript":"(() => { const {ctx} = window.__openclaw; ctx.clearRect(0,0,innerWidth,innerHeight); ctx.lineWidth=6; ctx.strokeStyle=\"#ff2d55\"; ctx.beginPath(); ctx.moveTo(40,40); ctx.lineTo(innerWidth-40, innerHeight-40); ctx.stroke(); return \"ok\"; })()"}'
```

```bash
openclaw nodes invoke --node "iOS Node" --command canvas.snapshot --params '{"maxWidth":900,"format":"jpeg"}'
```

## Key Config Keys
- node.invoke

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/ios.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/ios