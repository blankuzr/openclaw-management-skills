---
name: openclaw-docs-platforms-gcp
description: Run OpenClaw Gateway 24/7 on a GCP Compute Engine VM (Docker) with durable state
metadata: {"openclaw":{"docPath":"platforms/gcp","group":"Platforms"}}
---

# GCP

## Purpose
- Run OpenClaw Gateway 24/7 on a GCP Compute Engine VM (Docker) with durable state

## Read When
- You want OpenClaw running 24/7 on GCP
- You want a production-grade, always-on Gateway on your own VM
- You want full control over persistence, binaries, and restart behavior

## Topics Covered
- Goal
- What are we doing (simple terms)?
- Quick path (experienced operators)
- What you need
- 1) Install gcloud CLI (or use Console)
- 2) Create a GCP project
- 3) Create the VM
- 4) SSH into the VM

## Key Commands
```bash
gcloud init
gcloud auth login
```

```bash
gcloud projects create my-openclaw-project --name="OpenClaw Gateway"
gcloud config set project my-openclaw-project
```

```bash
gcloud services enable compute.googleapis.com
```

```bash
gcloud compute instances create openclaw-gateway \
  --zone=us-central1-a \
  --machine-type=e2-small \
  --boot-disk-size=20GB \
  --image-family=debian-12 \
  --image-project=debian-cloud
```

```bash
gcloud compute ssh openclaw-gateway --zone=us-central1-a
```

```bash
sudo apt-get update
sudo apt-get install -y git curl ca-certificates
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER
```

## Key Config Snippets
```json
services:
  openclaw-gateway:
    image: ${OPENCLAW_IMAGE}
    build: .
    restart: unless-stopped
    env_file:
      - .env
    environment:
      - HOME=/home/node
      - NODE_ENV=production
      - TERM=xterm-256color
      - OPENCLAW_GATEWAY_BIND=${OPENCLAW_GATEWAY_BIND}
      - OPENCLAW_GATEWAY_PORT=${OPENCLAW_GATEWAY_PORT}
      - OPENCLAW_GATEWAY_TOKEN=${OPENCLAW_GATEWAY_TOKEN}
      - GOG_KEYRING_PASSWORD=${GOG_KEYRING_PASSWORD}
      - XDG_CONFIG_HOME=${XDG_CONFIG_HOME}
      - PATH=/home/linuxbrew/.linuxbrew/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
    volumes:
      - ${OPENCLAW_CONFIG_DIR}:/home/node/.openclaw
      - ${OPENCLAW_WORKSPACE_DIR}:/home/node/.openclaw/workspace
```

```json
[gateway] listening on ws://0.0.0.0:18789
```

## Key Environment Variables
- OPENCLAW_IMAGE
- OPENCLAW_GATEWAY_TOKEN
- OPENCLAW_GATEWAY_BIND
- OPENCLAW_GATEWAY_PORT
- OPENCLAW_CONFIG_DIR
- OPENCLAW_WORKSPACE_DIR

## Files And Paths
- ~/.openclaw
- ~/.openclaw/workspace
- /home/$USER/.openclaw
- /home/$USER/.openclaw/workspace
- /home/node/.openclaw
- /home/node/.openclaw/workspace
- /var/lib/apt/lists/*
- /package.json

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/gcp.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/gcp