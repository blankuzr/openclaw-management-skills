---
name: openclaw-docs-platforms-mac-remote
description: macOS app flow for controlling a remote OpenClaw gateway over SSH
metadata: {"openclaw":{"docPath":"platforms/mac/remote","group":"macOS Companion App"}}
---

# Remote Control

## Purpose
- macOS app flow for controlling a remote OpenClaw gateway over SSH

## Read When
- Setting up or debugging remote mac control

## Topics Covered
- Modes
- Remote transports
- Prereqs on the remote host
- macOS app setup
- Web Chat
- Permissions
- Security notes
- WhatsApp login flow (remote)

## Key Commands
```bash
openclaw nodes notify --node <id> --title "Ping" --body "Remote gateway ready" --sound Glass
```

## Key Config Keys
- node.list
- node.describe
- node.invoke

## Files And Paths
- /etc/paths`,

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/mac/remote.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/mac/remote