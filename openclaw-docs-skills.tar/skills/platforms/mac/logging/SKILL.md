---
name: openclaw-docs-platforms-mac-logging
description: OpenClaw logging: rolling diagnostics file log + unified log privacy flags
metadata: {"openclaw":{"docPath":"platforms/mac/logging","group":"macOS Companion App"}}
---

# macOS Logging

## Purpose
- OpenClaw logging: rolling diagnostics file log + unified log privacy flags

## Read When
- Capturing macOS logs or investigating private data logging
- Debugging voice wake/session lifecycle issues

## Topics Covered
- Rolling diagnostics file log (Debug pane)
- Unified logging private data on macOS
- Enable for OpenClaw (`bot.molt`)
- Disable after debugging

## Key Commands
```bash
cat <<'EOF' >/tmp/bot.molt.plist
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>DEFAULT-OPTIONS</key>
    <dict>
        <key>Enable-Private-Data</key>
        <true/>
    </dict>
</dict>
</plist>
```

## Key Config Keys
- bot.molt

## Files And Paths
- ~/Library/Logs/OpenClaw/diagnostics.jsonl
- /tmp/bot.molt.plist

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/mac/logging.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/mac/logging