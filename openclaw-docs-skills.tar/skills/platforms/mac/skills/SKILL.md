---
name: openclaw-docs-platforms-mac-skills
description: macOS Skills settings UI and gateway-backed status
metadata: {"openclaw":{"docPath":"platforms/mac/skills","group":"macOS Companion App"}}
---

# Skills

## Purpose
- macOS Skills settings UI and gateway-backed status

## Read When
- Updating the macOS Skills settings UI
- Changing skills gating or install behavior

## Topics Covered
- Data source
- Install actions
- Env/API keys
- Remote mode

## Key Config Keys
- skills.status
- metadata.openclaw.requires
- metadata.openclaw.install
- skills.install
- skills.update

## Files And Paths
- .openclaw.requires`
- .openclaw.install`
- ~/.openclaw/openclaw.json

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/mac/skills.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/mac/skills