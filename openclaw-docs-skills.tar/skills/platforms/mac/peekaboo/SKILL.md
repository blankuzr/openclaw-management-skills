---
name: openclaw-docs-platforms-mac-peekaboo
description: PeekabooBridge integration for macOS UI automation
metadata: {"openclaw":{"docPath":"platforms/mac/peekaboo","group":"macOS Companion App"}}
---

# Peekaboo Bridge

## Purpose
- PeekabooBridge integration for macOS UI automation

## Read When
- Hosting PeekabooBridge in OpenClaw.app
- Integrating Peekaboo via Swift Package Manager
- Changing PeekabooBridge protocol/paths

## Topics Covered
- What this is (and isn't)
- Enable the bridge
- Client discovery order
- Security & permissions
- Snapshot behavior (automation)
- Troubleshooting

## Key Commands
```bash
export PEEKABOO_BRIDGE_SOCKET=/path/to/bridge.sock
```

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/mac/peekaboo.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/mac/peekaboo