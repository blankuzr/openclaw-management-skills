---
name: openclaw-docs-platforms-mac-menu-bar
description: Menu bar status logic and what is surfaced to users
metadata: {"openclaw":{"docPath":"platforms/mac/menu-bar","group":"macOS Companion App"}}
---

# Menu Bar

## Purpose
- Menu bar status logic and what is surfaced to users

## Read When
- Tweaking mac menu UI or status logic

## Topics Covered
- What is shown
- State model
- IconState enum (Swift)
- Status row text (menu)
- Event ingestion
- Debug override
- Testing checklist

## Key Config Keys
- node.list
- data.state
- data.phase
- args.command

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/mac/menu-bar.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/mac/menu-bar