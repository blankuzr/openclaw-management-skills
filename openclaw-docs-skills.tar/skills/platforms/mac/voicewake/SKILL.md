---
name: openclaw-docs-platforms-mac-voicewake
description: Voice wake and push-to-talk modes plus routing details in the mac app
metadata: {"openclaw":{"docPath":"platforms/mac/voicewake","group":"macOS Companion App"}}
---

# Voice Wake

## Purpose
- Voice wake and push-to-talk modes plus routing details in the mac app

## Read When
- Working on voice wake or PTT pathways

## Topics Covered
- Modes
- Runtime behavior (wake-word)
- Lifecycle invariants
- Sticky overlay failure mode (previous)
- Push-to-talk specifics
- User-facing settings
- Forwarding behavior
- Forwarding payload

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/mac/voicewake.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/mac/voicewake