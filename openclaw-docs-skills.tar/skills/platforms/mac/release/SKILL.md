---
name: openclaw-docs-platforms-mac-release
description: OpenClaw macOS release checklist (Sparkle feed, packaging, signing)
metadata: {"openclaw":{"docPath":"platforms/mac/release","group":"macOS Companion App"}}
---

# macOS Release

## Purpose
- OpenClaw macOS release checklist (Sparkle feed, packaging, signing)

## Read When
- Cutting or validating a OpenClaw macOS release
- Updating the Sparkle appcast or feed assets

## Topics Covered
- Prereqs
- Build & package
- Appcast entry
- Publish & verify

## Key Commands
```bash
# From repo root; set release IDs so Sparkle feed is enabled.
# APP_BUILD must be numeric + monotonic for Sparkle compare.
BUNDLE_ID=bot.molt.mac \
APP_VERSION=2026.2.1 \
APP_BUILD="$(git rev-list --count HEAD)" \
BUILD_CONFIG=release \
SIGN_IDENTITY="Developer ID Application: <Developer Name> (<TEAMID>)" \
scripts/package-mac-app.sh

# Zip for distribution (includes resource forks for Sparkle delta support)
ditto -c -k --sequesterRsrc --keepParent dist/OpenClaw.app dist/OpenClaw-2026.2.1.zip

```

```bash
SPARKLE_PRIVATE_KEY_FILE=/path/to/ed25519-private-key scripts/make_appcast.sh dist/OpenClaw-2026.2.1.zip https://raw.githubusercontent.com/openclaw/openclaw/main/appcast.xml
```

## Files And Paths
- ~/.profile
- /tmp/openclaw-notary.p8`
- /tmp/openclaw-notary.p8

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/mac/release.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/mac/release