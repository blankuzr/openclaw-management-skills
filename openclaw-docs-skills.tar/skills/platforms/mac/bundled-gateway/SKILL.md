---
name: openclaw-docs-platforms-mac-bundled-gateway
description: Gateway runtime on macOS (external launchd service)
metadata: {"openclaw":{"docPath":"platforms/mac/bundled-gateway","group":"macOS Companion App"}}
---

# Gateway on macOS

## Purpose
- Gateway runtime on macOS (external launchd service)

## Read When
- Packaging OpenClaw.app
- Debugging the macOS gateway launchd service
- Installing the gateway CLI for macOS

## Topics Covered
- Install the CLI (required for local mode)
- Launchd (Gateway as LaunchAgent)
- Version compatibility
- Smoke check

## Key Commands
```bash
npm install -g openclaw@<version>
```

```bash
openclaw --version

OPENCLAW_SKIP_CHANNELS=1 \
OPENCLAW_SKIP_CANVAS_HOST=1 \
openclaw gateway --port 18999 --bind loopback
```

```bash
openclaw gateway call health --url ws://127.0.0.1:18999 --timeout 3000
```

## Key Environment Variables
- OPENCLAW_SKIP_CHANNELS
- OPENCLAW_SKIP_CANVAS_HOST

## Files And Paths
- .openclaw.*`
- ~/Library/LaunchAgents/bot.molt.gateway.plist
- ~/Library/LaunchAgents/bot.molt.
- /tmp/openclaw/openclaw-gateway.log`

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/mac/bundled-gateway.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/mac/bundled-gateway