---
name: openclaw-docs-platforms-mac-xpc
description: macOS IPC architecture for OpenClaw app, gateway node transport, and PeekabooBridge
metadata: {"openclaw":{"docPath":"platforms/mac/xpc","group":"macOS Companion App"}}
---

# macOS IPC

## Purpose
- macOS IPC architecture for OpenClaw app, gateway node transport, and PeekabooBridge

## Read When
- Editing IPC contracts or menu bar app IPC

## Topics Covered
- Goals
- How it works
- Operational flows
- Hardening notes

## Key Config Keys
- system.run
- node.invoke
- system.notify

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/mac/xpc.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/mac/xpc