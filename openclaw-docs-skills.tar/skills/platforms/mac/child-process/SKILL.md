---
name: openclaw-docs-platforms-mac-child-process
description: Gateway lifecycle on macOS (launchd)
metadata: {"openclaw":{"docPath":"platforms/mac/child-process","group":"macOS Companion App"}}
---

# Gateway Lifecycle

## Purpose
- Gateway lifecycle on macOS (launchd)

## Read When
- Integrating the mac app with the gateway lifecycle

## Topics Covered
- Default behavior (launchd)
- Unsigned dev builds
- Attach-only mode
- Remote mode
- Why we prefer launchd

## Key Commands
```bash
launchctl kickstart -k gui/$UID/bot.molt.gateway
launchctl bootout gui/$UID/bot.molt.gateway
```

```bash
rm ~/.openclaw/disable-launchagent
```

## Key Config Keys
- bot.molt.gateway

## Key Environment Variables
- OPENCLAW_PROFILE

## Files And Paths
- .openclaw.*`
- ~/.openclaw/disable-launchagent

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/mac/child-process.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/mac/child-process