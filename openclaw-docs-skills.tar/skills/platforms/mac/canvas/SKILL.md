---
name: openclaw-docs-platforms-mac-canvas
description: Agent-controlled Canvas panel embedded via WKWebView + custom URL scheme
metadata: {"openclaw":{"docPath":"platforms/mac/canvas","group":"macOS Companion App"}}
---

# Canvas

## Purpose
- Agent-controlled Canvas panel embedded via WKWebView + custom URL scheme

## Read When
- Implementing the macOS Canvas panel
- Adding agent controls for visual workspace
- Debugging WKWebView canvas loads

## Topics Covered
- Where Canvas lives
- Panel behavior
- Agent API surface
- A2UI in Canvas
- Triggering agent runs from Canvas
- Security notes

## Key Commands
```bash
openclaw nodes canvas present --node <id>
openclaw nodes canvas navigate --node <id> --url "/"
openclaw nodes canvas eval --node <id> --js "document.title"
openclaw nodes canvas snapshot --node <id>
```

```bash
cat > /tmp/a2ui-v0.8.jsonl <<'EOFA2'
{"surfaceUpdate":{"surfaceId":"main","components":[{"id":"root","component":{"Column":{"children":{"explicitList":["title","content"]}}}},{"id":"title","component":{"Text":{"text":{"literalString":"Canvas (A2UI v0.8)"},"usageHint":"h1"}}},{"id":"content","component":{"Text":{"text":{"literalString":"If you can read this, A2UI push works."},"usageHint":"body"}}}]}}
{"beginRendering":{"surfaceId":"main","root":"root"}}
EOFA2

openclaw nodes canvas a2ui push --jsonl /tmp/a2ui-v0.8.jsonl --node <id>
```

```bash
openclaw nodes canvas a2ui push --node <id> --text "Hello from A2UI"
```

## Key Config Keys
- index.html

## Files And Paths
- ~/Library/Application
- /tmp/a2ui-v0.8.jsonl

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/mac/canvas.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/mac/canvas