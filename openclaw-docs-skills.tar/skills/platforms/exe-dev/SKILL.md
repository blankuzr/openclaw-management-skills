---
name: openclaw-docs-platforms-exe-dev
description: Run OpenClaw Gateway on exe.dev (VM + HTTPS proxy) for remote access
metadata: {"openclaw":{"docPath":"platforms/exe-dev","group":"Platforms"}}
---

# exe.dev

## Purpose
- Run OpenClaw Gateway on exe.dev (VM + HTTPS proxy) for remote access

## Read When
- You want a cheap always-on Linux host for the Gateway
- You want remote Control UI access without running your own VPS

## Topics Covered
- Beginner quick path
- What you need
- Automated Install with Shelley
- Manual installation
- 1) Create the VM
- 2) Install prerequisites (on the VM)
- 3) Install OpenClaw
- 4) Setup nginx to proxy OpenClaw to port 8000

## Key Commands
```bash
ssh exe.dev new
```

```bash
ssh <vm-name>.exe.xyz
```

```bash
sudo apt-get update
sudo apt-get install -y git curl jq ca-certificates openssl
```

```bash
curl -fsSL https://openclaw.ai/install.sh | bash
```

```bash
npm i -g openclaw@latest
openclaw doctor
openclaw gateway restart
openclaw health
```

## Files And Paths
- //docs.openclaw.ai/install)
- ~/.openclaw/
- ~/.openclaw/workspace/
- /etc/nginx/sites-enabled/default`

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/exe-dev.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/exe-dev