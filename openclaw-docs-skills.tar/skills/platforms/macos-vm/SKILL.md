---
name: openclaw-docs-platforms-macos-vm
description: Run OpenClaw in a sandboxed macOS VM (local or hosted) when you need isolation or iMessage
metadata: {"openclaw":{"docPath":"platforms/macos-vm","group":"Platforms"}}
---

# macOS VMs

## Purpose
- Run OpenClaw in a sandboxed macOS VM (local or hosted) when you need isolation or iMessage

## Read When
- You want OpenClaw isolated from your main macOS environment
- You want iMessage integration (BlueBubbles) in a sandbox
- You want a resettable macOS environment you can clone
- You want to compare local vs hosted macOS VM options

## Topics Covered
- Recommended default (most users)
- macOS VM options
- Quick path (Lume, experienced users)
- What you need (Lume)
- 1) Install Lume
- 2) Create the macOS VM
- 3) Complete Setup Assistant
- 4) Get the VM's IP address

## Key Commands
```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/trycua/cua/main/libs/lume/scripts/install.sh)"
```

```bash
echo 'export PATH="$PATH:$HOME/.local/bin"' >> ~/.zshrc && source ~/.zshrc
```

```bash
lume --version
```

```bash
lume create openclaw --os macos --ipsw latest
```

```bash
lume get openclaw
```

```bash
ssh youruser@192.168.64.X
```

## Key Config Snippets
```json
{
  "channels": {
    "whatsapp": {
      "dmPolicy": "allowlist",
      "allowFrom": ["+15551234567"]
    },
    "telegram": {
      "botToken": "YOUR_BOT_TOKEN"
    }
  }
}
```

```json
{
  "channels": {
    "bluebubbles": {
      "serverUrl": "http://localhost:1234",
      "password": "your-api-password",
      "webhookPath": "/bluebubbles-webhook"
    }
  }
}
```

## Files And Paths
- ~/.local/bin
- ~/.zshrc
- ~/.openclaw/openclaw.json

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/macos-vm.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/macos-vm