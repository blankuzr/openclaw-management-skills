---
name: openclaw-docs-platforms-windows
description: Windows (WSL2) support + companion app status
metadata: {"openclaw":{"docPath":"platforms/windows","group":"Platforms"}}
---

# Windows (WSL2)

## Purpose
- Windows (WSL2) support + companion app status

## Read When
- Installing OpenClaw on Windows
- Looking for Windows companion app status

## Topics Covered
- Install (WSL2)
- Gateway
- Gateway service install (CLI)
- Advanced: expose WSL services over LAN (portproxy)
- Step-by-step WSL2 install
- Windows companion app

## Key Commands
```bash
openclaw onboard --install-daemon
```

```bash
openclaw gateway install
```

```bash
openclaw configure
```

```bash
openclaw doctor
```

```bash
$Distro = "Ubuntu-24.04"
$ListenPort = 2222
$TargetPort = 22

$WslIp = (wsl -d $Distro -- hostname -I).Trim().Split(" ")[0]
if (-not $WslIp) { throw "WSL IP not found." }

netsh interface portproxy add v4tov4 listenaddress=0.0.0.0 listenport=$ListenPort `
  connectaddress=$WslIp connectport=$TargetPort
```

```bash
New-NetFirewallRule -DisplayName "WSL SSH $ListenPort" -Direction Inbound `
  -Protocol TCP -LocalPort $ListenPort -Action Allow
```

## Files And Paths
- /etc/wsl.conf

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/windows.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/windows