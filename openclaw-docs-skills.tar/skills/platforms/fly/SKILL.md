---
name: openclaw-docs-platforms-fly
description: Guidance for the OpenClaw docs section: platforms/fly.
metadata: {"openclaw":{"docPath":"platforms/fly","group":"Platforms"}}
---

# Fly.io

## Purpose
- Guidance for the OpenClaw docs section: platforms/fly.

## Topics Covered
- What you need
- Beginner quick path
- 1) Create the Fly app
- 2) Configure fly.toml
- 3) Set secrets
- 4) Deploy
- 5) Create config file
- 6) Access the Gateway

## Key Commands
```bash
# Clone the repo
git clone https://github.com/openclaw/openclaw.git
cd openclaw

# Create a new Fly app (pick your own name)
fly apps create my-openclaw

# Create a persistent volume (1GB is usually enough)
fly volumes create openclaw_data --size 1 --region iad
```

```bash
# Required: Gateway token (for non-loopback binding)
fly secrets set OPENCLAW_GATEWAY_TOKEN=$(openssl rand -hex 32)

# Model provider API keys
fly secrets set ANTHROPIC_API_KEY=sk-ant-...

# Optional: Other providers
fly secrets set OPENAI_API_KEY=sk-...
fly secrets set GOOGLE_API_KEY=...

# Channel tokens
fly secrets set DISCORD_BOT_TOKEN=MTQ...
```

```bash
fly deploy
```

```bash
fly status
fly logs
```

```bash
fly ssh console
```

```bash
mkdir -p /data
cat > /data/openclaw.json << 'EOF'
{
  "agents": {
    "defaults": {
      "model": {
        "primary": "anthropic/claude-opus-4-5",
        "fallbacks": ["anthropic/claude-sonnet-4-5", "openai/gpt-4o"]
      },
      "maxConcurrent": 4
    },
    "list": [
```

## Key Config Snippets
```json
app = "my-openclaw"  # Your app name
primary_region = "iad"

[build]
  dockerfile = "Dockerfile"

[env]
  NODE_ENV = "production"
  OPENCLAW_PREFER_PNPM = "1"
  OPENCLAW_STATE_DIR = "/data"
  NODE_OPTIONS = "--max-old-space-size=1536"

[processes]
  app = "node dist/index.js gateway --allow-unconfigured --port 3000 --bind lan"

[http_service]
  internal_port = 3000
  force_https = true
  auto_stop_machines = false
  auto_start_machines = true
```

```json
[gateway] listening on ws://0.0.0.0:3000 (PID xxx)
[discord] logged in to discord as xxx
```

## Key Config Keys
- fly.toml

## Key Environment Variables
- OPENCLAW_PREFER_PNPM
- OPENCLAW_STATE_DIR
- OPENCLAW_GATEWAY_PORT
- OPENCLAW_GATEWAY_TOKEN

## Files And Paths
- /data/openclaw.json
- /data/openclaw.json`.
- /data/openclaw.json`
- /local/path/config.json

## Related Source Code
- openclaw/src
- openclaw/docs/platforms/fly.md
- openclaw/apps
- openclaw/src/macos
- openclaw/ui

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/platforms/fly