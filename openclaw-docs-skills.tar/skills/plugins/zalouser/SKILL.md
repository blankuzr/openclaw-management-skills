---
name: openclaw-docs-plugins-zalouser
description: Zalo Personal plugin: QR login + messaging via zca-cli (plugin install + channel config + CLI + tool)
metadata: {"openclaw":{"docPath":"plugins/zalouser","group":"Tools & Skills"}}
---

# Zalo Personal Plugin

## Purpose
- Zalo Personal plugin: QR login + messaging via zca-cli (plugin install + channel config + CLI + tool)

## Read When
- You want Zalo Personal (unofficial) support in OpenClaw
- You are configuring or developing the zalouser plugin

## Topics Covered
- Naming
- Where it runs
- Install
- Prerequisite: zca-cli
- Config
- CLI
- Agent tool

## Key Commands
```bash
openclaw plugins install @openclaw/zalouser
```

```bash
openclaw plugins install ./extensions/zalouser
cd ./extensions/zalouser && pnpm install
```

```bash
zca --version
```

```bash
openclaw channels login --channel zalouser
openclaw channels logout --channel zalouser
openclaw channels status --probe
openclaw message send --channel zalouser --target <threadId> --message "Hello from OpenClaw"
openclaw directory peers list --channel zalouser --query "name"
```

## Key Config Snippets
```json
{
  channels: {
    zalouser: {
      enabled: true,
      dmPolicy: "pairing",
    },
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/plugins/zalouser.md
- openclaw/extensions
- openclaw/src/plugins
- openclaw/src/plugin-sdk

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/plugins/zalouser