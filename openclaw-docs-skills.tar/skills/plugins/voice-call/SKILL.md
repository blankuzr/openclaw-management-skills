---
name: openclaw-docs-plugins-voice-call
description: Voice Call plugin: outbound + inbound calls via Twilio/Telnyx/Plivo (plugin install + config + CLI)
metadata: {"openclaw":{"docPath":"plugins/voice-call","group":"Tools & Skills"}}
---

# Voice Call Plugin

## Purpose
- Voice Call plugin: outbound + inbound calls via Twilio/Telnyx/Plivo (plugin install + config + CLI)

## Read When
- You want to place an outbound voice call from OpenClaw
- You are configuring or developing the voice-call plugin

## Topics Covered
- Where it runs (local vs remote)
- Install
- Config
- TTS for calls
- Inbound calls
- CLI
- Agent tool
- Gateway RPC

## Key Commands
```bash
openclaw plugins install @openclaw/voice-call
```

```bash
openclaw plugins install ./extensions/voice-call
cd ./extensions/voice-call && pnpm install
```

```bash
openclaw voicecall call --to "+15555550123" --message "Hello from OpenClaw"
openclaw voicecall continue --call-id <id> --message "Any questions?"
openclaw voicecall speak --call-id <id> --message "One moment"
openclaw voicecall end --call-id <id>
openclaw voicecall status --call-id <id>
openclaw voicecall tail
openclaw voicecall expose --mode funnel
```

## Key Config Snippets
```json
{
  plugins: {
    entries: {
      "voice-call": {
        enabled: true,
        config: {
          provider: "twilio", // or "telnyx" | "plivo" | "mock"
          fromNumber: "+15550001234",
          toNumber: "+15550005678",

          twilio: {
            accountSid: "ACxxxxxxxx",
            authToken: "...",
          },

          plivo: {
            authId: "MAxxxxxxxxxxxxxxxxxxxx",
            authToken: "...",
          },

```

```json
{
  tts: {
    provider: "elevenlabs",
    elevenlabs: {
      voiceId: "pMsXgVXv3BLzUgSXRplE",
      modelId: "eleven_multilingual_v2",
    },
  },
}
```

## Key Config Keys
- plugins.entries.voice-call.config

## Related Source Code
- openclaw/src
- openclaw/docs/plugins/voice-call.md
- openclaw/extensions
- openclaw/src/plugins
- openclaw/src/plugin-sdk

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/plugins/voice-call