---
name: openclaw-docs-multi-agent-sandbox-tools
description: Per-agent sandbox + tool restrictions, precedence, and examples
metadata: {"openclaw":{"docPath":"multi-agent-sandbox-tools","group":"Tools & Skills"}}
---

# Multi-Agent Sandbox & Tools

## Purpose
- Per-agent sandbox + tool restrictions, precedence, and examples

## Topics Covered
- Overview
- Configuration Examples
- Configuration Precedence
- Migration from Single Agent
- Tool Restriction Examples
- Common Pitfall: "non-main"
- Testing
- Troubleshooting

## Key Commands
```bash
openclaw agents list --bindings
```

## Key Config Snippets
```json
{
  "agents": {
    "list": [
      {
        "id": "main",
        "default": true,
        "name": "Personal Assistant",
        "workspace": "~/.openclaw/workspace",
        "sandbox": { "mode": "off" }
      },
      {
        "id": "family",
        "name": "Family Bot",
        "workspace": "~/.openclaw/workspace-family",
        "sandbox": {
          "mode": "all",
          "scope": "agent"
        },
        "tools": {
          "allow": ["read"],
```

```json
{
  "agents": {
    "list": [
      {
        "id": "personal",
        "workspace": "~/.openclaw/workspace-personal",
        "sandbox": { "mode": "off" }
      },
      {
        "id": "work",
        "workspace": "~/.openclaw/workspace-work",
        "sandbox": {
          "mode": "all",
          "scope": "shared",
          "workspaceRoot": "/tmp/work-sandboxes"
        },
        "tools": {
          "allow": ["read", "write", "apply_patch", "exec"],
          "deny": ["browser", "gateway", "discord"]
        }
```

## Key Config Keys
- agents.defaults.sandbox
- tools.allow
- tools.deny
- sandbox.docker

## Key Environment Variables
- OPENCLAW_STATE_DIR

## Files And Paths
- ~/.openclaw/agents/
- /agent/auth-profiles.json
- ~/.openclaw/workspace
- ~/.openclaw/workspace-family
- ~/.openclaw/workspace-personal
- ~/.openclaw/workspace-work
- /tmp/work-sandboxes
- ~/.openclaw/workspace-public

## Related Source Code
- openclaw/src
- openclaw/docs/multi-agent-sandbox-tools.md

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/multi-agent-sandbox-tools