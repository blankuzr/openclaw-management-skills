---
name: openclaw-docs-cli-index
description: OpenClaw CLI reference for `openclaw` commands, subcommands, and options
metadata: {"openclaw":{"docPath":"cli/index","group":"CLI"}}
---

# CLI Reference

## Purpose
- OpenClaw CLI reference for `openclaw` commands, subcommands, and options

## Read When
- Adding or modifying CLI commands or options
- Documenting new command surfaces

## Topics Covered
- Command pages
- Global flags
- Output styling
- Color palette
- Command tree
- Security
- Plugins
- Memory

## Key Commands
```bash
openclaw [--dev] [--profile <name>] <command>
  setup
  onboard
  configure
  config
    get
    set
    unset
  doctor
  security
    audit
  reset
```

```bash
openclaw channels add --channel telegram --account alerts --name "Alerts Bot" --token $TELEGRAM_BOT_TOKEN
openclaw channels add --channel discord --account work --name "Work Bot" --token $DISCORD_BOT_TOKEN
openclaw channels remove --channel discord --account work --delete
openclaw channels status --probe
openclaw status --deep
```

```bash
openclaw logs --follow
openclaw logs --limit 200
openclaw logs --plain
openclaw logs --json
openclaw logs --no-color
```

```bash
claude setup-token
openclaw models auth setup-token --provider anthropic
openclaw models status
```

## Files And Paths
- ~/.openclaw-dev
- ~/.openclaw-
- ~/.openclaw/workspace

## Related Source Code
- openclaw/src
- openclaw/docs/cli/index.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/index