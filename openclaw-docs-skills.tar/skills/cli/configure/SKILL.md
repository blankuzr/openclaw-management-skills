---
name: openclaw-docs-cli-configure
description: CLI reference for `openclaw configure` (interactive configuration prompts)
metadata: {"openclaw":{"docPath":"cli/configure","group":"CLI"}}
---

# configure

## Purpose
- CLI reference for `openclaw configure` (interactive configuration prompts)

## Read When
- You want to tweak credentials, devices, or agent defaults interactively

## Topics Covered
- Examples

## Key Commands
```bash
openclaw configure
openclaw configure --section models --section channels
```

## Key Config Keys
- agents.defaults.models
- gateway.mode

## Related Source Code
- openclaw/src
- openclaw/docs/cli/configure.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/configure