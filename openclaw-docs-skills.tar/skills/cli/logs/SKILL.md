---
name: openclaw-docs-cli-logs
description: CLI reference for `openclaw logs` (tail gateway logs via RPC)
metadata: {"openclaw":{"docPath":"cli/logs","group":"CLI"}}
---

# logs

## Purpose
- CLI reference for `openclaw logs` (tail gateway logs via RPC)

## Read When
- You need to tail Gateway logs remotely (without SSH)
- You want JSON log lines for tooling

## Topics Covered
- Examples

## Key Commands
```bash
openclaw logs
openclaw logs --follow
openclaw logs --json
openclaw logs --limit 500
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/logs.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/logs