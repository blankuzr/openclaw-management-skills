---
name: openclaw-docs-cli-doctor
description: CLI reference for `openclaw doctor` (health checks + guided repairs)
metadata: {"openclaw":{"docPath":"cli/doctor","group":"CLI"}}
---

# doctor

## Purpose
- CLI reference for `openclaw doctor` (health checks + guided repairs)

## Read When
- You have connectivity/auth issues and want guided fixes
- You updated and want a sanity check

## Topics Covered
- Examples
- macOS: `launchctl` env overrides

## Key Commands
```bash
openclaw doctor
openclaw doctor --repair
openclaw doctor --deep
```

```bash
launchctl getenv OPENCLAW_GATEWAY_TOKEN
launchctl getenv OPENCLAW_GATEWAY_PASSWORD

launchctl unsetenv OPENCLAW_GATEWAY_TOKEN
launchctl unsetenv OPENCLAW_GATEWAY_PASSWORD
```

## Key Environment Variables
- OPENCLAW_GATEWAY_TOKEN
- OPENCLAW_GATEWAY_PASSWORD

## Files And Paths
- ~/.openclaw/openclaw.json.bak

## Related Source Code
- openclaw/src
- openclaw/docs/cli/doctor.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/doctor