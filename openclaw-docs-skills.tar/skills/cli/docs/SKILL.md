---
name: openclaw-docs-cli-docs
description: CLI reference for `openclaw docs` (search the live docs index)
metadata: {"openclaw":{"docPath":"cli/docs","group":"CLI"}}
---

# docs

## Purpose
- CLI reference for `openclaw docs` (search the live docs index)

## Read When
- You want to search the live OpenClaw docs from the terminal

## Key Commands
```bash
openclaw docs browser extension
openclaw docs sandbox allowHostControl
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/docs.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/docs