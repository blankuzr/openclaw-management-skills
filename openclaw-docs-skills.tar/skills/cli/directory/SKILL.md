---
name: openclaw-docs-cli-directory
description: CLI reference for `openclaw directory` (self, peers, groups)
metadata: {"openclaw":{"docPath":"cli/directory","group":"CLI"}}
---

# directory

## Purpose
- CLI reference for `openclaw directory` (self, peers, groups)

## Read When
- You want to look up contacts/groups/self ids for a channel
- You are developing a channel directory adapter

## Topics Covered
- Common flags
- Notes
- Using results with `message send`
- ID formats (by channel)
- Self ("me")
- Peers (contacts/users)
- Groups

## Key Commands
```bash
openclaw directory peers list --channel slack --query "U0"
openclaw message send --channel slack --target user:U012ABCDEF --message "hello"
```

```bash
openclaw directory self --channel zalouser
```

```bash
openclaw directory peers list --channel zalouser
openclaw directory peers list --channel zalouser --query "name"
openclaw directory peers list --channel zalouser --limit 50
```

```bash
openclaw directory groups list --channel zalouser
openclaw directory groups list --channel zalouser --query "work"
openclaw directory groups members --channel zalouser --group-id <id>
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/directory.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/directory