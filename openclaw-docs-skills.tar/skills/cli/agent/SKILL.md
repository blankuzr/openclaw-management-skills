---
name: openclaw-docs-cli-agent
description: CLI reference for `openclaw agent` (send one agent turn via the Gateway)
metadata: {"openclaw":{"docPath":"cli/agent","group":"CLI"}}
---

# agent

## Purpose
- CLI reference for `openclaw agent` (send one agent turn via the Gateway)

## Read When
- You want to run one agent turn from scripts (optionally deliver reply)

## Topics Covered
- Examples

## Key Commands
```bash
openclaw agent --to +15555550123 --message "status update" --deliver
openclaw agent --agent ops --message "Summarize logs"
openclaw agent --session-id 1234 --message "Summarize inbox" --thinking medium
openclaw agent --agent ops --message "Generate report" --deliver --reply-channel slack --reply-to "#reports"
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/agent.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/agent