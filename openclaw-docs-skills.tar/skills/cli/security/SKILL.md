---
name: openclaw-docs-cli-security
description: CLI reference for `openclaw security` (audit and fix common security footguns)
metadata: {"openclaw":{"docPath":"cli/security","group":"CLI"}}
---

# security

## Purpose
- CLI reference for `openclaw security` (audit and fix common security footguns)

## Read When
- You want to run a quick security audit on config/state
- You want to apply safe "fix" suggestions (chmod, tighten defaults)

## Topics Covered
- Audit

## Key Commands
```bash
openclaw security audit
openclaw security audit --deep
openclaw security audit --fix
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/security.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/security