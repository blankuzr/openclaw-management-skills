---
name: openclaw-docs-cli-status
description: CLI reference for `openclaw status` (diagnostics, probes, usage snapshots)
metadata: {"openclaw":{"docPath":"cli/status","group":"CLI"}}
---

# status

## Purpose
- CLI reference for `openclaw status` (diagnostics, probes, usage snapshots)

## Read When
- You want a quick diagnosis of channel health + recent session recipients
- You want a pasteable "all" status for debugging

## Key Commands
```bash
openclaw status
openclaw status --all
openclaw status --deep
openclaw status --usage
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/status.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/status