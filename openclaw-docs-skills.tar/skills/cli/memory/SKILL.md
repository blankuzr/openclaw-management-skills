---
name: openclaw-docs-cli-memory
description: CLI reference for `openclaw memory` (status/index/search)
metadata: {"openclaw":{"docPath":"cli/memory","group":"CLI"}}
---

# memory

## Purpose
- CLI reference for `openclaw memory` (status/index/search)

## Read When
- You want to index or search semantic memory
- You're debugging memory availability or indexing

## Topics Covered
- Examples
- Options

## Key Commands
```bash
openclaw memory status
openclaw memory status --deep
openclaw memory status --deep --index
openclaw memory status --deep --index --verbose
openclaw memory index
openclaw memory index --verbose
openclaw memory search "release checklist"
openclaw memory status --agent main
openclaw memory index --agent main --verbose
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/memory.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/memory