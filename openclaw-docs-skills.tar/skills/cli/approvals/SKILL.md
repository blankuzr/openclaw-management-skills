---
name: openclaw-docs-cli-approvals
description: CLI reference for `openclaw approvals` (exec approvals for gateway or node hosts)
metadata: {"openclaw":{"docPath":"cli/approvals","group":"CLI"}}
---

# approvals

## Purpose
- CLI reference for `openclaw approvals` (exec approvals for gateway or node hosts)

## Read When
- You want to edit exec approvals from the CLI
- You need to manage allowlists on gateway or node hosts

## Topics Covered
- Common commands
- Replace approvals from a file
- Allowlist helpers
- Notes

## Key Commands
```bash
openclaw approvals get
openclaw approvals get --node <id|name|ip>
openclaw approvals get --gateway
```

```bash
openclaw approvals set --file ./exec-approvals.json
openclaw approvals set --node <id|name|ip> --file ./exec-approvals.json
openclaw approvals set --gateway --file ./exec-approvals.json
```

```bash
openclaw approvals allowlist add "~/Projects/**/bin/rg"
openclaw approvals allowlist add --agent main --node <id|name|ip> "/usr/bin/uptime"
openclaw approvals allowlist add --agent "*" "/usr/bin/uname"

openclaw approvals allowlist remove "~/Projects/**/bin/rg"
```

## Files And Paths
- /exec-approvals.json
- ~/Projects/
- ~/.openclaw/exec-approvals.json

## Related Source Code
- openclaw/src
- openclaw/docs/cli/approvals.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/approvals