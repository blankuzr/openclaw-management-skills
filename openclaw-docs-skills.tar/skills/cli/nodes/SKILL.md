---
name: openclaw-docs-cli-nodes
description: CLI reference for `openclaw nodes` (list/status/approve/invoke, camera/canvas/screen)
metadata: {"openclaw":{"docPath":"cli/nodes","group":"CLI"}}
---

# nodes

## Purpose
- CLI reference for `openclaw nodes` (list/status/approve/invoke, camera/canvas/screen)

## Read When
- You're managing paired nodes (cameras, screen, canvas)
- You need to approve requests or invoke node commands

## Topics Covered
- Common commands
- Invoke / run

## Key Commands
```bash
openclaw nodes list
openclaw nodes list --connected
openclaw nodes list --last-connected 24h
openclaw nodes pending
openclaw nodes approve <requestId>
openclaw nodes status
openclaw nodes status --connected
openclaw nodes status --last-connected 24h
```

```bash
openclaw nodes invoke --node <id|name|ip> --command <command> --params <json>
openclaw nodes run --node <id|name|ip> <command...>
openclaw nodes run --raw "git status"
openclaw nodes run --agent main --node <id|name|ip> --raw "git status"
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/nodes.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/nodes