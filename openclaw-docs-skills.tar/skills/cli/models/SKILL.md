---
name: openclaw-docs-cli-models
description: CLI reference for `openclaw models` (status/list/set/scan, aliases, fallbacks, auth)
metadata: {"openclaw":{"docPath":"cli/models","group":"CLI"}}
---

# models

## Purpose
- CLI reference for `openclaw models` (status/list/set/scan, aliases, fallbacks, auth)

## Read When
- You want to change default models or view provider auth status
- You want to scan available models/providers and debug auth profiles

## Topics Covered
- Common commands
- Aliases + fallbacks
- Auth profiles

## Key Commands
```bash
openclaw models status
openclaw models list
openclaw models set <model-or-alias>
openclaw models scan
```

```bash
openclaw models aliases list
openclaw models fallbacks list
```

```bash
openclaw models auth add
openclaw models auth login --provider <id>
openclaw models auth setup-token
openclaw models auth paste-token
```

## Key Environment Variables
- OPENCLAW_AGENT_DIR
- PI_CODING_AGENT_DIR

## Related Source Code
- openclaw/src
- openclaw/docs/cli/models.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/models