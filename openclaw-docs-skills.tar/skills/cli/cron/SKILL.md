---
name: openclaw-docs-cli-cron
description: CLI reference for `openclaw cron` (schedule and run background jobs)
metadata: {"openclaw":{"docPath":"cli/cron","group":"CLI"}}
---

# cron

## Purpose
- CLI reference for `openclaw cron` (schedule and run background jobs)

## Read When
- You want scheduled jobs and wakeups
- You're debugging cron execution and logs

## Topics Covered
- Common edits

## Key Commands
```bash
openclaw cron edit <job-id> --deliver --channel telegram --to "123456789"
```

```bash
openclaw cron edit <job-id> --no-deliver
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/cron.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/cron