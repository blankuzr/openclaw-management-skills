---
name: openclaw-docs-cli-hooks
description: CLI reference for `openclaw hooks` (agent hooks)
metadata: {"openclaw":{"docPath":"cli/hooks","group":"CLI"}}
---

# hooks

## Purpose
- CLI reference for `openclaw hooks` (agent hooks)

## Read When
- You want to manage agent hooks
- You want to install or update hooks

## Topics Covered
- List All Hooks
- Get Hook Information
- Check Hooks Eligibility
- Enable a Hook
- Disable a Hook
- Install Hooks
- Update Hooks
- Bundled Hooks

## Key Commands
```bash
openclaw hooks list
```

```bash
openclaw hooks list --verbose
```

```bash
openclaw hooks list --json
```

```bash
openclaw hooks info <name>
```

```bash
openclaw hooks info session-memory
```

```bash
openclaw hooks check
```

## Files And Paths
- //docs.openclaw.ai/hooks#session-memory
- ~/.openclaw/config.json
- ~/.openclaw/hooks/
- ~/.openclaw/workspace/memory/YYYY-MM-DD-slug.md
- ~/.openclaw/logs/commands.log

## Related Source Code
- openclaw/src
- openclaw/docs/cli/hooks.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/hooks