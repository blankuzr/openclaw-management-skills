---
name: openclaw-docs-cli-health
description: CLI reference for `openclaw health` (gateway health endpoint via RPC)
metadata: {"openclaw":{"docPath":"cli/health","group":"CLI"}}
---

# health

## Purpose
- CLI reference for `openclaw health` (gateway health endpoint via RPC)

## Read When
- You want to quickly check the running Gateway's health

## Key Commands
```bash
openclaw health
openclaw health --json
openclaw health --verbose
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/health.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/health