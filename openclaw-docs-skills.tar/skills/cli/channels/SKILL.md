---
name: openclaw-docs-cli-channels
description: CLI reference for `openclaw channels` (accounts, status, login/logout, logs)
metadata: {"openclaw":{"docPath":"cli/channels","group":"CLI"}}
---

# channels

## Purpose
- CLI reference for `openclaw channels` (accounts, status, login/logout, logs)

## Read When
- You want to add/remove channel accounts (WhatsApp/Telegram/Discord/Google Chat/Slack/Mattermost (plugin)/Signal/iMessage)
- You want to check channel status or tail channel logs

## Topics Covered
- Common commands
- Add / remove accounts
- Login / logout (interactive)
- Troubleshooting
- Capabilities probe
- Resolve names to IDs

## Key Commands
```bash
openclaw channels list
openclaw channels status
openclaw channels capabilities
openclaw channels capabilities --channel discord --target channel:123
openclaw channels resolve --channel slack "#general" "@jane"
openclaw channels logs --channel all
```

```bash
openclaw channels add --channel telegram --token <bot-token>
openclaw channels remove --channel telegram --delete
```

```bash
openclaw channels login --channel whatsapp
openclaw channels logout --channel whatsapp
```

```bash
openclaw channels capabilities
openclaw channels capabilities --channel discord --target channel:123
```

```bash
openclaw channels resolve --channel slack "#general" "@jane"
openclaw channels resolve --channel discord "My Server/#support" "@someone"
openclaw channels resolve --channel matrix "Project Room"
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/channels.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/channels