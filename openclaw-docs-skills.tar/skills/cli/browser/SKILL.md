---
name: openclaw-docs-cli-browser
description: CLI reference for `openclaw browser` (profiles, tabs, actions, extension relay)
metadata: {"openclaw":{"docPath":"cli/browser","group":"CLI"}}
---

# browser

## Purpose
- CLI reference for `openclaw browser` (profiles, tabs, actions, extension relay)

## Read When
- You use `openclaw browser` and want examples for common tasks
- You want to control a browser running on another machine via a node host
- You want to use the Chrome extension relay (attach/detach via toolbar button)

## Topics Covered
- Common flags
- Quick start (local)
- Profiles
- Tabs
- Snapshot / screenshot / actions
- Chrome extension relay (attach via toolbar button)
- Remote browser control (node host proxy)

## Key Commands
```bash
openclaw browser --browser-profile chrome tabs
openclaw browser --browser-profile openclaw start
openclaw browser --browser-profile openclaw open https://example.com
openclaw browser --browser-profile openclaw snapshot
```

```bash
openclaw browser profiles
openclaw browser create-profile --name work --color "#FF5A36"
openclaw browser delete-profile --name work
```

```bash
openclaw browser --browser-profile work tabs
```

```bash
openclaw browser tabs
openclaw browser open https://docs.openclaw.ai
openclaw browser focus <targetId>
openclaw browser close <targetId>
```

```bash
openclaw browser snapshot
```

```bash
openclaw browser screenshot
```

## Files And Paths
- //docs.openclaw.ai

## Related Source Code
- openclaw/src
- openclaw/docs/cli/browser.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/browser