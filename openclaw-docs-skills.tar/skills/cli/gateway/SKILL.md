---
name: openclaw-docs-cli-gateway
description: OpenClaw Gateway CLI (`openclaw gateway`) - run, query, and discover gateways
metadata: {"openclaw":{"docPath":"cli/gateway","group":"CLI"}}
---

# gateway

## Purpose
- OpenClaw Gateway CLI (`openclaw gateway`) - run, query, and discover gateways

## Read When
- Running the Gateway from the CLI (dev or servers)
- Debugging Gateway auth, bind modes, and connectivity
- Discovering gateways via Bonjour (LAN + tailnet)

## Topics Covered
- Run the Gateway
- Query a running Gateway
- Manage the Gateway service
- Discover gateways (Bonjour)

## Key Commands
```bash
openclaw gateway
```

```bash
openclaw gateway run
```

```bash
openclaw gateway health --url ws://127.0.0.1:18789
```

```bash
openclaw gateway status
openclaw gateway status --json
```

```bash
openclaw gateway probe
openclaw gateway probe --json
```

```bash
openclaw gateway probe --ssh user@gateway-host
```

## Key Environment Variables
- OPENCLAW_GATEWAY_TOKEN
- OPENCLAW_GATEWAY_PASSWORD

## Files And Paths
- ~/.openclaw/openclaw.json

## Related Source Code
- openclaw/src
- openclaw/docs/cli/gateway.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/gateway