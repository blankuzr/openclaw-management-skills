---
name: openclaw-docs-cli-setup
description: CLI reference for `openclaw setup` (initialize config + workspace)
metadata: {"openclaw":{"docPath":"cli/setup","group":"CLI"}}
---

# setup

## Purpose
- CLI reference for `openclaw setup` (initialize config + workspace)

## Read When
- You're doing first-run setup without the full onboarding wizard
- You want to set the default workspace path

## Topics Covered
- Examples

## Key Commands
```bash
openclaw setup
openclaw setup --workspace ~/.openclaw/workspace
```

```bash
openclaw setup --wizard
```

## Files And Paths
- ~/.openclaw/openclaw.json
- ~/.openclaw/workspace

## Related Source Code
- openclaw/src
- openclaw/docs/cli/setup.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/setup