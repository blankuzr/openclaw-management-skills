---
name: openclaw-docs-cli-update
description: CLI reference for `openclaw update` (safe-ish source update + gateway auto-restart)
metadata: {"openclaw":{"docPath":"cli/update","group":"CLI"}}
---

# update

## Purpose
- CLI reference for `openclaw update` (safe-ish source update + gateway auto-restart)

## Read When
- You want to update a source checkout safely
- You need to understand `--update` shorthand behavior

## Topics Covered
- Usage
- Options
- `update status`
- `update wizard`
- What it does
- Git checkout flow
- `--update` shorthand
- See also

## Key Commands
```bash
openclaw update
openclaw update status
openclaw update wizard
openclaw update --channel beta
openclaw update --channel dev
openclaw update --tag beta
openclaw update --no-restart
openclaw update --json
openclaw --update
```

```bash
openclaw update status
openclaw update status --json
openclaw update status --timeout 10
```

## Key Environment Variables
- OPENCLAW_GIT_DIR

## Files And Paths
- ~/openclaw

## Related Source Code
- openclaw/src
- openclaw/docs/cli/update.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/update