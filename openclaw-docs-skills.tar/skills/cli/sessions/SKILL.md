---
name: openclaw-docs-cli-sessions
description: CLI reference for `openclaw sessions` (list stored sessions + usage)
metadata: {"openclaw":{"docPath":"cli/sessions","group":"CLI"}}
---

# sessions

## Purpose
- CLI reference for `openclaw sessions` (list stored sessions + usage)

## Read When
- You want to list stored sessions and see recent activity

## Key Commands
```bash
openclaw sessions
openclaw sessions --active 120
openclaw sessions --json
```

## Related Source Code
- openclaw/src
- openclaw/docs/cli/sessions.md
- openclaw/src/cli
- openclaw/src/commands

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/cli/sessions