---
name: openclaw-docs-web-control-ui
description: Browser-based control UI for the Gateway (chat, nodes, config)
metadata: {"openclaw":{"docPath":"web/control-ui","group":"Web & Interfaces"}}
---

# Control UI

## Purpose
- Browser-based control UI for the Gateway (chat, nodes, config)

## Read When
- You want to operate the Gateway from a browser
- You want Tailnet access without SSH tunnels

## Topics Covered
- Quick open (local)
- Device pairing (first connection)
- What it can do (today)
- Chat behavior
- Tailnet access (recommended)
- Insecure HTTP
- Building the UI
- Debugging/testing: dev server + remote Gateway

## Key Commands
```bash
# List pending requests
openclaw devices list

# Approve by request ID
openclaw devices approve <requestId>
```

```bash
openclaw gateway --tailscale serve
```

```bash
openclaw gateway --bind tailnet --token "$(openssl rand -hex 32)"
```

```bash
pnpm ui:build # auto-installs UI deps on first run
```

```bash
OPENCLAW_CONTROL_UI_BASE_PATH=/openclaw/ pnpm ui:build
```

```bash
pnpm ui:dev # auto-installs UI deps on first run
```

## Key Config Snippets
```json
{
  gateway: {
    controlUi: { allowInsecureAuth: true },
    bind: "tailnet",
    auth: { mode: "token", token: "replace-me" },
  },
}
```

## Key Config Keys
- connect.params.auth.token
- connect.params.auth.password

## Key Environment Variables
- OPENCLAW_CONTROL_UI_BASE_PATH

## Files And Paths
- ~/.openclaw/openclaw.json

## Related Source Code
- openclaw/src
- openclaw/docs/web/control-ui.md
- openclaw/ui
- openclaw/src/web

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/web/control-ui