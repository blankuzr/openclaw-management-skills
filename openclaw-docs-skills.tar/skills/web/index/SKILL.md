---
name: openclaw-docs-web-index
description: Gateway web surfaces: Control UI, bind modes, and security
metadata: {"openclaw":{"docPath":"web/index","group":"Web & Interfaces"}}
---

# Web

## Purpose
- Gateway web surfaces: Control UI, bind modes, and security

## Read When
- You want to access the Gateway over Tailscale
- You want the browser Control UI and config editing

## Topics Covered
- Webhooks
- Config (default-on)
- Tailscale access
- Security notes
- Building the UI

## Key Commands
```bash
openclaw gateway
```

```bash
openclaw gateway
```

```bash
pnpm ui:build # auto-installs UI deps on first run
```

## Key Config Snippets
```json
{
  gateway: {
    controlUi: { enabled: true, basePath: "/openclaw" }, // basePath optional
  },
}
```

```json
{
  gateway: {
    bind: "loopback",
    tailscale: { mode: "serve" },
  },
}
```

## Key Environment Variables
- OPENCLAW_GATEWAY_PASSWORD

## Related Source Code
- openclaw/src
- openclaw/docs/web/index.md
- openclaw/ui
- openclaw/src/web

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/web/index