---
name: openclaw-docs-concepts-typebox
description: TypeBox schemas as the single source of truth for the gateway protocol
metadata: {"openclaw":{"docPath":"concepts/typebox","group":"Core Concepts"}}
---

# TypeBox

## Purpose
- TypeBox schemas as the single source of truth for the gateway protocol

## Read When
- Updating protocol schemas or codegen

## Topics Covered
- Mental model (30 seconds)
- Where the schemas live
- Current pipeline
- How the schemas are used at runtime
- Example frames
- Minimal client (Node.js)
- Worked example: add a method endtoend
- Swift codegen behavior

## Key Commands
```bash
pnpm protocol:check
```

## Key Config Snippets
```json
{
  "type": "req",
  "id": "c1",
  "method": "connect",
  "params": {
    "minProtocol": 2,
    "maxProtocol": 2,
    "client": {
      "id": "openclaw-macos",
      "displayName": "macos",
      "version": "1.0.0",
      "platform": "macos 15.1",
      "mode": "ui",
      "instanceId": "A1B2"
    }
  }
}
```

```json
{
  "type": "res",
  "id": "c1",
  "ok": true,
  "payload": {
    "type": "hello-ok",
    "protocol": 2,
    "server": { "version": "dev", "connId": "ws-1" },
    "features": { "methods": ["health"], "events": ["tick"] },
    "snapshot": {
      "presence": [],
      "health": {},
      "stateVersion": { "presence": 0, "health": 0 },
      "uptimeMs": 0
    },
    "policy": { "maxPayload": 1048576, "maxBufferedBytes": 1048576, "tickIntervalMs": 30000 }
  }
}
```

## Key Config Keys
- chat.send

## Files And Paths
- //raw.githubusercontent.com/openclaw/openclaw/main/dist/protocol.schema.json

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/typebox.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/typebox