---
name: openclaw-docs-concepts-model-failover
description: How OpenClaw rotates auth profiles and falls back across models
metadata: {"openclaw":{"docPath":"concepts/model-failover","group":"Core Concepts"}}
---

# Model Failover

## Purpose
- How OpenClaw rotates auth profiles and falls back across models

## Read When
- Diagnosing auth profile rotation, cooldowns, or model fallback behavior
- Updating failover rules for auth profiles or models

## Topics Covered
- Auth storage (keys + OAuth)
- Profile IDs
- Rotation order
- Cooldowns
- Billing disables
- Model fallback
- Related config

## Key Config Snippets
```json
{
  "usageStats": {
    "provider:profile": {
      "lastUsed": 1736160000000,
      "cooldownUntil": 1736160600000,
      "errorCount": 2
    }
  }
}
```

```json
{
  "usageStats": {
    "provider:profile": {
      "disabledUntil": 1736178000000,
      "disabledReason": "billing"
    }
  }
}
```

## Key Config Keys
- agents.defaults.model.fallbacks
- auth.profiles
- auth.order

## Files And Paths
- ~/.openclaw/agents/
- ~/.openclaw/agent/auth-profiles.json
- ~/.openclaw/credentials/oauth.json

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/model-failover.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/model-failover