---
name: openclaw-docs-concepts-model-providers
description: Model provider overview with example configs + CLI flows
metadata: {"openclaw":{"docPath":"concepts/model-providers","group":"Core Concepts"}}
---

# Model Providers

## Purpose
- Model provider overview with example configs + CLI flows

## Read When
- You need a provider-by-provider model setup reference
- You want example configs or CLI onboarding commands for model providers

## Topics Covered
- Quick rules
- Built-in providers (pi-ai catalog)
- Providers via `models.providers` (custom/base URL)
- CLI examples

## Key Commands
```bash
openclaw plugins enable qwen-portal-auth
openclaw models auth login --provider qwen-portal --set-default
```

```bash
# Install Ollama, then pull a model:
ollama pull llama3.3
```

```bash
openclaw onboard --auth-choice opencode-zen
openclaw models set opencode/claude-opus-4-5
openclaw models list
```

## Key Config Snippets
```json
{
  agents: { defaults: { model: { primary: "openai/gpt-5.2" } } },
}
```

```json
{
  agents: { defaults: { model: { primary: "anthropic/claude-opus-4-5" } } },
}
```

## Key Config Keys
- agents.defaults.models
- models.providers

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/model-providers.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/model-providers