---
name: openclaw-docs-concepts-context
description: Context: what the model sees, how it is built, and how to inspect it
metadata: {"openclaw":{"docPath":"concepts/context","group":"Core Concepts"}}
---

# Context

## Purpose
- Context: what the model sees, how it is built, and how to inspect it

## Read When
- You want to understand what "context" means in OpenClaw
- You are debugging why the model "knows" something (or forgot it)
- You want to reduce context overhead (/context, /status, /compact)

## Topics Covered
- Quick start (inspect context)
- Example output
- What counts toward the context window
- How OpenClaw builds the system prompt
- Injected workspace files (Project Context)
- Skills: what's injected vs loaded on-demand
- Tools: there are two costs
- Commands, directives, and "inline shortcuts"

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/context.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/context