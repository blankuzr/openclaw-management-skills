---
name: openclaw-docs-concepts-session-pruning
description: Session pruning: tool-result trimming to reduce context bloat
metadata: {"openclaw":{"docPath":"concepts/session-pruning","group":"Core Concepts"}}
---

# concepts/session-pruning

## Purpose
- Session pruning: tool-result trimming to reduce context bloat

## Read When
- You want to reduce LLM context growth from tool outputs
- You are tuning agents.defaults.contextPruning

## Topics Covered
- When it runs
- Smart defaults (Anthropic)
- What this improves (cost + cache behavior)
- What can be pruned
- Context window estimation
- Mode
- Soft vs hard pruning
- Tool selection

## Key Config Snippets
```json
{
  agent: {
    contextPruning: { mode: "off" },
  },
}
```

```json
{
  agent: {
    contextPruning: { mode: "cache-ttl", ttl: "5m" },
  },
}
```

## Key Config Keys
- tools.allow
- tools.deny

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/session-pruning.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/session-pruning