---
name: openclaw-docs-concepts-typing-indicators
description: When OpenClaw shows typing indicators and how to tune them
metadata: {"openclaw":{"docPath":"concepts/typing-indicators","group":"Core Concepts"}}
---

# Typing Indicators

## Purpose
- When OpenClaw shows typing indicators and how to tune them

## Read When
- Changing typing indicator behavior or defaults

## Topics Covered
- Defaults
- Modes
- Configuration
- Notes

## Key Config Snippets
```json
{
  agent: {
    typingMode: "thinking",
    typingIntervalSeconds: 6,
  },
}
```

```json
{
  session: {
    typingMode: "message",
    typingIntervalSeconds: 4,
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/typing-indicators.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/typing-indicators