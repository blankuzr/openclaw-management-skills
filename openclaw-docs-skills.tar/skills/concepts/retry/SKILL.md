---
name: openclaw-docs-concepts-retry
description: Retry policy for outbound provider calls
metadata: {"openclaw":{"docPath":"concepts/retry","group":"Core Concepts"}}
---

# Retry Policy

## Purpose
- Retry policy for outbound provider calls

## Read When
- Updating provider retry behavior or defaults
- Debugging provider send errors or rate limits

## Topics Covered
- Goals
- Defaults
- Behavior
- Configuration
- Notes

## Key Config Snippets
```json
{
  channels: {
    telegram: {
      retry: {
        attempts: 3,
        minDelayMs: 400,
        maxDelayMs: 30000,
        jitter: 0.1,
      },
    },
    discord: {
      retry: {
        attempts: 3,
        minDelayMs: 500,
        maxDelayMs: 30000,
        jitter: 0.1,
      },
    },
  },
}
```

## Files And Paths
- ~/.openclaw/openclaw.json

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/retry.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/retry