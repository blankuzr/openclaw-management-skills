---
name: openclaw-docs-concepts-session
description: Session management rules, keys, and persistence for chats
metadata: {"openclaw":{"docPath":"concepts/session","group":"Core Concepts"}}
---

# Session Management

## Purpose
- Session management rules, keys, and persistence for chats

## Read When
- Modifying session handling or storage

## Topics Covered
- Gateway is the source of truth
- Where state lives
- Session pruning
- Pre-compaction memory flush
- Mapping transports -> session keys
- Lifecycle
- Send policy (optional)
- Configuration (optional rename example)

## Key Config Snippets
```json
{
  session: {
    sendPolicy: {
      rules: [
        { action: "deny", match: { channel: "discord", chatType: "group" } },
        { action: "deny", match: { keyPrefix: "cron:" } },
      ],
      default: "allow",
    },
  },
}
```

```json
// ~/.openclaw/openclaw.json
{
  session: {
    scope: "per-sender", // keep group keys separate
    dmScope: "main", // DM continuity (set per-channel-peer/per-account-channel-peer for shared inboxes)
    identityLinks: {
      alice: ["telegram:123456789", "discord:987654321012345678"],
    },
    reset: {
      // Defaults: mode=daily, atHour=4 (gateway host local time).
      // If you also set idleMinutes, whichever expires first wins.
      mode: "daily",
      atHour: 4,
      idleMinutes: 120,
    },
    resetByType: {
      thread: { mode: "daily", atHour: 4 },
      dm: { mode: "idle", idleMinutes: 240 },
      group: { mode: "idle", idleMinutes: 120 },
    },
```

## Key Config Keys
- session.reset

## Files And Paths
- ~/.openclaw/agents/
- ~/.openclaw/openclaw.json
- /sessions/sessions.json

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/session.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/session