---
name: openclaw-docs-concepts-groups
description: Group chat behavior across surfaces (WhatsApp/Telegram/Discord/Slack/Signal/iMessage/Microsoft Teams)
metadata: {"openclaw":{"docPath":"concepts/groups","group":"Core Concepts"}}
---

# Groups

## Purpose
- Group chat behavior across surfaces (WhatsApp/Telegram/Discord/Slack/Signal/iMessage/Microsoft Teams)

## Read When
- Changing group chat behavior or mention gating

## Topics Covered
- Beginner intro (2 minutes)
- Session keys
- Pattern: personal DMs + public groups (single agent)
- Display labels
- Group policy
- Mention gating (default)
- Group/channel tool restrictions (optional)
- Group allowlists

## Key Config Snippets
```json
{
  agents: {
    defaults: {
      sandbox: {
        mode: "non-main", // groups/channels are non-main -> sandboxed
        scope: "session", // strongest isolation (one container per group/channel)
        workspaceAccess: "none",
      },
    },
  },
  tools: {
    sandbox: {
      tools: {
        // If allow is non-empty, everything else is blocked (deny still wins).
        allow: ["group:messaging", "group:sessions"],
        deny: ["group:runtime", "group:fs", "group:ui", "nodes", "cron", "gateway"],
      },
    },
  },
}
```

```json
{
  agents: {
    defaults: {
      sandbox: {
        mode: "non-main",
        scope: "session",
        workspaceAccess: "none",
        docker: {
          binds: [
            // hostPath:containerPath:mode
            "~/FriendsShared:/data:ro",
          ],
        },
      },
    },
  },
}
```

## Files And Paths
- ~/FriendsShared

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/groups.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/groups