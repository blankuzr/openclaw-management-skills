---
name: openclaw-docs-concepts-models
description: Models CLI: list, set, aliases, fallbacks, scan, status
metadata: {"openclaw":{"docPath":"concepts/models","group":"Core Concepts"}}
---

# Models CLI

## Purpose
- Models CLI: list, set, aliases, fallbacks, scan, status

## Read When
- Adding or modifying models CLI (models list/set/scan/aliases/fallbacks)
- Changing model fallback behavior or selection UX
- Updating model scan probes (tools/images)

## Topics Covered
- How model selection works
- Quick model picks (anecdotal)
- Setup wizard (recommended)
- Config keys (overview)
- "Model is not allowed" (and why replies stop)
- Switching models in chat (`/model`)
- CLI commands
- Scanning (OpenRouter free models)

## Key Commands
```bash
openclaw onboard
```

```bash
openclaw models list
openclaw models status
openclaw models set <provider/model>
openclaw models set-image <provider/model>

openclaw models aliases list
openclaw models aliases add <alias> <provider/model>
openclaw models aliases remove <alias>

openclaw models fallbacks list
openclaw models fallbacks add <provider/model>
openclaw models fallbacks remove <provider/model>
```

```bash
claude setup-token
openclaw models status
```

## Key Config Snippets
```json
{
  agent: {
    model: { primary: "anthropic/claude-sonnet-4-5" },
    models: {
      "anthropic/claude-sonnet-4-5": { alias: "Sonnet" },
      "anthropic/claude-opus-4-5": { alias: "Opus" },
    },
  },
}
```

## Key Config Keys
- agents.defaults.model.primary
- agents.defaults.model
- agents.defaults.model.fallbacks
- agents.defaults.models

## Files And Paths
- ~/.openclaw/agents/

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/models.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/models