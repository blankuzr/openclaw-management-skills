---
name: openclaw-docs-concepts-markdown-formatting
description: Markdown formatting pipeline for outbound channels
metadata: {"openclaw":{"docPath":"concepts/markdown-formatting","group":"Core Concepts"}}
---

# Markdown Formatting

## Purpose
- Markdown formatting pipeline for outbound channels

## Read When
- You are changing markdown formatting or chunking for outbound channels
- You are adding a new channel formatter or style mapping
- You are debugging formatting regressions across channels

## Topics Covered
- Goals
- Pipeline
- IR example
- Where it is used
- Table handling
- Chunking rules
- Link policy
- Spoilers

## Key Config Snippets
```json
{
  "text": "Hello world - see docs.",
  "styles": [{ "start": 6, "end": 11, "style": "bold" }],
  "links": [{ "start": 19, "end": 23, "href": "https://docs.openclaw.ai" }]
}
```

```json
channels:
  discord:
    markdown:
      tables: code
    accounts:
      work:
        markdown:
          tables: off
```

## Files And Paths
- //docs.openclaw.ai).
- //docs.openclaw.ai

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/markdown-formatting.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/markdown-formatting