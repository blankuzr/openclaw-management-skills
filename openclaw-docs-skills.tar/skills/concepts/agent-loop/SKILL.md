---
name: openclaw-docs-concepts-agent-loop
description: Agent loop lifecycle, streams, and wait semantics
metadata: {"openclaw":{"docPath":"concepts/agent-loop","group":"Core Concepts"}}
---

# Agent Loop

## Purpose
- Agent loop lifecycle, streams, and wait semantics

## Read When
- You need an exact walkthrough of the agent loop or lifecycle events

## Topics Covered
- Entry points
- How it works (high-level)
- Queueing + concurrency
- Session + workspace preparation
- Prompt assembly + system prompt
- Hook points (where you can intercept)
- Streaming + partial replies
- Tool execution + messaging tools

## Key Config Keys
- agent.wait

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/agent-loop.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/agent-loop