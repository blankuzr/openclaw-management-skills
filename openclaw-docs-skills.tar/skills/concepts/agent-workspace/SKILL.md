---
name: openclaw-docs-concepts-agent-workspace
description: Agent workspace: location, layout, and backup strategy
metadata: {"openclaw":{"docPath":"concepts/agent-workspace","group":"Core Concepts"}}
---

# Agent Workspace

## Purpose
- Agent workspace: location, layout, and backup strategy

## Read When
- You need to explain the agent workspace or its file layout
- You want to back up or migrate an agent workspace

## Topics Covered
- Default location
- Extra workspace folders
- Workspace file map (what each file means)
- What is NOT in the workspace
- Git backup (recommended, private)
- Do not commit secrets
- Moving the workspace to a new machine
- Advanced notes

## Key Commands
```bash
cd ~/.openclaw/workspace
git init
git add AGENTS.md SOUL.md TOOLS.md IDENTITY.md USER.md HEARTBEAT.md memory/
git commit -m "Add agent workspace"
```

```bash
git branch -M main
git remote add origin <https-url>
git push -u origin main
```

```bash
gh auth login
gh repo create openclaw-workspace --private --source . --remote origin --push
```

```bash
git branch -M main
git remote add origin <https-url>
git push -u origin main
```

```bash
git status
git add .
git commit -m "Update memory"
git push
```

## Key Config Snippets
```json
{
  agent: {
    workspace: "~/.openclaw/workspace",
  },
}
```

```json
{ agent: { skipBootstrap: true } }
```

## Key Config Keys
- agents.defaults.sandbox

## Key Environment Variables
- OPENCLAW_PROFILE

## Files And Paths
- ~/.openclaw/
- ~/.openclaw/sandboxes
- ~/.openclaw/workspace
- ~/.openclaw/workspace-
- ~/.openclaw/openclaw.json
- ~/openclaw
- ~/.openclaw/credentials/
- ~/.openclaw/agents/

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/agent-workspace.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/agent-workspace