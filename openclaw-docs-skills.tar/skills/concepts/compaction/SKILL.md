---
name: openclaw-docs-concepts-compaction
description: Context window + compaction: how OpenClaw keeps sessions under model limits
metadata: {"openclaw":{"docPath":"concepts/compaction","group":"Core Concepts"}}
---

# Compaction

## Purpose
- Context window + compaction: how OpenClaw keeps sessions under model limits

## Read When
- You want to understand auto-compaction and /compact
- You are debugging long sessions hitting context limits

## Topics Covered
- What compaction is
- Configuration
- Auto-compaction (default on)
- Manual compaction
- Context window source
- Compaction vs pruning
- Tips

## Key Config Keys
- agents.defaults.compaction

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/compaction.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/compaction