---
name: openclaw-docs-concepts-usage-tracking
description: Usage tracking surfaces and credential requirements
metadata: {"openclaw":{"docPath":"concepts/usage-tracking","group":"Core Concepts"}}
---

# Usage Tracking

## Purpose
- Usage tracking surfaces and credential requirements

## Read When
- You are wiring provider usage/quota surfaces
- You need to explain usage tracking behavior or auth requirements

## Topics Covered
- What it is
- Where it shows up
- Providers + credentials

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/usage-tracking.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/usage-tracking