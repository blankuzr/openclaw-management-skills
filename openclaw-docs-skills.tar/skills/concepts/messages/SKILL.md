---
name: openclaw-docs-concepts-messages
description: Message flow, sessions, queueing, and reasoning visibility
metadata: {"openclaw":{"docPath":"concepts/messages","group":"Core Concepts"}}
---

# Messages

## Purpose
- Message flow, sessions, queueing, and reasoning visibility

## Read When
- Explaining how inbound messages become replies
- Clarifying sessions, queueing modes, or streaming behavior
- Documenting reasoning visibility and usage implications

## Topics Covered
- Message flow (high level)
- Inbound dedupe
- Inbound debouncing
- Sessions and devices
- Inbound bodies and history context
- Queueing and followups
- Streaming, chunking, and batching
- Reasoning visibility and tokens

## Key Config Snippets
```json
{
  messages: {
    inbound: {
      debounceMs: 2000,
      byChannel: {
        whatsapp: 5000,
        slack: 1500,
        discord: 1500,
      },
    },
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/messages.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/messages