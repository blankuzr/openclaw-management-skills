---
name: openclaw-docs-concepts-session-tool
description: Agent session tools for listing sessions, fetching history, and sending cross-session messages
metadata: {"openclaw":{"docPath":"concepts/session-tool","group":"Core Concepts"}}
---

# Session Tools

## Purpose
- Agent session tools for listing sessions, fetching history, and sending cross-session messages

## Read When
- Adding or modifying session tools

## Topics Covered
- Tool Names
- Key Model
- sessions_list
- sessions_history
- sessions_send
- Channel Field
- Security / Send Policy
- sessions_spawn

## Key Config Snippets
```json
{
  "session": {
    "sendPolicy": {
      "rules": [
        {
          "match": { "channel": "discord", "chatType": "group" },
          "action": "deny"
        }
      ],
      "default": "allow"
    }
  }
}
```

```json
{
  agents: {
    defaults: {
      sandbox: {
        // default: "spawned"
        sessionToolsVisibility: "spawned", // or "all"
      },
    },
  },
}
```

## Key Config Keys
- chat.history
- agent.wait

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/session-tool.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/session-tool