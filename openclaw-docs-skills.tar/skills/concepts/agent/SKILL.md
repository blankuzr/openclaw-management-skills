---
name: openclaw-docs-concepts-agent
description: Agent runtime (embedded pi-mono), workspace contract, and session bootstrap
metadata: {"openclaw":{"docPath":"concepts/agent","group":"Core Concepts"}}
---

# Agent Runtime

## Purpose
- Agent runtime (embedded pi-mono), workspace contract, and session bootstrap

## Read When
- Changing agent runtime, workspace bootstrap, or session behavior

## Topics Covered
- Workspace (required)
- Bootstrap files (injected)
- Built-in tools
- Skills
- pi-mono integration
- Sessions
- Steering while streaming
- Model refs

## Key Config Snippets
```json
{ agent: { skipBootstrap: true } }
```

## Key Config Keys
- agents.defaults.workspace
- agents.defaults.sandbox

## Files And Paths
- ~/.openclaw/openclaw.json
- ~/.openclaw/skills
- ~/.pi/agent
- ~/.openclaw/agents/

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/agent.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/agent