---
name: openclaw-docs-concepts-channel-routing
description: Routing rules per channel (WhatsApp, Telegram, Discord, Slack) and shared context
metadata: {"openclaw":{"docPath":"concepts/channel-routing","group":"Core Concepts"}}
---

# Channel Routing

## Purpose
- Routing rules per channel (WhatsApp, Telegram, Discord, Slack) and shared context

## Read When
- Changing channel routing or inbox behavior

## Topics Covered
- Key terms
- Session key shapes (examples)
- Routing rules (how an agent is chosen)
- Broadcast groups (run multiple agents)
- Config overview
- Session storage
- WebChat behavior
- Reply context

## Key Config Snippets
```json
{
  broadcast: {
    strategy: "parallel",
    "120363403215116621@g.us": ["alfred", "baerbel"],
    "+15555550123": ["support", "logger"],
  },
}
```

```json
{
  agents: {
    list: [{ id: "support", name: "Support", workspace: "~/.openclaw/workspace-support" }],
  },
  bindings: [
    { match: { channel: "slack", teamId: "T123" }, agentId: "support" },
    { match: { channel: "telegram", peer: { kind: "group", id: "-100123" } }, agentId: "support" },
  ],
}
```

## Key Config Keys
- peer.kind
- peer.id

## Files And Paths
- ~/.openclaw/workspace-support
- ~/.openclaw
- ~/.openclaw/agents/

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/channel-routing.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/channel-routing