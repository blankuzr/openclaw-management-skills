---
name: openclaw-docs-concepts-group-messages
description: Behavior and config for WhatsApp group message handling (mentionPatterns are shared across surfaces)
metadata: {"openclaw":{"docPath":"concepts/group-messages","group":"Core Concepts"}}
---

# Group Messages

## Purpose
- Behavior and config for WhatsApp group message handling (mentionPatterns are shared across surfaces)

## Read When
- Changing group message rules or mentions

## Topics Covered
- What's implemented (2025-12-03)
- Config example (WhatsApp)
- How to use
- Testing / verification
- Known considerations

## Key Config Snippets
```json
{
  channels: {
    whatsapp: {
      groups: {
        "*": { requireMention: true },
      },
    },
  },
  agents: {
    list: [
      {
        id: "main",
        groupChat: {
          historyLimit: 50,
          mentionPatterns: ["@?openclaw", "\\+?15555550123"],
        },
      },
    ],
  },
}
```

## Key Config Keys
- channels.whatsapp.groups

## Files And Paths
- ~/.openclaw/openclaw.json
- ~/.openclaw/agents/

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/group-messages.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/group-messages