---
name: openclaw-docs-concepts-presence
description: How OpenClaw presence entries are produced, merged, and displayed
metadata: {"openclaw":{"docPath":"concepts/presence","group":"Core Concepts"}}
---

# Presence

## Purpose
- How OpenClaw presence entries are produced, merged, and displayed

## Read When
- Debugging the Instances tab
- Investigating duplicate or stale instance rows
- Changing gateway WS connect or system-event beacons

## Topics Covered
- Presence fields (what shows up)
- Producers (where presence comes from)
- Merge + dedupe rules (why `instanceId` matters)
- TTL and bounded size
- Remote/tunnel caveat (loopback IPs)
- Consumers
- Debugging tips

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/presence.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/presence