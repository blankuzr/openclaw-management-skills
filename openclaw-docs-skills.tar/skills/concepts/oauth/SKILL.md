---
name: openclaw-docs-concepts-oauth
description: OAuth in OpenClaw: token exchange, storage, and multi-account patterns
metadata: {"openclaw":{"docPath":"concepts/oauth","group":"Core Concepts"}}
---

# OAuth

## Purpose
- OAuth in OpenClaw: token exchange, storage, and multi-account patterns

## Read When
- You want to understand OpenClaw OAuth end-to-end
- You hit token invalidation / logout issues
- You want setup-token or OAuth auth flows
- You want multiple accounts or profile routing

## Topics Covered
- The token sink (why it exists)
- Storage (where tokens live)
- Anthropic setup-token (subscription auth)
- OAuth exchange (how login works)
- Refresh + expiry
- Multiple accounts (profiles) + routing

## Key Commands
```bash
openclaw models auth login --provider <id>
```

```bash
openclaw models auth setup-token --provider anthropic
```

```bash
openclaw models auth paste-token --provider anthropic
```

```bash
openclaw models status
```

```bash
openclaw agents add work
openclaw agents add personal
```

## Key Environment Variables
- OPENCLAW_STATE_DIR

## Files And Paths
- ~/.openclaw/agents/
- ~/.openclaw/credentials/oauth.json

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/oauth.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/oauth