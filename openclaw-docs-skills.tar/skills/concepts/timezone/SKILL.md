---
name: openclaw-docs-concepts-timezone
description: Timezone handling for agents, envelopes, and prompts
metadata: {"openclaw":{"docPath":"concepts/timezone","group":"Core Concepts"}}
---

# Timezones

## Purpose
- Timezone handling for agents, envelopes, and prompts

## Read When
- You need to understand how timestamps are normalized for the model
- Configuring the user timezone for system prompts

## Topics Covered
- Message envelopes (local by default)
- Tool payloads (raw provider data + normalized fields)
- User timezone for the system prompt

## Key Config Snippets
```json
[Provider ... 2026-01-05 16:26 PST] message text
```

```json
{
  agents: {
    defaults: {
      envelopeTimezone: "local", // "utc" | "local" | "user" | IANA timezone
      envelopeTimestamp: "on", // "on" | "off"
      envelopeElapsed: "on", // "on" | "off"
    },
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/timezone.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/timezone