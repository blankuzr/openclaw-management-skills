---
name: openclaw-docs-concepts-multi-agent
description: Multi-agent routing: isolated agents, channel accounts, and bindings
metadata: {"openclaw":{"docPath":"concepts/multi-agent","group":"Core Concepts"}}
---

# Multi-Agent Routing

## Purpose
- Multi-agent routing: isolated agents, channel accounts, and bindings

## Topics Covered
- What is "one agent"?
- Paths (quick map)
- Agent helper
- Multiple agents = multiple people, multiple personalities
- One WhatsApp number, multiple people (DM split)
- Routing rules (how messages pick an agent)
- Multiple accounts / phone numbers
- Concepts

## Key Commands
```bash
openclaw agents add work
```

```bash
openclaw agents list --bindings
```

## Key Config Snippets
```json
{
  agents: {
    list: [
      { id: "alex", workspace: "~/.openclaw/workspace-alex" },
      { id: "mia", workspace: "~/.openclaw/workspace-mia" },
    ],
  },
  bindings: [
    { agentId: "alex", match: { channel: "whatsapp", peer: { kind: "dm", id: "+15551230001" } } },
    { agentId: "mia", match: { channel: "whatsapp", peer: { kind: "dm", id: "+15551230002" } } },
  ],
  channels: {
    whatsapp: {
      dmPolicy: "allowlist",
      allowFrom: ["+15551230001", "+15551230002"],
    },
  },
}
```

```json
{
  agents: {
    list: [
      {
        id: "home",
        default: true,
        name: "Home",
        workspace: "~/.openclaw/workspace-home",
        agentDir: "~/.openclaw/agents/home/agent",
      },
      {
        id: "work",
        name: "Work",
        workspace: "~/.openclaw/workspace-work",
        agentDir: "~/.openclaw/agents/work/agent",
      },
    ],
  },

  // Deterministic routing: first match wins (most-specific first).
```

## Key Environment Variables
- OPENCLAW_CONFIG_PATH
- OPENCLAW_STATE_DIR
- OPENCLAW_PROFILE

## Files And Paths
- ~/.openclaw/agents/
- /agent/auth-profiles.json
- ~/.openclaw/skills
- ~/.openclaw/openclaw.json
- ~/.openclaw
- ~/.openclaw/workspace
- ~/.openclaw/workspace-
- ~/.openclaw/agents/main/agent

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/multi-agent.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/multi-agent