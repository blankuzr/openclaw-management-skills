---
name: openclaw-docs-concepts-memory
description: How OpenClaw memory works (workspace files + automatic memory flush)
metadata: {"openclaw":{"docPath":"concepts/memory","group":"Core Concepts"}}
---

# Memory

## Purpose
- How OpenClaw memory works (workspace files + automatic memory flush)

## Read When
- You want the memory file layout and workflow
- You want to tune the automatic pre-compaction memory flush

## Topics Covered
- Memory files (Markdown)
- When to write memory
- Automatic memory flush (pre-compaction ping)
- Vector memory search

## Key Config Snippets
```json
{
  agents: {
    defaults: {
      compaction: {
        reserveTokensFloor: 20000,
        memoryFlush: {
          enabled: true,
          softThresholdTokens: 4000,
          systemPrompt: "Session nearing compaction. Store durable memories now.",
          prompt: "Write any lasting notes to memory/YYYY-MM-DD.md; reply with NO_REPLY if nothing to store.",
        },
      },
    },
  },
}
```

```json
agents: {
  defaults: {
    memorySearch: {
      extraPaths: ["../team-docs", "/srv/shared-notes/overview.md"]
    }
  }
}
```

## Key Config Keys
- agents.defaults.workspace

## Files And Paths
- ~/.openclaw/workspace
- ~/.openclaw/memory/
- ~/.openclaw/agents/

## Related Source Code
- openclaw/src
- openclaw/docs/concepts/memory.md
- openclaw/src/agents
- openclaw/src/sessions
- openclaw/src/routing
- openclaw/src/memory

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/concepts/memory