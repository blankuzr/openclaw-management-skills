---
name: openclaw-docs-render
description: Guidance for the OpenClaw docs section: render.
metadata: {"openclaw":{"docPath":"render","group":"Install & Updates"}}
---

# Deploy on Render

## Purpose
- Guidance for the OpenClaw docs section: render.

## Topics Covered
- Prerequisites
- Deploy with a Render Blueprint
- Understanding the Blueprint
- Choosing a plan
- After deployment
- Render Dashboard features
- Custom domain
- Scaling

## Key Config Snippets
```json
services:
  - type: web
    name: openclaw
    runtime: docker
    plan: starter
    healthCheckPath: /health
    envVars:
      - key: PORT
        value: "8080"
      - key: SETUP_PASSWORD
        sync: false # prompts during deploy
      - key: OPENCLAW_STATE_DIR
        value: /data/.openclaw
      - key: OPENCLAW_WORKSPACE_DIR
        value: /data/workspace
      - key: OPENCLAW_GATEWAY_TOKEN
        generateValue: true # auto-generates a secure token
    disk:
      name: openclaw-data
      mountPath: /data
```

## Key Config Keys
- render.yaml

## Key Environment Variables
- OPENCLAW_STATE_DIR
- OPENCLAW_WORKSPACE_DIR
- OPENCLAW_GATEWAY_TOKEN

## Files And Paths
- /data/.openclaw

## Related Source Code
- openclaw/src
- openclaw/docs/render.mdx

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/render