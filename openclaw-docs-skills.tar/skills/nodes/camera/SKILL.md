---
name: openclaw-docs-nodes-camera
description: Camera capture (iOS node + macOS app) for agent use: photos (jpg) and short video clips (mp4)
metadata: {"openclaw":{"docPath":"nodes/camera","group":"Nodes & Media"}}
---

# Camera Capture

## Purpose
- Camera capture (iOS node + macOS app) for agent use: photos (jpg) and short video clips (mp4)

## Read When
- Adding or modifying camera capture on iOS nodes or macOS
- Extending agent-accessible MEDIA temp-file workflows

## Topics Covered
- iOS node
- Android node
- macOS app
- Safety + practical limits
- macOS screen video (OS-level)

## Key Commands
```bash
openclaw nodes camera snap --node <id>               # default: both front + back (2 MEDIA lines)
openclaw nodes camera snap --node <id> --facing front
openclaw nodes camera clip --node <id> --duration 3000
openclaw nodes camera clip --node <id> --no-audio
```

```bash
openclaw nodes camera list --node <id>            # list camera ids
openclaw nodes camera snap --node <id>            # prints MEDIA:<path>
openclaw nodes camera snap --node <id> --max-width 1280
openclaw nodes camera snap --node <id> --delay-ms 2000
openclaw nodes camera snap --node <id> --device-id <id>
openclaw nodes camera clip --node <id> --duration 10s          # prints MEDIA:<path>
openclaw nodes camera clip --node <id> --duration-ms 3000      # prints MEDIA:<path> (legacy flag)
openclaw nodes camera clip --node <id> --device-id <id>
openclaw nodes camera clip --node <id> --no-audio
```

```bash
openclaw nodes screen record --node <id> --duration 10s --fps 15   # prints MEDIA:<path>
```

## Key Config Keys
- node.invoke
- camera.enabled
- camera.list
- camera.snap
- camera.clip

## Related Source Code
- openclaw/src
- openclaw/docs/nodes/camera.md
- openclaw/src/media
- openclaw/src/canvas-host
- openclaw/src/tts

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/nodes/camera