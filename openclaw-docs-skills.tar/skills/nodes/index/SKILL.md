---
name: openclaw-docs-nodes-index
description: Nodes: pairing, capabilities, permissions, and CLI helpers for canvas/camera/screen/system
metadata: {"openclaw":{"docPath":"nodes/index","group":"Nodes & Media"}}
---

# Nodes

## Purpose
- Nodes: pairing, capabilities, permissions, and CLI helpers for canvas/camera/screen/system

## Read When
- Pairing iOS/Android nodes to a gateway
- Using node canvas/camera for agent context
- Adding new node commands or CLI helpers

## Topics Covered
- Pairing + status
- Remote node host (system.run)
- Invoking commands
- Screenshots (canvas snapshots)
- Photos + videos (node camera)
- Screen recordings (nodes)
- Location (nodes)
- SMS (Android nodes)

## Key Commands
```bash
openclaw devices list
openclaw devices approve <requestId>
openclaw devices reject <requestId>
openclaw nodes status
openclaw nodes describe --node <idOrNameOrIp>
```

```bash
openclaw node run --host <gateway-host> --port 18789 --display-name "Build Node"
```

```bash
# Terminal A (keep running): forward local 18790 -> gateway 127.0.0.1:18789
ssh -N -L 18790:127.0.0.1:18789 user@gateway-host

# Terminal B: export the gateway token and connect through the tunnel
export OPENCLAW_GATEWAY_TOKEN="<gateway-token>"
openclaw node run --host 127.0.0.1 --port 18790 --display-name "Build Node"
```

```bash
openclaw node install --host <gateway-host> --port 18789 --display-name "Build Node"
openclaw node restart
```

```bash
openclaw nodes pending
openclaw nodes approve <requestId>
openclaw nodes list
```

```bash
openclaw approvals allowlist add --node <id|name|ip> "/usr/bin/uname"
openclaw approvals allowlist add --node <id|name|ip> "/usr/bin/sw_vers"
```

## Key Config Keys
- node.invoke

## Key Environment Variables
- OPENCLAW_GATEWAY_TOKEN
- OPENCLAW_NODE_EXEC_HOST
- OPENCLAW_NODE_EXEC_FALLBACK

## Files And Paths
- ~/.openclaw/exec-approvals.json
- ~/.openclaw/openclaw.json
- ~/.openclaw/node.json

## Related Source Code
- openclaw/src
- openclaw/docs/nodes/index.md
- openclaw/src/media
- openclaw/src/canvas-host
- openclaw/src/tts

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/nodes/index