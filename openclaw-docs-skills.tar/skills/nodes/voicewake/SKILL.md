---
name: openclaw-docs-nodes-voicewake
description: Global voice wake words (Gateway-owned) and how they sync across nodes
metadata: {"openclaw":{"docPath":"nodes/voicewake","group":"Nodes & Media"}}
---

# Voice Wake

## Purpose
- Global voice wake words (Gateway-owned) and how they sync across nodes

## Read When
- Changing voice wake words behavior or defaults
- Adding new node platforms that need wake word sync

## Topics Covered
- Storage (Gateway host)
- Protocol
- Client behavior

## Key Config Snippets
```json
{ "triggers": ["openclaw", "claude", "computer"], "updatedAtMs": 1730000000000 }
```

## Files And Paths
- ~/.openclaw/settings/voicewake.json

## Related Source Code
- openclaw/src
- openclaw/docs/nodes/voicewake.md
- openclaw/src/media
- openclaw/src/canvas-host
- openclaw/src/tts

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/nodes/voicewake