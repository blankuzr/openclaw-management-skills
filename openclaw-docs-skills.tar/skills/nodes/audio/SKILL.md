---
name: openclaw-docs-nodes-audio
description: How inbound audio/voice notes are downloaded, transcribed, and injected into replies
metadata: {"openclaw":{"docPath":"nodes/audio","group":"Nodes & Media"}}
---

# Audio and Voice Notes

## Purpose
- How inbound audio/voice notes are downloaded, transcribed, and injected into replies

## Read When
- Changing audio transcription or media handling

## Topics Covered
- What works
- Auto-detection (default)
- Config examples
- Notes & limits
- Gotchas

## Key Config Snippets
```json
{
  tools: {
    media: {
      audio: {
        enabled: true,
        maxBytes: 20971520,
        models: [
          { provider: "openai", model: "gpt-4o-mini-transcribe" },
          {
            type: "cli",
            command: "whisper",
            args: ["--model", "base", "{{MediaPath}}"],
            timeoutSeconds: 45,
          },
        ],
      },
    },
  },
}
```

```json
{
  tools: {
    media: {
      audio: {
        enabled: true,
        scope: {
          default: "allow",
          rules: [{ action: "deny", match: { chatType: "group" } }],
        },
        models: [{ provider: "openai", model: "gpt-4o-mini-transcribe" }],
      },
    },
  },
}
```

## Key Config Keys
- tools.media.audio.enabled
- tools.media.audio.models

## Related Source Code
- openclaw/src
- openclaw/docs/nodes/audio.md
- openclaw/src/media
- openclaw/src/canvas-host
- openclaw/src/tts

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/nodes/audio