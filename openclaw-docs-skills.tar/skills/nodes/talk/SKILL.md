---
name: openclaw-docs-nodes-talk
description: Talk mode: continuous speech conversations with ElevenLabs TTS
metadata: {"openclaw":{"docPath":"nodes/talk","group":"Nodes & Media"}}
---

# Talk Mode

## Purpose
- Talk mode: continuous speech conversations with ElevenLabs TTS

## Read When
- Implementing Talk mode on macOS/iOS/Android
- Changing voice/TTS/interrupt behavior

## Topics Covered
- Behavior (macOS)
- Voice directives in replies
- Config (`~/.openclaw/openclaw.json`)
- macOS UI
- Notes

## Key Config Snippets
```json
{ "voice": "<voice-id>", "once": true }
```

```json
{
  talk: {
    voiceId: "elevenlabs_voice_id",
    modelId: "eleven_v3",
    outputFormat: "mp3_44100_128",
    apiKey: "elevenlabs_api_key",
    interruptOnSpeech: true,
  },
}
```

## Files And Paths
- ~/.openclaw/openclaw.json

## Related Source Code
- openclaw/src
- openclaw/docs/nodes/talk.md
- openclaw/src/media
- openclaw/src/canvas-host
- openclaw/src/tts

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/nodes/talk