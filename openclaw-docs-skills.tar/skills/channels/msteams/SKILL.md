---
name: openclaw-docs-channels-msteams
description: Microsoft Teams bot support status, capabilities, and configuration
metadata: {"openclaw":{"docPath":"channels/msteams","group":"Channels"}}
---

# Microsoft Teams

## Purpose
- Microsoft Teams bot support status, capabilities, and configuration

## Read When
- Working on MS Teams channel features

## Topics Covered
- Plugin required
- Quick setup (beginner)
- Goals
- Config writes
- Access control (DMs + groups)
- How it works
- Azure Bot Setup (Prerequisites)
- Local Development (Tunneling)

## Key Commands
```bash
openclaw plugins install @openclaw/msteams
```

```bash
openclaw plugins install ./extensions/msteams
```

```bash
ngrok http 3978
# Copy the https URL, e.g., https://abc123.ngrok.io
# Set messaging endpoint to: https://abc123.ngrok.io/api/messages
```

```bash
tailscale funnel 3978
# Use your Tailscale funnel URL as the messaging endpoint
```

```bash
# Via Graph Explorer or curl with a valid token:
   curl -H "Authorization: Bearer $TOKEN" \
     "https://graph.microsoft.com/v1.0/sites/{hostname}:/{site-path}"

   # Example: for a site at "contoso.sharepoint.com/sites/BotFiles"
   curl -H "Authorization: Bearer $TOKEN" \
     "https://graph.microsoft.com/v1.0/sites/contoso.sharepoint.com:/sites/BotFiles"

   # Response includes: "id": "contoso.sharepoint.com,guid1,guid2"
```

```bash
openclaw message send --channel msteams \
  --target "conversation:19:abc...@thread.tacv2" \
  --card '{"type":"AdaptiveCard","version":"1.5","body":[{"type":"TextBlock","text":"Hello!"}]}'
```

## Key Config Snippets
```json
{
  channels: {
    msteams: {
      enabled: true,
      appId: "<APP_ID>",
      appPassword: "<APP_PASSWORD>",
      tenantId: "<TENANT_ID>",
      webhook: { port: 3978, path: "/api/messages" },
    },
  },
}
```

```json
{
  channels: { msteams: { configWrites: false } },
}
```

## Files And Paths
- ~/.openclaw/openclaw.json
- //developer.microsoft.com/en-us/json-schemas/teams/v1.23/MicrosoftTeams.schema.json
- ~/.openclaw/msteams-polls.json

## Related Source Code
- openclaw/src
- openclaw/docs/channels/msteams.md
- openclaw/src/channels
- openclaw/extensions/msteams

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/channels/msteams