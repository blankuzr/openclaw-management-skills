---
name: openclaw-docs-channels-mattermost
description: Mattermost bot setup and OpenClaw config
metadata: {"openclaw":{"docPath":"channels/mattermost","group":"Channels"}}
---

# Mattermost

## Purpose
- Mattermost bot setup and OpenClaw config

## Read When
- Setting up Mattermost
- Debugging Mattermost routing

## Topics Covered
- Plugin required
- Quick setup
- Environment variables (default account)
- Chat modes
- Access control (DMs)
- Channels (groups)
- Targets for outbound delivery
- Multi-account

## Key Commands
```bash
openclaw plugins install @openclaw/mattermost
```

```bash
openclaw plugins install ./extensions/mattermost
```

## Key Config Snippets
```json
{
  channels: {
    mattermost: {
      enabled: true,
      botToken: "mm-token",
      baseUrl: "https://chat.example.com",
      dmPolicy: "pairing",
    },
  },
}
```

```json
{
  channels: {
    mattermost: {
      chatmode: "onchar",
      oncharPrefixes: [">", "!"],
    },
  },
}
```

## Related Source Code
- openclaw/src
- openclaw/docs/channels/mattermost.md
- openclaw/src/channels
- openclaw/extensions/mattermost

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/channels/mattermost