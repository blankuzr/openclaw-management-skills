---
name: openclaw-docs-channels-matrix
description: Matrix support status, capabilities, and configuration
metadata: {"openclaw":{"docPath":"channels/matrix","group":"Channels"}}
---

# Matrix

## Purpose
- Matrix support status, capabilities, and configuration

## Read When
- Working on Matrix channel features

## Topics Covered
- Plugin required
- Setup
- Encryption (E2EE)
- Routing model
- Access control (DMs)
- Rooms (groups)
- Threads
- Capabilities

## Key Commands
```bash
openclaw plugins install @openclaw/matrix
```

```bash
openclaw plugins install ./extensions/matrix
```

```bash
curl --request POST \
     --url https://matrix.example.org/_matrix/client/v3/login \
     --header 'Content-Type: application/json' \
     --data '{
     "type": "m.login.password",
     "identifier": {
       "type": "m.id.user",
       "user": "your-user-name"
     },
     "password": "your-password"
   }'
```

## Key Config Snippets
```json
{
  channels: {
    matrix: {
      enabled: true,
      homeserver: "https://matrix.example.org",
      accessToken: "syt_***",
      dm: { policy: "pairing" },
    },
  },
}
```

```json
{
  channels: {
    matrix: {
      enabled: true,
      homeserver: "https://matrix.example.org",
      accessToken: "syt_***",
      encryption: true,
      dm: { policy: "pairing" },
    },
  },
}
```

## Files And Paths
- ~/.openclaw/credentials/matrix/credentials.json
- ~/.openclaw/matrix/accounts/

## Related Source Code
- openclaw/src
- openclaw/docs/channels/matrix.md
- openclaw/src/channels
- openclaw/extensions/matrix

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/channels/matrix