---
name: openclaw-docs-channels-grammy
description: Telegram Bot API integration via grammY with setup notes
metadata: {"openclaw":{"docPath":"channels/grammy","group":"Channels"}}
---

# grammY

## Purpose
- Telegram Bot API integration via grammY with setup notes

## Read When
- Working on Telegram or grammY pathways

## Key Config Keys
- channels.telegram.proxy
- webhook.ts
- channels.telegram.groups

## Related Source Code
- openclaw/src
- openclaw/docs/channels/grammy.md
- openclaw/src/channels

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/channels/grammy