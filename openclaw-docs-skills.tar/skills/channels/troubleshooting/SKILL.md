---
name: openclaw-docs-channels-troubleshooting
description: Channel-specific troubleshooting shortcuts (Discord/Telegram/WhatsApp)
metadata: {"openclaw":{"docPath":"channels/troubleshooting","group":"Channels"}}
---

# Channel Troubleshooting

## Purpose
- Channel-specific troubleshooting shortcuts (Discord/Telegram/WhatsApp)

## Read When
- A channel connects but messages don't flow
- Investigating channel misconfiguration (intents, permissions, privacy mode)

## Topics Covered
- Channels
- Telegram quick fixes

## Key Commands
```bash
openclaw doctor
openclaw channels status --probe
```

## Related Source Code
- openclaw/src
- openclaw/docs/channels/troubleshooting.md
- openclaw/src/channels

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/channels/troubleshooting