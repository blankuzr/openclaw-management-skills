---
name: openclaw-docs-install-installer
description: How the installer scripts work (install.sh + install-cli.sh), flags, and automation
metadata: {"openclaw":{"docPath":"install/installer","group":"Install & Updates"}}
---

# Installer Internals

## Purpose
- How the installer scripts work (install.sh + install-cli.sh), flags, and automation

## Read When
- You want to understand `openclaw.ai/install.sh`
- You want to automate installs (CI / headless)
- You want to install from a GitHub checkout

## Topics Covered
- install.sh (recommended)
- install-cli.sh (non-root CLI installer)
- install.ps1 (Windows PowerShell)

## Key Commands
```bash
curl -fsSL https://openclaw.ai/install.sh | bash -s -- --help
```

```bash
& ([scriptblock]::Create((iwr -useb https://openclaw.ai/install.ps1))) -?
```

```bash
SHARP_IGNORE_GLOBAL_LIBVIPS=0 curl -fsSL https://openclaw.ai/install.sh | bash
```

```bash
curl -fsSL https://openclaw.ai/install-cli.sh | bash -s -- --help
```

```bash
iwr -useb https://openclaw.ai/install.ps1 | iex
```

```bash
iwr -useb https://openclaw.ai/install.ps1 | iex -InstallMethod git
```

## Key Config Keys
- openclaw.ai

## Key Environment Variables
- OPENCLAW_INSTALL_METHOD
- OPENCLAW_GIT_DIR

## Files And Paths
- ~/.npm-global
- ~/.bashrc
- ~/.zshrc
- ~/.openclaw
- C:\\openclaw

## Related Source Code
- openclaw/src
- openclaw/docs/install/installer.md
- openclaw/scripts
- openclaw/docker-setup.sh
- openclaw/Dockerfile

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/install/installer