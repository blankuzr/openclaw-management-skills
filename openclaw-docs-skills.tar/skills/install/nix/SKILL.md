---
name: openclaw-docs-install-nix
description: Install OpenClaw declaratively with Nix
metadata: {"openclaw":{"docPath":"install/nix","group":"Install & Updates"}}
---

# Nix

## Purpose
- Install OpenClaw declaratively with Nix

## Read When
- You want reproducible, rollback-able installs
- You're already using Nix/NixOS/Home Manager
- You want everything pinned and managed declaratively

## Topics Covered
- Quick Start
- What you get
- Nix Mode Runtime Behavior
- Packaging note (macOS)
- Related

## Key Commands
```bash
OPENCLAW_NIX_MODE=1
```

```bash
defaults write bot.molt.mac openclaw.nixMode -bool true
```

## Key Environment Variables
- OPENCLAW_NIX_MODE
- OPENCLAW_CONFIG_PATH
- OPENCLAW_STATE_DIR

## Files And Paths
- ~/code/openclaw-local
- ~/.secrets/
- ~/.openclaw
- /openclaw.json`)

## Related Source Code
- openclaw/src
- openclaw/docs/install/nix.md
- openclaw/scripts
- openclaw/docker-setup.sh
- openclaw/Dockerfile

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/install/nix