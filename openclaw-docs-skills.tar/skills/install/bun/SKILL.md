---
name: openclaw-docs-install-bun
description: Bun workflow (experimental): installs and gotchas vs pnpm
metadata: {"openclaw":{"docPath":"install/bun","group":"Install & Updates"}}
---

# Bun (Experimental)

## Purpose
- Bun workflow (experimental): installs and gotchas vs pnpm

## Read When
- You want the fastest local dev loop (bun + watch)
- You hit Bun install/patch/lifecycle script issues

## Topics Covered
- Status
- Install
- Build / Test (Bun)
- Bun lifecycle scripts (blocked by default)
- Caveats

## Key Commands
```bash
bun install
```

```bash
bun install --no-save
```

```bash
bun run build
bun run vitest run
```

```bash
bun pm trust @whiskeysockets/baileys protobufjs
```

## Related Source Code
- openclaw/src
- openclaw/docs/install/bun.md
- openclaw/scripts
- openclaw/docker-setup.sh
- openclaw/Dockerfile

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/install/bun