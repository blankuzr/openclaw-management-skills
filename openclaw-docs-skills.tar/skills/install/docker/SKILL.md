---
name: openclaw-docs-install-docker
description: Optional Docker-based setup and onboarding for OpenClaw
metadata: {"openclaw":{"docPath":"install/docker","group":"Install & Updates"}}
---

# Docker

## Purpose
- Optional Docker-based setup and onboarding for OpenClaw

## Read When
- You want a containerized gateway instead of local installs
- You are validating the Docker flow

## Topics Covered
- Is Docker right for me?
- Requirements
- Containerized Gateway (Docker Compose)
- Agent Sandbox (host gateway + Docker tools)
- Troubleshooting

## Key Commands
```bash
./docker-setup.sh
```

```bash
docker build -t openclaw:local -f Dockerfile .
docker compose run --rm openclaw-cli onboard
docker compose up -d openclaw-gateway
```

```bash
docker compose -f docker-compose.yml -f docker-compose.extra.yml <command>
```

```bash
docker compose run --rm openclaw-cli dashboard --no-open
docker compose run --rm openclaw-cli devices list
docker compose run --rm openclaw-cli devices approve <requestId>
```

```bash
export OPENCLAW_EXTRA_MOUNTS="$HOME/.codex:/home/node/.codex:ro,$HOME/github:/home/node/github:rw"
./docker-setup.sh
```

```bash
export OPENCLAW_HOME_VOLUME="openclaw_home"
./docker-setup.sh
```

## Key Config Snippets
```json
{
  agents: {
    defaults: {
      sandbox: {
        mode: "non-main", // off | non-main | all
        scope: "agent", // session | agent | shared (agent is default)
        workspaceAccess: "none", // none | ro | rw
        workspaceRoot: "~/.openclaw/sandboxes",
        docker: {
          image: "openclaw-sandbox:bookworm-slim",
          workdir: "/workspace",
          readOnlyRoot: true,
          tmpfs: ["/tmp", "/var/tmp", "/run"],
          network: "none",
          user: "1000:1000",
          capDrop: ["ALL"],
          env: { LANG: "C.UTF-8" },
          setupCommand: "apt-get update && apt-get install -y git curl jq",
          pidsLimit: 256,
          memory: "1g",
```

```json
{
  agents: {
    defaults: {
      sandbox: { docker: { image: "openclaw-sandbox-common:bookworm-slim" } },
    },
  },
}
```

## Key Environment Variables
- OPENCLAW_DOCKER_APT_PACKAGES
- OPENCLAW_EXTRA_MOUNTS
- OPENCLAW_HOME_VOLUME
- OPENCLAW_GATEWAY_TOKEN

## Files And Paths
- ~/.openclaw/
- ~/.openclaw/workspace
- /home/node/.openclaw`,
- /package.json
- /ui/package.json
- ~/.openclaw/agents/
- ~/.openclaw/sandboxes
- /var/tmp

## Related Source Code
- openclaw/src
- openclaw/docs/install/docker.md
- openclaw/scripts
- openclaw/docker-setup.sh
- openclaw/Dockerfile

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/install/docker