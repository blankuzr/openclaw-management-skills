---
name: openclaw-docs-install-ansible
description: Automated, hardened OpenClaw installation with Ansible, Tailscale VPN, and firewall isolation
metadata: {"openclaw":{"docPath":"install/ansible","group":"Install & Updates"}}
---

# Ansible

## Purpose
- Automated, hardened OpenClaw installation with Ansible, Tailscale VPN, and firewall isolation

## Read When
- You want automated server deployment with security hardening
- You need firewall-isolated setup with VPN access
- You're deploying to remote Debian/Ubuntu servers

## Topics Covered
- Quick Start
- What You Get
- Requirements
- What Gets Installed
- Post-Install Setup
- Security Architecture
- Manual Installation
- Updating OpenClaw

## Key Commands
```bash
curl -fsSL https://raw.githubusercontent.com/openclaw/openclaw-ansible/main/install.sh | bash
```

```bash
sudo -i -u openclaw
```

```bash
# Check service status
sudo systemctl status openclaw

# View live logs
sudo journalctl -u openclaw -f

# Restart gateway
sudo systemctl restart openclaw

# Provider login (run as openclaw user)
sudo -i -u openclaw
openclaw channels login
```

```bash
nmap -p- YOUR_SERVER_IP
```

```bash
# 1. Install prerequisites
sudo apt update && sudo apt install -y ansible git

# 2. Clone repository
git clone https://github.com/openclaw/openclaw-ansible.git
cd openclaw-ansible

# 3. Install Ansible collections
ansible-galaxy collection install -r requirements.yml

# 4. Run playbook
./run-playbook.sh
```

```bash
cd openclaw-ansible
./run-playbook.sh
```

## Files And Paths
- /tmp/openclaw-setup.sh
- ~/openclaw

## Related Source Code
- openclaw/src
- openclaw/docs/install/ansible.md
- openclaw/scripts
- openclaw/docker-setup.sh
- openclaw/Dockerfile

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/install/ansible