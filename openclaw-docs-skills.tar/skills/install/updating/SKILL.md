---
name: openclaw-docs-install-updating
description: Updating OpenClaw safely (global install or source), plus rollback strategy
metadata: {"openclaw":{"docPath":"install/updating","group":"Install & Updates"}}
---

# Updating

## Purpose
- Updating OpenClaw safely (global install or source), plus rollback strategy

## Read When
- Updating OpenClaw
- Something breaks after an update

## Topics Covered
- Recommended: re-run the website installer (upgrade in place)
- Before you update
- Update (global install)
- Update (`openclaw update`)
- Update (Control UI / RPC)
- Update (from source)
- Always Run: `openclaw doctor`
- Start / stop / restart the Gateway

## Key Commands
```bash
curl -fsSL https://openclaw.ai/install.sh | bash
```

```bash
curl -fsSL https://openclaw.ai/install.sh | bash -s -- --install-method git --no-onboard
```

```bash
npm i -g openclaw@latest
```

```bash
pnpm add -g openclaw@latest
```

```bash
openclaw update --channel beta
openclaw update --channel dev
openclaw update --channel stable
```

```bash
openclaw doctor
openclaw gateway restart
openclaw health
```

## Files And Paths
- ~/.openclaw/openclaw.json
- ~/.openclaw/credentials/
- ~/.openclaw/workspace
- .openclaw.*`

## Related Source Code
- openclaw/src
- openclaw/docs/install/updating.md
- openclaw/scripts
- openclaw/docker-setup.sh
- openclaw/Dockerfile

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/install/updating