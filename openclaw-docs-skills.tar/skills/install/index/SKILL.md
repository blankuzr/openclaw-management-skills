---
name: openclaw-docs-install-index
description: Install OpenClaw (recommended installer, global install, or from source)
metadata: {"openclaw":{"docPath":"install/index","group":"Install & Updates"}}
---

# Install

## Purpose
- Install OpenClaw (recommended installer, global install, or from source)

## Read When
- Installing OpenClaw
- You want to install from GitHub

## Topics Covered
- Quick install (recommended)
- System requirements
- Choose your install path
- After install
- Install method: npm vs git (installer)
- Troubleshooting: `openclaw` not found (PATH)
- Update / uninstall

## Key Commands
```bash
curl -fsSL https://openclaw.ai/install.sh | bash
```

```bash
iwr -useb https://openclaw.ai/install.ps1 | iex
```

```bash
openclaw onboard --install-daemon
```

```bash
curl -fsSL https://openclaw.ai/install.sh | bash
```

```bash
curl -fsSL https://openclaw.ai/install.sh | bash -s -- --help
```

```bash
curl -fsSL https://openclaw.ai/install.sh | bash -s -- --no-onboard
```

## Key Environment Variables
- OPENCLAW_INSTALL_METHOD
- OPENCLAW_GIT_DIR
- OPENCLAW_GIT_UPDATE
- OPENCLAW_NO_PROMPT
- OPENCLAW_DRY_RUN
- OPENCLAW_NO_ONBOARD

## Files And Paths
- ~/openclaw
- ~/.zshrc
- ~/.bashrc

## Related Source Code
- openclaw/src
- openclaw/docs/install/index.md
- openclaw/scripts
- openclaw/docker-setup.sh
- openclaw/Dockerfile

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/install/index