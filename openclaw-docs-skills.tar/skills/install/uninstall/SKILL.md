---
name: openclaw-docs-install-uninstall
description: Uninstall OpenClaw completely (CLI, service, state, workspace)
metadata: {"openclaw":{"docPath":"install/uninstall","group":"Install & Updates"}}
---

# Uninstall

## Purpose
- Uninstall OpenClaw completely (CLI, service, state, workspace)

## Read When
- You want to remove OpenClaw from a machine
- The gateway service is still running after uninstall

## Topics Covered
- Easy path (CLI still installed)
- Manual service removal (CLI not installed)
- Normal install vs source checkout

## Key Commands
```bash
openclaw uninstall
```

```bash
openclaw uninstall --all --yes --non-interactive
npx -y openclaw uninstall --all --yes --non-interactive
```

```bash
openclaw gateway stop
```

```bash
openclaw gateway uninstall
```

```bash
rm -rf "${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
```

```bash
rm -rf ~/.openclaw/workspace
```

## Key Environment Variables
- OPENCLAW_STATE_DIR
- OPENCLAW_CONFIG_PATH
- OPENCLAW_PROFILE

## Files And Paths
- /.openclaw}
- ~/.openclaw/workspace
- ~/.openclaw-
- .openclaw.*`
- ~/Library/LaunchAgents/bot.molt.gateway.plist
- ~/.config/systemd/user/openclaw-gateway.service
- .openclaw\gateway.cmd
- .openclaw-

## Related Source Code
- openclaw/src
- openclaw/docs/install/uninstall.md
- openclaw/scripts
- openclaw/docker-setup.sh
- openclaw/Dockerfile

## How To Use This Skill
- Copy this folder into your OpenClaw skills directory (typically `<openclaw-install>/skills/`).
- Add the skill name to `SKILLS.md` or reference it in your agent config/AGENTS.md so it can be loaded.
- Use the OpenClaw CLI for the commands shown here and consult the linked doc page for full details.
- If you use tooling or web lookups, enable the standard OpenClaw tools (`exec`, `web`, `browser`) as needed.

## Source Documentation
- https://docs.openclaw.ai/install/uninstall